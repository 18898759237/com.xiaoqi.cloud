/**
 * 自动生成
 */
package com.xiaoqi;

import com.google.gson.Gson;
import com.xiaoqi.entity.DataModel;
import com.xiaoqi.entity.FileUrl;
import com.xiaoqi.entity.MysqlInfo;
import com.xiaoqi.entity.PropertyInfo;
import com.xiaoqi.util.EntityInfoUtil;
import com.xiaoqi.util.GeneratorUtil;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class MyGenerator {
    // 基础信息：作者、版本
    public static final String AUTHOR = "liuxuebo";
    public static final String VERSION = "V1.0";

    // 数据库连接信息：连接URL、用户名、秘密、数据库名
    public static final String URL = "jdbc:mysql://192.168.136.128:3306/ry-vehicle?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true&serverTimezone=Asia/Shanghai";
    public static final String NAME = "root";
    public static final String PASS = "xiaoqi";
    public static final String DATABASE = "ry_vehicle";

    // 类信息：类名、对象名（一般是【类名】的首字母小些）、类说明、时间
    public static final String ENTITY_NAME = "ActualDataNodes";
    public static final String TABLE = "actual-data-nodes";
    public static final String ENTITY_COMMENT = "表分片";
    public static final String TIME = "2022年09月19日";
    public static final String AGILE = new Date().getTime() + "";

    // 路径信息，分开路径方便聚合工程项目，微服务项目
    public static final String ENTITY_URL = "com.sziov.vehicle.entity.po";
    public static final String DAO_URL = "com.sziov.vehicle.dao";
    public static final String MAPPER_URL = "com.sziov.mapper";
    public static final String SERVICE_URL = "com.sziov.vehicle.service";
    public static final String SERVICE_IMPL_URL = "com.sziov.vehicle.service.impl";

    public static void main(String[] args) throws SQLException {

        DataModel dataModel = init();
        Gson gson = new Gson();
        System.out.println(gson.toJson(dataModel));
        String fileUrl = "C:\\Users\\Administrator\\Desktop\\dd";// 生成文件存放位置
        //开始生成文件
        GeneratorUtil.createEntity(fileUrl, dataModel).toString();
        GeneratorUtil.createDao(fileUrl, dataModel).toString();
        GeneratorUtil.createDaoImpl(fileUrl, dataModel).toString();
        GeneratorUtil.createService(fileUrl, dataModel).toString();
        GeneratorUtil.createServiceImpl(fileUrl, dataModel).toString();

    }

    /**
     * 初始化数据模型
     * @return
     * @throws SQLException
     */
    public static DataModel  init() throws SQLException {
        // 数据模型
        DataModel dataModel = new DataModel();
        dataModel.setVersion(VERSION);
        dataModel.setAuthor(AUTHOR);
        dataModel.setEntityName(ENTITY_NAME);
        dataModel.setEntityComment(ENTITY_COMMENT);

        // 初始化数据库连接信息
        MysqlInfo mysqlInfo = new MysqlInfo(URL, DATABASE, NAME, PASS, TABLE);
        dataModel.setMysqlInfo(mysqlInfo);

        // 初始化数据库表字段
        List<PropertyInfo> propertyInfoList = EntityInfoUtil.getInfo(mysqlInfo);
        dataModel.setPropertyInfoList(propertyInfoList);

        // 初始化package的url
        FileUrl FileUrl = new FileUrl(ENTITY_URL, DAO_URL, MAPPER_URL, SERVICE_URL, SERVICE_IMPL_URL);
        dataModel.setBaseUrl(FileUrl);
        return dataModel;
    }
}
