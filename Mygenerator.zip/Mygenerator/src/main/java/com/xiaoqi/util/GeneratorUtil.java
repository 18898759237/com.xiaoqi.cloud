/**
 * Copyright © 2019 dream horse Info. Tech Ltd. All rights reserved.
 *
 * @Package: com.gitee.mybatis.fl.convert
 * @author: flying-cattle
 * @date: 2019年4月9日 下午8:15:25
 */
package com.xiaoqi.util;

import com.xiaoqi.entity.DataModel;
import com.xiaoqi.entity.PropertyInfo;
import com.xiaoqi.entity.ResultJson;

import java.util.List;

/**
 * 生成文件
 */
public class GeneratorUtil {
    //路径信息
    public static final String ENTITY = "entity";
    public static final String DAO = "dao";
    public static final String DAO_IMPL = "daoImpl";
    public static final String SERVICE = "service";
    public static final String SERVICE_IMPL = "serviceImpl";

    // 创建实体类
    public static ResultJson createEntity(String url, DataModel bi) {
        String fileUrl = getGeneratorFileUrl(url, bi.getBaseUrl().getEntityUrl(), bi.getEntityName(), ENTITY);
        return FreemarkerUtil.createFile(bi, "entity.ftl", fileUrl);
    }

    // 创建DAO
    public static ResultJson createDao(String url, DataModel bi) {
        String fileUrl = getGeneratorFileUrl(url, bi.getBaseUrl().getDaoUrl(), bi.getEntityName(), DAO);
        return FreemarkerUtil.createFile(bi, "dao.ftl", fileUrl);
    }

    // 创建mapper配置文件
    public static ResultJson createDaoImpl(String url, DataModel bi) {
        String fileUrl = getGeneratorFileUrl(url, bi.getBaseUrl().getMapperUrl(), bi.getEntityName(), DAO_IMPL);
        List<PropertyInfo> list = bi.getPropertyInfoList();
        // 初始化基本字段及插入字段
        String baseColumnList = "";
        String insertColumnList = "";
        for (PropertyInfo propertyInfo : list) {
            baseColumnList = baseColumnList + propertyInfo.getJdbcColumn() + ", ";
            if(!propertyInfo.getJdbcColumn().equals("id")){
                insertColumnList = insertColumnList + propertyInfo.getJdbcColumn() + ", ";
            }
        }
        baseColumnList = baseColumnList.substring(0, baseColumnList.length() - 2);
        insertColumnList = insertColumnList.substring(0, insertColumnList.length() - 2);
        bi.setBaseColumnList(baseColumnList);
        bi.setInsertColumnList(insertColumnList);
        return FreemarkerUtil.createFile(bi, "mapper.ftl", fileUrl);
    }

    // 创建SERVICE
    public static ResultJson createService(String url, DataModel bi) {
        String fileUrl = getGeneratorFileUrl(url, bi.getBaseUrl().getServiceUrl(), bi.getEntityName(), SERVICE);
        return FreemarkerUtil.createFile(bi, "service.ftl", fileUrl);
    }

    // 创建SERVICE_IMPL
    public static ResultJson createServiceImpl(String url, DataModel bi) {
        String fileUrl = getGeneratorFileUrl(url, bi.getBaseUrl().getServiceImplUrl(), bi.getEntityName(), SERVICE_IMPL);
        return FreemarkerUtil.createFile(bi, "serviceImpl.ftl", fileUrl);
    }

    //生成文件路径和名字
    public static String getGeneratorFileUrl(String url, String packageUrl, String entityName, String type) {
        if (type.equals("entity")) {
            return url + pageToUrl(packageUrl) + entityName + ".java";
        } else if (type.equals("dao")) {
            return url + pageToUrl(packageUrl) + entityName + "Mapper.java";
        } else if (type.equals("daoImpl")) {
            return url + pageToUrl(packageUrl) + entityName + "Mapper.xml";
        } else if (type.equals("service")) {
            return url + pageToUrl(packageUrl) + entityName + "Service.java";
        } else if (type.equals("serviceImpl")) {
            return url + pageToUrl(packageUrl) + entityName + "ServiceImpl.java";
        } else if (type.equals("controller")) {
            return url + pageToUrl(packageUrl) + entityName + "Controller.java";
        } else if (type.equals("swaggerConfig")) {
            return url + pageToUrl(packageUrl) + entityName + "Config.java";
        }
        return null;
    }

    /**
     * 转换package路径为真实路径
     * @param url
     * @return
     */
    public static String pageToUrl(String url) {
        return url.replace(".", "/") + "/";
    }
}
