
package com.xiaoqi.util;

import com.xiaoqi.convert.MySqlTypeConvert;
import com.xiaoqi.entity.DataModel;
import com.xiaoqi.entity.MysqlInfo;
import com.xiaoqi.entity.PropertyInfo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 获取表字段信息
 */
public class EntityInfoUtil {

    /**
     * 查询数据库表字段信息
     * @param  bi 数据连接信息
     * @return 数据库表字段集合
     * @throws SQLException
     */
    public static List<PropertyInfo> getInfo(MysqlInfo bi) throws SQLException {
        List<PropertyInfo> columns = new ArrayList<PropertyInfo>();
        // 创建连接
        Connection con = null;
        PreparedStatement pstemt = null;
        ResultSet rs = null;
        //sql
        String sql = "select column_name,data_type,column_comment from information_schema.columns where table_schema='" + bi.getDbName() + "' and table_name='" + bi.getTable() + "'";
        try {
            con = DriverManager.getConnection(bi.getDbUrl(), bi.getUserName(), bi.getDbPassword());
            pstemt = con.prepareStatement(sql);
            rs = pstemt.executeQuery();
            while (rs.next()) {
                String column = rs.getString(1);
                String jdbcType = rs.getString(2);
                String comment = rs.getString(3);

                PropertyInfo pi = new PropertyInfo();
                pi.setJdbcColumn(column);
                pi.setJdbcComment(comment);
                pi.setJdbcType(MySqlToJavaUtil.jdbcTypeToMapperType(jdbcType));
                pi.setJavaColumn(MySqlToJavaUtil.changeToJavaFiled(pi.getJdbcColumn()));
                pi.setJavaType(MySqlToJavaUtil.jdbcTypeToJavaType(pi.getJdbcType()));
                columns.add(pi);
            }
            // 完成后关闭
            rs.close();
            pstemt.close();
            con.close();
            if (null == columns || columns.size() == 0) {
                throw new RuntimeException("未能读取到表或表中的字段。请检查链接url，数据库账户，数据库密码，查询的数据名、是否正确。");
            }
            return columns;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("自动生成实体类错误：" + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
            } catch (SQLException se2) {
            }
            // 关闭资源
            try {
                if (pstemt != null) pstemt.close();
            } catch (SQLException se2) {
            }// 什么都不做
            try {
                if (con != null) con.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
