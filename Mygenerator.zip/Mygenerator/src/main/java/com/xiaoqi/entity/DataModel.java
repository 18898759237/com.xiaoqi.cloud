package com.xiaoqi.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 数据模型
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataModel implements Serializable {
    private static final long serialVersionUID = 123123L;

    /**
     * 作者
     */
    private String author;
    /**
     * 版本
     */
    private String version;

    /**
     * 实体类名
     */
    private String entityName;

    /**
     * 首字母小写实体类名
     */
    private String lowercaseEntityName;

    /**
     * 实体注释
     */
    private String entityComment;

    /**
     * 数据库信息
     */
    private MysqlInfo mysqlInfo;

    /**
     * 数据库字段集合
     */
    private List<PropertyInfo> propertyInfoList;

    /**
     * 数据库修改插入字段集合
     */
    private List<PropertyInfo> updatePropertyInfoList;

    /**
     * 文件路径
     */
    private FileUrl baseUrl;


    /**
     * mapper.xml文件中baseColumnList属性
     */
    private String baseColumnList;

    /**
     * mapper.xml文件中insterColumnList属性
     */
    private String insertColumnList;

    /**
     * mapper.xml文件中idColumn属性
     */
    private String idColumn = "#{id,jdbcType=INTEGER}";

    /**
     * 排序语句
     */
    private String orderSql = "" +
            "<if test=\"orderByClause != null\">\n" +
            "             order by ${orderByClause}\n" +
            "        </if>";

    /**
     * 分页语句
     */
    private String limitSql = "" +
            "<if test=\"limit != null\">\n" +
            "             <if test=\"offset != null\">\n" +
            "                 limit ${offset}, ${limit}\n" +
            "             </if>\n" +
            "             <if test=\"offset == null\">\n" +
            "                 limit ${limit}\n" +
            "             </if>\n" +
            "        </if>";


    public List<PropertyInfo> getUpdatePropertyInfoList() {
        return this.propertyInfoList.stream().filter(p -> !p.getJdbcColumn().equals("id")).collect(Collectors.toList());
    }

    public String getLowercaseEntityName() {
        if (Character.isLowerCase(this.entityName.charAt(0))) {

            return this.entityName;
        } else {

            return (new StringBuilder()).append(Character.toLowerCase(this.entityName.charAt(0))).append(this.entityName.substring(1)).toString();
        }
    }
}
