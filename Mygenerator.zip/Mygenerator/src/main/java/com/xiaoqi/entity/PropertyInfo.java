package com.xiaoqi.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 数据库表字段属性
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PropertyInfo implements Serializable {

    private static final long serialVersionUID = 123124L;

    /**
     * 数据库字段名
     */
    private String jdbcColumn;

    /**
     * 数据库字段类型
     */
    private String jdbcType;

    public String getJsonFormat() {

        if(this.javaType.contains("Date")){
            return "@JsonFormat(pattern = \"yyyy-MM-dd HH:mm:ss\", timezone = \"GMT+8\")";
        }
        return "";
    }
    /**
     * 日期各式字符串
     */
    private String jsonFormat;
    /**
     * 数据库字段注释
     */
    private String jdbcComment;

    /**
     * 实体类字段名
     */
    private String javaColumn;

    /**
     * 实体类字段类型
     */
    private String javaType;
    /**
     * jdbc属性字符串
     * #{id,jdbcType=INTEGER},
     */
    private String insertColumn;

    /**
     * jdbc属性字符串
     * #{id,jdbcType=INTEGER},
     */
    private String whereColumn;

    public String getInsertColumn() {
        if(this.jdbcColumn.equals("id")){
            return "";
        }
        String str = "#{id,jdbcType=INTEGER},";
        str = str.replace("id", this.javaColumn);
        str = str.replace("INTEGER", this.jdbcType);
        return str;
    }

    public String getWhereColumn() {

        String str = "#{id,jdbcType=INTEGER}";
        str = str.replace("id", this.javaColumn);
        str = str.replace("INTEGER", this.jdbcType);
        return str;
    }
}
