package com.xiaoqi.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * 文件路径
 */
@Data
public class FileUrl implements Serializable{
	private static final long serialVersionUID = 123125L;

	/**
	 * 实体类路径
	 */
	private String entityUrl;

	/**
	 * dao路径
	 */
	private String daoUrl;

	/**
	 * mapperUrl 路径
	 */
	private String mapperUrl;

	/**
	 * serviceUrl路径
	 */
	private String serviceUrl;

	/**
	 * serviceImplUrl
	 */
	private String serviceImplUrl;

	public FileUrl(String entityUrl, String daoUrl, String mapperUrl, String serviceUrl, String serviceImplUrl) {
		this.entityUrl = entityUrl;
		this.daoUrl = daoUrl;
		this.mapperUrl = mapperUrl;
		this.serviceUrl = serviceUrl;
		this.serviceImplUrl = serviceImplUrl;
	}
}
