package com.xiaoqi.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

/**
 * 数据库连接信息
 */
@Data
public class MysqlInfo implements Serializable {
    private static final long serialVersionUID = 123123L;

    /**
     * jdbc连接
     */
    private String dbUrl;

    /**
     * 数据库名字
     */
    private String dbName;

    /**
     * 数据库用户名
     */
    private String userName;
    /**
     * 数据库密码
     */
    private String dbPassword;

    /**
     * 表名
     */
    private String table;

    public MysqlInfo(String dbUrl, String dbName, String userName, String dbPassword, String table) {
        this.dbUrl = dbUrl;
        this.dbName = dbName;
        this.userName = userName;
        this.dbPassword = dbPassword;
        this.table = table;
    }
}
