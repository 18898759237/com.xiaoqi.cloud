package com.xiaoqi.vehicle.domain;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.xiaoqi.common.core.annotation.Excel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.xiaoqi.common.core.web.domain.BaseEntity;

/**
 * 车辆行驶记录对象 vehicle_test_record
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@ApiModel(value = "车辆行驶记录")
public class VehicleTestRecord extends BaseEntity
        {
private static final long serialVersionUID=1L;

    /** $column.columnComment */
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 客户名称 */
            @Excel(name = "客户名称")
    @ApiModelProperty(value = "客户名称")
    private String customerName;

    /** 车辆vin码 */
            @Excel(name = "车辆vin码")
    @ApiModelProperty(value = "车辆vin码")
    private String vin;

    /** 时间戳 */
            @Excel(name = "时间戳")
    @ApiModelProperty(value = "时间戳")
    private Long timeStamp;

    /** 0：熄火,1：点火 */
            @Excel(name = "0：熄火,1：点火")
    @ApiModelProperty(value = "0：熄火,1：点火")
    private Long ignitionStatus;

    /** 0：手动,1：自动 */
            @Excel(name = "0：手动,1：自动")
    @ApiModelProperty(value = "0：手动,1：自动")
    private Long drivingMode;

    /** 总里程km */
            @Excel(name = "总里程km")
    @ApiModelProperty(value = "总里程km")
    private BigDecimal totalMileage;

    /** 续航里程km */
            @Excel(name = "续航里程km")
    @ApiModelProperty(value = "续航里程km")
    private BigDecimal recordRange;

    /** 车速km/h */
            @Excel(name = "车速km/h")
    @ApiModelProperty(value = "车速km/h")
    private BigDecimal speed;

    /** 方向盘角度 */
            @Excel(name = "方向盘角度")
    @ApiModelProperty(value = "方向盘角度")
    private BigDecimal steeringWheelAngle;

    /** 方向盘扭矩 */
            @Excel(name = "方向盘扭矩")
    @ApiModelProperty(value = "方向盘扭矩")
    private String steeringWheelTorque;

    /** 挡位0：N/P,1：D,2：R */
            @Excel(name = "挡位0：N/P,1：D,2：R")
    @ApiModelProperty(value = "挡位0：N/P,1：D,2：R")
    private String gear;

    /** 油门踏板开度 */
            @Excel(name = "油门踏板开度")
    @ApiModelProperty(value = "油门踏板开度")
    private BigDecimal acceleratorPedalOpening;

    /** 制动踏板开度 */
            @Excel(name = "制动踏板开度")
    @ApiModelProperty(value = "制动踏板开度")
    private BigDecimal brakePedalOpening;

    /** 转向灯,0：无转向灯,1：左转向灯开,2：右转向灯开 */
            @Excel(name = "转向灯,0：无转向灯,1：左转向灯开,2：右转向灯开")
    @ApiModelProperty(value = "转向灯,0：无转向灯,1：左转向灯开,2：右转向灯开")
    private BigDecimal corneringLamp;

    /** 加速度,m/s2 */
            @Excel(name = "加速度,m/s2")
    @ApiModelProperty(value = "加速度,m/s2")
    private BigDecimal acceleration;

    /** 刹车灯 */
            @Excel(name = "刹车灯")
    @ApiModelProperty(value = "刹车灯")
    private String stoplight;

    /** GPS有效性,0：有效,1：无效 */
            @Excel(name = "GPS有效性,0：有效,1：无效")
    @ApiModelProperty(value = "GPS有效性,0：有效,1：无效")
    private Long gpsValidity;

    /** GPS经度 */
            @Excel(name = "GPS经度")
    @ApiModelProperty(value = "GPS经度")
    private BigDecimal gpsLongitude;

    /** GPS纬度 */
            @Excel(name = "GPS纬度")
    @ApiModelProperty(value = "GPS纬度")
    private BigDecimal gpsLatitude;

    /** f方向盘航向角 */
            @Excel(name = "f方向盘航向角")
    @ApiModelProperty(value = "f方向盘航向角")
    private BigDecimal gpsHeadingAngle;

    /** GPS加速度 */
            @Excel(name = "GPS加速度")
    @ApiModelProperty(value = "GPS加速度")
    private BigDecimal gpsAcceleration;

    /** 时间 */
            @JsonFormat(pattern = "yyyy-MM-dd")
            @Excel(name = "时间", width = 30, dateFormat = "yyyy-MM-dd")
    @ApiModelProperty(value = "时间")
    private Date recodTime;

    /** 制动灯 */
            @Excel(name = "制动灯")
    @ApiModelProperty(value = "制动灯")
    private Long breakLight;

    /** 提示接管类型，0：无提示  1：交通阻塞 */
            @Excel(name = "提示接管类型，0：无提示  1：交通阻塞")
    @ApiModelProperty(value = "提示接管类型，0：无提示  1：交通阻塞")
    private Long takeoverType;

    public void setId(Long id)
            {
            this.id = id;
            }

    public Long getId()
            {
            return id;
            }
    public void setCustomerName(String customerName)
            {
            this.customerName = customerName;
            }

    public String getCustomerName()
            {
            return customerName;
            }
    public void setVin(String vin)
            {
            this.vin = vin;
            }

    public String getVin()
            {
            return vin;
            }
    public void setTimeStamp(Long timeStamp)
            {
            this.timeStamp = timeStamp;
            }

    public Long getTimeStamp()
            {
            return timeStamp;
            }
    public void setIgnitionStatus(Long ignitionStatus)
            {
            this.ignitionStatus = ignitionStatus;
            }

    public Long getIgnitionStatus()
            {
            return ignitionStatus;
            }
    public void setDrivingMode(Long drivingMode)
            {
            this.drivingMode = drivingMode;
            }

    public Long getDrivingMode()
            {
            return drivingMode;
            }
    public void setTotalMileage(BigDecimal totalMileage)
            {
            this.totalMileage = totalMileage;
            }

    public BigDecimal getTotalMileage()
            {
            return totalMileage;
            }
    public void setRecordRange(BigDecimal recordRange)
            {
            this.recordRange = recordRange;
            }

    public BigDecimal getRecordRange()
            {
            return recordRange;
            }
    public void setSpeed(BigDecimal speed)
            {
            this.speed = speed;
            }

    public BigDecimal getSpeed()
            {
            return speed;
            }
    public void setSteeringWheelAngle(BigDecimal steeringWheelAngle)
            {
            this.steeringWheelAngle = steeringWheelAngle;
            }

    public BigDecimal getSteeringWheelAngle()
            {
            return steeringWheelAngle;
            }
    public void setSteeringWheelTorque(String steeringWheelTorque)
            {
            this.steeringWheelTorque = steeringWheelTorque;
            }

    public String getSteeringWheelTorque()
            {
            return steeringWheelTorque;
            }
    public void setGear(String gear)
            {
            this.gear = gear;
            }

    public String getGear()
            {
            return gear;
            }
    public void setAcceleratorPedalOpening(BigDecimal acceleratorPedalOpening)
            {
            this.acceleratorPedalOpening = acceleratorPedalOpening;
            }

    public BigDecimal getAcceleratorPedalOpening()
            {
            return acceleratorPedalOpening;
            }
    public void setBrakePedalOpening(BigDecimal brakePedalOpening)
            {
            this.brakePedalOpening = brakePedalOpening;
            }

    public BigDecimal getBrakePedalOpening()
            {
            return brakePedalOpening;
            }
    public void setCorneringLamp(BigDecimal corneringLamp)
            {
            this.corneringLamp = corneringLamp;
            }

    public BigDecimal getCorneringLamp()
            {
            return corneringLamp;
            }
    public void setAcceleration(BigDecimal acceleration)
            {
            this.acceleration = acceleration;
            }

    public BigDecimal getAcceleration()
            {
            return acceleration;
            }
    public void setStoplight(String stoplight)
            {
            this.stoplight = stoplight;
            }

    public String getStoplight()
            {
            return stoplight;
            }
    public void setGpsValidity(Long gpsValidity)
            {
            this.gpsValidity = gpsValidity;
            }

    public Long getGpsValidity()
            {
            return gpsValidity;
            }
    public void setGpsLongitude(BigDecimal gpsLongitude)
            {
            this.gpsLongitude = gpsLongitude;
            }

    public BigDecimal getGpsLongitude()
            {
            return gpsLongitude;
            }
    public void setGpsLatitude(BigDecimal gpsLatitude)
            {
            this.gpsLatitude = gpsLatitude;
            }

    public BigDecimal getGpsLatitude()
            {
            return gpsLatitude;
            }
    public void setGpsHeadingAngle(BigDecimal gpsHeadingAngle)
            {
            this.gpsHeadingAngle = gpsHeadingAngle;
            }

    public BigDecimal getGpsHeadingAngle()
            {
            return gpsHeadingAngle;
            }
    public void setGpsAcceleration(BigDecimal gpsAcceleration)
            {
            this.gpsAcceleration = gpsAcceleration;
            }

    public BigDecimal getGpsAcceleration()
            {
            return gpsAcceleration;
            }
    public void setRecodTime(Date recodTime)
            {
            this.recodTime = recodTime;
            }

    public Date getRecodTime()
            {
            return recodTime;
            }
    public void setBreakLight(Long breakLight)
            {
            this.breakLight = breakLight;
            }

    public Long getBreakLight()
            {
            return breakLight;
            }
    public void setTakeoverType(Long takeoverType)
            {
            this.takeoverType = takeoverType;
            }

    public Long getTakeoverType()
            {
            return takeoverType;
            }

@Override
public String toString(){
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id",getId())
            .append("customerName",getCustomerName())
            .append("vin",getVin())
            .append("timeStamp",getTimeStamp())
            .append("ignitionStatus",getIgnitionStatus())
            .append("drivingMode",getDrivingMode())
            .append("totalMileage",getTotalMileage())
            .append("recordRange",getRecordRange())
            .append("speed",getSpeed())
            .append("steeringWheelAngle",getSteeringWheelAngle())
            .append("steeringWheelTorque",getSteeringWheelTorque())
            .append("gear",getGear())
            .append("acceleratorPedalOpening",getAcceleratorPedalOpening())
            .append("brakePedalOpening",getBrakePedalOpening())
            .append("corneringLamp",getCorneringLamp())
            .append("acceleration",getAcceleration())
            .append("stoplight",getStoplight())
            .append("gpsValidity",getGpsValidity())
            .append("gpsLongitude",getGpsLongitude())
            .append("gpsLatitude",getGpsLatitude())
            .append("gpsHeadingAngle",getGpsHeadingAngle())
            .append("gpsAcceleration",getGpsAcceleration())
            .append("recodTime",getRecodTime())
            .append("breakLight",getBreakLight())
            .append("takeoverType",getTakeoverType())
        .toString();
        }
        }
