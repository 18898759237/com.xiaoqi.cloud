package com.xiaoqi.vehicle.controller;

import java.util.List;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.xiaoqi.common.log.annotation.Log;
import com.xiaoqi.common.log.enums.BusinessType;
import com.xiaoqi.common.security.annotation.RequiresPermissions;
import com.xiaoqi.vehicle.domain.VehicleSafetyInfo;
import com.xiaoqi.vehicle.service.IVehicleSafetyInfoService;
import com.xiaoqi.common.core.web.controller.BaseController;
import com.xiaoqi.common.core.web.domain.AjaxResult;
import com.xiaoqi.common.core.utils.poi.ExcelUtil;
import com.xiaoqi.common.core.web.page.TableDataInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 安全员基础信息Controller
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@RestController
@RequestMapping("/safety")
@Api(tags ="安全员基础信息")
public class VehicleSafetyInfoController extends BaseController
{
    @Autowired
    private IVehicleSafetyInfoService vehicleSafetyInfoService;

    /**
     * 查询安全员基础信息列表
     */
    @ApiOperation(value = "查询安全员基础信息列表")
    @RequiresPermissions("vehicle:safety:list")
    @GetMapping("/list")
    public TableDataInfo list(VehicleSafetyInfo vehicleSafetyInfo)
    {
        startPage();
        List<VehicleSafetyInfo> list = vehicleSafetyInfoService.selectVehicleSafetyInfoList(vehicleSafetyInfo);
        return getDataTable(list);
    }

    /**
     * 导出安全员基础信息列表
     */
    @ApiOperation(value = "导出安全员基础信息列表")
    @RequiresPermissions("vehicle:safety:export")
    @Log(title = "安全员基础信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, VehicleSafetyInfo vehicleSafetyInfo)
    {
        List<VehicleSafetyInfo> list = vehicleSafetyInfoService.selectVehicleSafetyInfoList(vehicleSafetyInfo);
        ExcelUtil<VehicleSafetyInfo> util = new ExcelUtil<VehicleSafetyInfo>(VehicleSafetyInfo.class);
        util.exportExcel(response, list, "安全员基础信息数据");
    }

    /**
     * 获取安全员基础信息详细信息
     */
    @ApiOperation(value = "获取安全员基础信息详细信息")
    @RequiresPermissions("vehicle:safety:query")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(vehicleSafetyInfoService.selectVehicleSafetyInfoById(id));
    }

    /**
     * 新增安全员基础信息
     */
    @ApiOperation(value = "新增安全员基础信息")
    @RequiresPermissions("vehicle:safety:add")
    @Log(title = "安全员基础信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody VehicleSafetyInfo vehicleSafetyInfo)
    {
        return toAjax(vehicleSafetyInfoService.insertVehicleSafetyInfo(vehicleSafetyInfo));
    }

    /**
     * 修改安全员基础信息
     */
    @ApiOperation(value = "修改安全员基础信息")
    @RequiresPermissions("vehicle:safety:edit")
    @Log(title = "安全员基础信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody VehicleSafetyInfo vehicleSafetyInfo)
    {
        return toAjax(vehicleSafetyInfoService.updateVehicleSafetyInfo(vehicleSafetyInfo));
    }

    /**
     * 删除安全员基础信息
     */
    @ApiOperation(value = "删除安全员基础信息")
    @RequiresPermissions("vehicle:safety:remove")
    @Log(title = "安全员基础信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(vehicleSafetyInfoService.deleteVehicleSafetyInfoByIds(ids));
    }
}
