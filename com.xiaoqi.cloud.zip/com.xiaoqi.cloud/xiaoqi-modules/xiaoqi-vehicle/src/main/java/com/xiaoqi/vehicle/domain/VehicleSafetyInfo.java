package com.xiaoqi.vehicle.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.xiaoqi.common.core.annotation.Excel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.xiaoqi.common.core.web.domain.BaseEntity;

/**
 * 安全员基础信息对象 vehicle_safety_info
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@ApiModel(value = "安全员基础信息")
public class VehicleSafetyInfo extends BaseEntity
        {
private static final long serialVersionUID=1L;

    /** 安全员ID */
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 客户id */
            @Excel(name = "客户id")
    @ApiModelProperty(value = "客户id")
    private Long customerId;

    /** 真实姓名 */
            @Excel(name = "真实姓名")
    @ApiModelProperty(value = "真实姓名")
    private String realName;

    /** 头像图标 */
            @Excel(name = "头像图标")
    @ApiModelProperty(value = "头像图标")
    private String headIcon;

    /** 性别（1：男 2：女 对应数据字典gender） */
            @Excel(name = "性别", readConverterExp = "1=：男,2=：女,对=应数据字典gender")
    @ApiModelProperty(value = "性别")
    private Integer gender;

    /** 年龄 */
            @Excel(name = "年龄")
    @ApiModelProperty(value = "年龄")
    private Long age;

    /** 手机号 */
            @Excel(name = "手机号")
    @ApiModelProperty(value = "手机号")
    private String phone;

    /** 操作人 */
            @Excel(name = "操作人")
    @ApiModelProperty(value = "操作人")
    private Integer operator;

    public void setId(Long id)
            {
            this.id = id;
            }

    public Long getId()
            {
            return id;
            }
    public void setCustomerId(Long customerId)
            {
            this.customerId = customerId;
            }

    public Long getCustomerId()
            {
            return customerId;
            }
    public void setRealName(String realName)
            {
            this.realName = realName;
            }

    public String getRealName()
            {
            return realName;
            }
    public void setHeadIcon(String headIcon)
            {
            this.headIcon = headIcon;
            }

    public String getHeadIcon()
            {
            return headIcon;
            }
    public void setGender(Integer gender)
            {
            this.gender = gender;
            }

    public Integer getGender()
            {
            return gender;
            }
    public void setAge(Long age)
            {
            this.age = age;
            }

    public Long getAge()
            {
            return age;
            }
    public void setPhone(String phone)
            {
            this.phone = phone;
            }

    public String getPhone()
            {
            return phone;
            }
    public void setOperator(Integer operator)
            {
            this.operator = operator;
            }

    public Integer getOperator()
            {
            return operator;
            }

@Override
public String toString(){
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id",getId())
            .append("customerId",getCustomerId())
            .append("realName",getRealName())
            .append("headIcon",getHeadIcon())
            .append("gender",getGender())
            .append("age",getAge())
            .append("phone",getPhone())
            .append("updateTime",getUpdateTime())
            .append("createTime",getCreateTime())
            .append("operator",getOperator())
        .toString();
        }
        }
