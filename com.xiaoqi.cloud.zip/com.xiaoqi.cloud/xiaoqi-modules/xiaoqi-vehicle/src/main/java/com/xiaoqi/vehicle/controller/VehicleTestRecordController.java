package com.xiaoqi.vehicle.controller;

import java.util.List;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.xiaoqi.common.log.annotation.Log;
import com.xiaoqi.common.log.enums.BusinessType;
import com.xiaoqi.common.security.annotation.RequiresPermissions;
import com.xiaoqi.vehicle.domain.VehicleTestRecord;
import com.xiaoqi.vehicle.service.IVehicleTestRecordService;
import com.xiaoqi.common.core.web.controller.BaseController;
import com.xiaoqi.common.core.web.domain.AjaxResult;
import com.xiaoqi.common.core.utils.poi.ExcelUtil;
import com.xiaoqi.common.core.web.page.TableDataInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 车辆行驶记录Controller
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@RestController
@RequestMapping("/testrecord")
@Api(tags ="车辆行驶记录")
public class VehicleTestRecordController extends BaseController
{
    @Autowired
    private IVehicleTestRecordService vehicleTestRecordService;

    /**
     * 查询车辆行驶记录列表
     */
    @ApiOperation(value = "查询车辆行驶记录列表")
    @RequiresPermissions("vehicle:testrecord:list")
    @GetMapping("/list")
    public TableDataInfo list(VehicleTestRecord vehicleTestRecord)
    {
        startPage();
        List<VehicleTestRecord> list = vehicleTestRecordService.selectVehicleTestRecordList(vehicleTestRecord);
        return getDataTable(list);
    }

    /**
     * 导出车辆行驶记录列表
     */
    @ApiOperation(value = "导出车辆行驶记录列表")
    @RequiresPermissions("vehicle:testrecord:export")
    @Log(title = "车辆行驶记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, VehicleTestRecord vehicleTestRecord)
    {
        List<VehicleTestRecord> list = vehicleTestRecordService.selectVehicleTestRecordList(vehicleTestRecord);
        ExcelUtil<VehicleTestRecord> util = new ExcelUtil<VehicleTestRecord>(VehicleTestRecord.class);
        util.exportExcel(response, list, "车辆行驶记录数据");
    }

    /**
     * 获取车辆行驶记录详细信息
     */
    @ApiOperation(value = "获取车辆行驶记录详细信息")
    @RequiresPermissions("vehicle:testrecord:query")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(vehicleTestRecordService.selectVehicleTestRecordById(id));
    }

    /**
     * 新增车辆行驶记录
     */
    @ApiOperation(value = "新增车辆行驶记录")
    @RequiresPermissions("vehicle:testrecord:add")
    @Log(title = "车辆行驶记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody VehicleTestRecord vehicleTestRecord)
    {
        return toAjax(vehicleTestRecordService.insertVehicleTestRecord(vehicleTestRecord));
    }

    /**
     * 修改车辆行驶记录
     */
    @ApiOperation(value = "修改车辆行驶记录")
    @RequiresPermissions("vehicle:testrecord:edit")
    @Log(title = "车辆行驶记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody VehicleTestRecord vehicleTestRecord)
    {
        return toAjax(vehicleTestRecordService.updateVehicleTestRecord(vehicleTestRecord));
    }

    /**
     * 删除车辆行驶记录
     */
    @ApiOperation(value = "删除车辆行驶记录")
    @RequiresPermissions("vehicle:testrecord:remove")
    @Log(title = "车辆行驶记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(vehicleTestRecordService.deleteVehicleTestRecordByIds(ids));
    }
}
