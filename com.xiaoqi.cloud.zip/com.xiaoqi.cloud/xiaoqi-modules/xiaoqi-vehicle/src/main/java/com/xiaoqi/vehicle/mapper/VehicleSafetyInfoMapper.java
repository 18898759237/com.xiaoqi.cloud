package com.xiaoqi.vehicle.mapper;

import java.util.List;
import com.xiaoqi.vehicle.domain.VehicleSafetyInfo;

/**
 * 安全员基础信息Mapper接口
 *
 * @author xiaoqi
 * @date 2024-01-14
 */
public interface VehicleSafetyInfoMapper
{
    /**
     * 查询安全员基础信息
     *
     * @param id 安全员基础信息主键
     * @return 安全员基础信息
     */
    public VehicleSafetyInfo selectById(Long id);

    /**
     * 查询安全员基础信息列表
     *
     * @param vehicleSafetyInfo 安全员基础信息
     * @return 安全员基础信息集合
     */
    public List<VehicleSafetyInfo> selectList(VehicleSafetyInfo vehicleSafetyInfo);

    /**
     * 新增安全员基础信息
     *
     * @param vehicleSafetyInfo 安全员基础信息
     * @return 结果
     */
    public int insert(VehicleSafetyInfo vehicleSafetyInfo);

    /**
     * 修改安全员基础信息
     *
     * @param vehicleSafetyInfo 安全员基础信息
     * @return 结果
     */
    public int updateById(VehicleSafetyInfo vehicleSafetyInfo);

    /**
     * 删除安全员基础信息
     *
     * @param id 安全员基础信息主键
     * @return 结果
     */
    public int deleteById(Long id);

    /**
     * 批量删除安全员基础信息
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteByIds(Long[] ids);
}
