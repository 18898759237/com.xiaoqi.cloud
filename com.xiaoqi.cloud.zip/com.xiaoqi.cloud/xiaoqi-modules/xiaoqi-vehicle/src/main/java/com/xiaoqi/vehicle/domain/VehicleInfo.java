package com.xiaoqi.vehicle.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.xiaoqi.common.core.annotation.Excel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.xiaoqi.common.core.web.domain.BaseEntity;

/**
 * 测试车辆基础信息对象 vehicle_info
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@ApiModel(value = "测试车辆基础信息")
public class VehicleInfo extends BaseEntity
        {
private static final long serialVersionUID=1L;

    /** 记录ID */
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 客户id */
            @Excel(name = "客户id")
    @ApiModelProperty(value = "客户id")
    private Long customerId;

    /** vin码 */
            @Excel(name = "vin码")
    @ApiModelProperty(value = "vin码")
    private String vin;

    /** 类型(0:公交车，1:小轿车，2:SUV  数据字典) */
            @Excel(name = "类型(0:公交车，1:小轿车，2:SUV  数据字典)")
    @ApiModelProperty(value = "类型(0:公交车，1:小轿车，2:SUV  数据字典)")
    private Integer vehicleType;

    /** 车辆属性(0:封闭测试(场内)，1:道路测试(场外)，2:示范运营，3:商业文化应用) */
            @Excel(name = "车辆属性(0:封闭测试(场内)，1:道路测试(场外)，2:示范运营，3:商业文化应用)")
    @ApiModelProperty(value = "车辆属性(0:封闭测试(场内)，1:道路测试(场外)，2:示范运营，3:商业文化应用)")
    private Integer vehicleAscription;

    /** 车牌 */
            @Excel(name = "车牌")
    @ApiModelProperty(value = "车牌")
    private String license;

    /** 车辆型号 A4 A6数据字典 */
            @Excel(name = "车辆型号 A4 A6数据字典")
    @ApiModelProperty(value = "车辆型号 A4 A6数据字典")
    private String vehicleModel;

    /** 车辆品牌生产商 */
            @Excel(name = "车辆品牌生产商")
    @ApiModelProperty(value = "车辆品牌生产商")
    private String vehicleBrand;

    /** 车型图片地址 */
            @Excel(name = "车型图片地址")
    @ApiModelProperty(value = "车型图片地址")
    private String vehicleImg;

    /** 是否在测试(0:是；1：否) */
            @Excel(name = "是否在测试(0:是；1：否)")
    @ApiModelProperty(value = "是否在测试(0:是；1：否)")
    private Integer isTest;

    /** 安全员 */
            @Excel(name = "安全员")
    @ApiModelProperty(value = "安全员")
    private Long safetyId;

    /** 操作人 */
            @Excel(name = "操作人")
    @ApiModelProperty(value = "操作人")
    private Integer operator;

    public void setId(Long id)
            {
            this.id = id;
            }

    public Long getId()
            {
            return id;
            }
    public void setCustomerId(Long customerId)
            {
            this.customerId = customerId;
            }

    public Long getCustomerId()
            {
            return customerId;
            }
    public void setVin(String vin)
            {
            this.vin = vin;
            }

    public String getVin()
            {
            return vin;
            }
    public void setVehicleType(Integer vehicleType)
            {
            this.vehicleType = vehicleType;
            }

    public Integer getVehicleType()
            {
            return vehicleType;
            }
    public void setVehicleAscription(Integer vehicleAscription)
            {
            this.vehicleAscription = vehicleAscription;
            }

    public Integer getVehicleAscription()
            {
            return vehicleAscription;
            }
    public void setLicense(String license)
            {
            this.license = license;
            }

    public String getLicense()
            {
            return license;
            }
    public void setVehicleModel(String vehicleModel)
            {
            this.vehicleModel = vehicleModel;
            }

    public String getVehicleModel()
            {
            return vehicleModel;
            }
    public void setVehicleBrand(String vehicleBrand)
            {
            this.vehicleBrand = vehicleBrand;
            }

    public String getVehicleBrand()
            {
            return vehicleBrand;
            }
    public void setVehicleImg(String vehicleImg)
            {
            this.vehicleImg = vehicleImg;
            }

    public String getVehicleImg()
            {
            return vehicleImg;
            }
    public void setIsTest(Integer isTest)
            {
            this.isTest = isTest;
            }

    public Integer getIsTest()
            {
            return isTest;
            }
    public void setSafetyId(Long safetyId)
            {
            this.safetyId = safetyId;
            }

    public Long getSafetyId()
            {
            return safetyId;
            }
    public void setOperator(Integer operator)
            {
            this.operator = operator;
            }

    public Integer getOperator()
            {
            return operator;
            }

@Override
public String toString(){
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id",getId())
            .append("customerId",getCustomerId())
            .append("vin",getVin())
            .append("vehicleType",getVehicleType())
            .append("vehicleAscription",getVehicleAscription())
            .append("license",getLicense())
            .append("vehicleModel",getVehicleModel())
            .append("vehicleBrand",getVehicleBrand())
            .append("vehicleImg",getVehicleImg())
            .append("isTest",getIsTest())
            .append("safetyId",getSafetyId())
            .append("updateTime",getUpdateTime())
            .append("createTime",getCreateTime())
            .append("operator",getOperator())
        .toString();
        }
        }
