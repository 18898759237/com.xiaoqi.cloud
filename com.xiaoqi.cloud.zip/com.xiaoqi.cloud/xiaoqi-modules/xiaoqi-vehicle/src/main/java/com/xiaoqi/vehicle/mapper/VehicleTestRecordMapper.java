package com.xiaoqi.vehicle.mapper;

import java.util.List;
import com.xiaoqi.vehicle.domain.VehicleTestRecord;

/**
 * 车辆行驶记录Mapper接口
 * 
 * @author xiaoqi
 * @date 2023-12-22
 */
public interface VehicleTestRecordMapper 
{
    /**
     * 查询车辆行驶记录
     * 
     * @param id 车辆行驶记录主键
     * @return 车辆行驶记录
     */
    public VehicleTestRecord selectVehicleTestRecordById(Long id);

    /**
     * 查询车辆行驶记录列表
     * 
     * @param vehicleTestRecord 车辆行驶记录
     * @return 车辆行驶记录集合
     */
    public List<VehicleTestRecord> selectVehicleTestRecordList(VehicleTestRecord vehicleTestRecord);

    /**
     * 新增车辆行驶记录
     * 
     * @param vehicleTestRecord 车辆行驶记录
     * @return 结果
     */
    public int insertVehicleTestRecord(VehicleTestRecord vehicleTestRecord);

    /**
     * 修改车辆行驶记录
     * 
     * @param vehicleTestRecord 车辆行驶记录
     * @return 结果
     */
    public int updateVehicleTestRecord(VehicleTestRecord vehicleTestRecord);

    /**
     * 删除车辆行驶记录
     * 
     * @param id 车辆行驶记录主键
     * @return 结果
     */
    public int deleteVehicleTestRecordById(Long id);

    /**
     * 批量删除车辆行驶记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteVehicleTestRecordByIds(Long[] ids);
}
