
## nacos配置文件
````
# spring配置
spring:
 shardingsphere:
    #数据源
    datasource:
      names: ds
      ds:
        type: com.alibaba.druid.pool.DruidDataSource
        driver-class-name: com.mysql.cj.jdbc.Driver
        url: jdbc:mysql://192.168.136.130:3306/xiaoqi_vehicle?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=false&serverTimezone=GMT%2B8
        username: root
        password: xiaoqi
    sharding:
      tables:
        vehicle_test_record:
          # 配置数据节点，这里是按月分表，时间范围设置在202201 ~ 202412
          actual-data-nodes: ds.vehicle_test_record_$->{2022..2024}_0$->{1..9}, ds.vehicle_test_record_$->{2022..2024}_1$->{0..2}
          # 指定vehicle_test_record表的主键生成策略为SNOWFLAKE
          key-generator:
            column: recod_time
            type: SNOWFLAKE
          # 指定vehicle_test_record表的分片策略，分片策略包括分片键和分片算法
          table-strategy:
            standard:
              sharding-column: recod_time
              range-algorithm-class-name: com.xiaoqi.shardjdbc.config.MonthShardingAlgorithm
              precise-algorithm-class-name: com.xiaoqi.shardjdbc.config.MonthShardingAlgorithm
# mybatis配置
mybatis:
    # 搜索指定包别名
    typeAliasesPackage: com.xiaoqi.shardjdbc
    # 配置mapper的扫描，找到所有的mapper.xml映射文件
    mapperLocations: classpath:mapper/**/*.xml

# swagger配置
swagger:
  title: shardjdbc模块接口文档
  license: Powered By xiaoqi
  licenseUrl: https://xiaoqi.vip
````
## 注意事项
````
# 以下配置与shardingsphere数据源冲突,application-dev.yml已经配置可以不用配置,若没引用到application-dev.yml配置文件,则需要添加以下配置
spring:
  autoconfigure:
    exclude: com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceAutoConfigure
````
