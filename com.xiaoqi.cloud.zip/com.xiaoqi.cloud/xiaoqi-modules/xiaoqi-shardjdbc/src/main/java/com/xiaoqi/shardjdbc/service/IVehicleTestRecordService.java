package com.xiaoqi.shardjdbc.service;



import com.xiaoqi.shardjdbc.domain.VehicleTestRecord;

import java.util.List;

/**
 * 车辆行驶记录Service接口
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
public interface IVehicleTestRecordService
{
    /**
     * 查询车辆行驶记录
     *
     * @param id 车辆行驶记录主键
     * @return 车辆行驶记录
     */
    public VehicleTestRecord selectVehicleTestRecordById(Long id);

    /**
     * 查询车辆行驶记录列表
     *
     * @param vehicleTestRecord 车辆行驶记录
     * @return 车辆行驶记录集合
     */
    public List<VehicleTestRecord> selectVehicleTestRecordList(VehicleTestRecord vehicleTestRecord);

    /**
     * 新增车辆行驶记录
     *
     * @param vehicleTestRecord 车辆行驶记录
     * @return 结果
     */
    public int insertVehicleTestRecord(VehicleTestRecord vehicleTestRecord);

    /**
     * 修改车辆行驶记录
     *
     * @param vehicleTestRecord 车辆行驶记录
     * @return 结果
     */
    public int updateVehicleTestRecord(VehicleTestRecord vehicleTestRecord);

    /**
     * 批量删除车辆行驶记录
     *
     * @param ids 需要删除的车辆行驶记录主键集合
     * @return 结果
     */
    public int deleteVehicleTestRecordByIds(Long[] ids);

    /**
     * 删除车辆行驶记录信息
     *
     * @param id 车辆行驶记录主键
     * @return 结果
     */
    public int deleteVehicleTestRecordById(Long id);
}
