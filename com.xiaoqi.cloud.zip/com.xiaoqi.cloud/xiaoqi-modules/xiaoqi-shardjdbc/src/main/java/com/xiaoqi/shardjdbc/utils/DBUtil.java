package com.xiaoqi.shardjdbc.utils;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.xiaoqi.common.core.utils.SpringUtils;
import org.springframework.core.env.Environment;

import java.sql.*;
import java.util.Map;
import java.util.Set;

public class DBUtil {

    private static final Map<String, Set<String>> tableMap = Maps.newConcurrentMap();
    /**
     * 数据库连接地址
     */
    private final static String env_url = "spring.shardingsphere.datasource.ds.url";
    /**
     * 数据库驱动
     */
    private final static String env_driver_class_name = "spring.shardingsphere.datasource.ds.driver-class-name";

    /**
     * 用户
     */
    private final static String env_user = "spring.shardingsphere.datasource.ds.username";

    /**
     * 密码
     */
    private final static String env_password = "spring.shardingsphere.datasource.ds.password";

    /**
     * 初始化分表缓存
     *
     * @param logicTableName
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    private static void init(String logicTableName) throws SQLException, ClassNotFoundException {


        Set<String> tableSet = Sets.newHashSet();
        Connection connection = getConnection();
        //sql查询语句
        String sql = "select TABLE_NAME from information_schema.tables where TABLE_NAME like '%#{tableName}%'";
        sql = sql.replace("#{tableName}", logicTableName);
        System.out.println("执行语句:" + sql);
        Statement statement = connection.createStatement();
        //执行查询语句
        ResultSet resultSet = statement.executeQuery(sql);
        //结果遍历
        while (resultSet.next()) {
            Object TABLE_NAME = resultSet.getObject("TABLE_NAME");
            tableSet.add(TABLE_NAME.toString());
        }
        tableMap.put(logicTableName, tableSet);
        //关闭资源
        resultSet.close();
        statement.close();
        connection.close();
    }

    /**
     * 判断分表是否存在
     *
     * @param tableName 分表名称
     * @return
     */
    public static synchronized void checkTable(String logicTableName, String tableName) throws SQLException, ClassNotFoundException {

        Set<String> tableSet = tableMap.get(logicTableName);
        if (tableSet == null || tableSet.size() == 0) {
            init(logicTableName);
            tableSet = tableMap.get(logicTableName);
        }
        for (String vo : tableSet) {
            if (vo.equals(tableName)) {
                return;
            }
        }
        // 表不存在则创建
        createTable(tableName);
        tableSet.add(tableName);
    }

    /**
     * 创建数据库
     *
     * @param tableName 不存在的分表名称
     * @return
     */
    private static boolean createTable(String tableName) throws SQLException, ClassNotFoundException {

        String sql = "CREATE TABLE  #{tableName} (\n" +
                "          `id` bigint(28) NOT NULL,\n" +
                "          `customer_name` varchar(255) DEFAULT NULL COMMENT '客户名称',\n" +
                "          `vin` varchar(255) DEFAULT NULL COMMENT '车辆vin码',\n" +
                "          `time_stamp` bigint(20) DEFAULT NULL COMMENT '时间戳',\n" +
                "          `ignition_status` int(11) DEFAULT '0' COMMENT '0：熄火,1：点火',\n" +
                "          `driving_mode` int(11) DEFAULT NULL COMMENT '0：手动,1：自动',\n" +
                "          `total_mileage` decimal(18,2) DEFAULT NULL COMMENT '总里程km',\n" +
                "          `record_range` decimal(18,2) DEFAULT NULL COMMENT '续航里程km',\n" +
                "          `speed` decimal(18,2) DEFAULT NULL COMMENT '车速km/h',\n" +
                "          `steering_wheel_angle` decimal(18,2) DEFAULT NULL COMMENT '方向盘角度',\n" +
                "          `steering_wheel_torque` varchar(255) DEFAULT NULL COMMENT '方向盘扭矩',\n" +
                "          `gear` varchar(255) DEFAULT NULL COMMENT '挡位0：N/P,1：D,2：R',\n" +
                "          `accelerator_pedal_opening` decimal(18,2) DEFAULT NULL COMMENT '油门踏板开度',\n" +
                "          `brake_pedal_opening` decimal(18,2) DEFAULT NULL COMMENT '制动踏板开度',\n" +
                "          `cornering_lamp` decimal(18,2) DEFAULT NULL COMMENT '转向灯,0：无转向灯,1：左转向灯开,2：右转向灯开',\n" +
                "          `acceleration` decimal(18,2) DEFAULT NULL COMMENT '加速度,m/s2',\n" +
                "          `stoplight` varchar(255) DEFAULT NULL COMMENT '刹车灯',\n" +
                "          `gps_validity` int(11) DEFAULT NULL COMMENT 'GPS有效性,0：有效,1：无效',\n" +
                "          `gps_longitude` decimal(18,8) DEFAULT NULL COMMENT 'GPS经度',\n" +
                "          `gps_latitude` decimal(18,8) DEFAULT NULL COMMENT 'GPS纬度',\n" +
                "          `gps_heading_angle` decimal(18,8) DEFAULT NULL COMMENT 'f方向盘航向角',\n" +
                "          `gps_acceleration` decimal(18,8) DEFAULT NULL COMMENT 'GPS加速度',\n" +
                "          `recod_time` datetime DEFAULT NULL COMMENT '时间',\n" +
                "          `break_light` int(11) DEFAULT '0' COMMENT '制动灯',\n" +
                "          `takeover_type` int(11) DEFAULT '0' COMMENT '提示接管类型，0：无提示  1：交通阻塞',\n" +
                "          PRIMARY KEY (`id`),\n" +
                "          KEY `index_vin_recod_time` (`recod_time`,`vin`),\n" +
                "          KEY `index_time_stamp` (`time_stamp`) USING BTREE\n" +
                "    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车辆行驶记录'";

        sql = sql.replace("#{tableName}", tableName);
        Connection connection = getConnection();
        Statement statement = connection.createStatement();
        //执行查询语句
        boolean status = statement.execute(sql);
        //关闭资源
        statement.close();
        connection.close();
        return status;
    }

    /**
     * jdbc获取数据库连接,绕开shardingsphere
     *
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    private static Connection getConnection() throws ClassNotFoundException, SQLException {

        Environment environment = SpringUtils.getBean(Environment.class);
        String url = environment.getProperty(env_url);
        String driverClassName = environment.getProperty(env_driver_class_name);
        String user = environment.getProperty(env_user);
        String password = environment.getProperty(env_password);
        //加载驱动
        Class.forName(driverClassName);
        Connection connection = DriverManager.getConnection(url, user, password);
        return connection;
    }

}
