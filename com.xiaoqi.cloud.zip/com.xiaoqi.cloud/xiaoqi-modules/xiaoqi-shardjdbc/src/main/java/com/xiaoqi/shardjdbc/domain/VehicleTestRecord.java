package com.xiaoqi.shardjdbc.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.xiaoqi.common.core.annotation.Excel;
import com.xiaoqi.common.core.web.domain.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 车辆行驶记录对象 vehicle_test_record
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@ApiModel(value = "车辆行驶记录")
@Data
public class VehicleTestRecord extends BaseEntity
{
    private static final long serialVersionUID=1L;

    /** $column.columnComment */
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 客户名称 */
    @Excel(name = "客户名称")
    @ApiModelProperty(value = "客户名称")
    private String customerName;

    /** 车辆vin码 */
    @Excel(name = "车辆vin码")
    @ApiModelProperty(value = "车辆vin码")
    private String vin;

    /** 时间戳 */
    @Excel(name = "时间戳")
    @ApiModelProperty(value = "时间戳")
    private Long timeStamp;

    /** 0：熄火,1：点火 */
    @Excel(name = "0：熄火,1：点火")
    @ApiModelProperty(value = "0：熄火,1：点火")
    private Long ignitionStatus;

    /** 0：手动,1：自动 */
    @Excel(name = "0：手动,1：自动")
    @ApiModelProperty(value = "0：手动,1：自动")
    private Long drivingMode;

    /** 总里程km */
    @Excel(name = "总里程km")
    @ApiModelProperty(value = "总里程km")
    private Long totalMileage;

    /** 续航里程km */
    @Excel(name = "续航里程km")
    @ApiModelProperty(value = "续航里程km")
    private Long recordRange;

    /** 车速km/h */
    @Excel(name = "车速km/h")
    @ApiModelProperty(value = "车速km/h")
    private Long speed;

    /** 方向盘角度 */
    @Excel(name = "方向盘角度")
    @ApiModelProperty(value = "方向盘角度")
    private Long steeringWheelAngle;

    /** 方向盘扭矩 */
    @Excel(name = "方向盘扭矩")
    @ApiModelProperty(value = "方向盘扭矩")
    private String steeringWheelTorque;

    /** 挡位0：N/P,1：D,2：R */
    @Excel(name = "挡位0：N/P,1：D,2：R")
    @ApiModelProperty(value = "挡位0：N/P,1：D,2：R")
    private String gear;

    /** 油门踏板开度 */
    @Excel(name = "油门踏板开度")
    @ApiModelProperty(value = "油门踏板开度")
    private Long acceleratorPedalOpening;

    /** 制动踏板开度 */
    @Excel(name = "制动踏板开度")
    @ApiModelProperty(value = "制动踏板开度")
    private Long brakePedalOpening;

    /** 转向灯,0：无转向灯,1：左转向灯开,2：右转向灯开 */
    @Excel(name = "转向灯,0：无转向灯,1：左转向灯开,2：右转向灯开")
    @ApiModelProperty(value = "转向灯,0：无转向灯,1：左转向灯开,2：右转向灯开")
    private Long corneringLamp;

    /** 加速度,m/s2 */
    @Excel(name = "加速度,m/s2")
    @ApiModelProperty(value = "加速度,m/s2")
    private Long acceleration;

    /** 刹车灯 */
    @Excel(name = "刹车灯")
    @ApiModelProperty(value = "刹车灯")
    private String stoplight;

    /** GPS有效性,0：有效,1：无效 */
    @Excel(name = "GPS有效性,0：有效,1：无效")
    @ApiModelProperty(value = "GPS有效性,0：有效,1：无效")
    private Long gpsValidity;

    /** GPS经度 */
    @Excel(name = "GPS经度")
    @ApiModelProperty(value = "GPS经度")
    private Long gpsLongitude;

    /** GPS纬度 */
    @Excel(name = "GPS纬度")
    @ApiModelProperty(value = "GPS纬度")
    private Long gpsLatitude;

    /** f方向盘航向角 */
    @Excel(name = "f方向盘航向角")
    @ApiModelProperty(value = "f方向盘航向角")
    private Long gpsHeadingAngle;

    /** GPS加速度 */
    @Excel(name = "GPS加速度")
    @ApiModelProperty(value = "GPS加速度")
    private Long gpsAcceleration;

    /** 时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "时间", width = 30, dateFormat = "yyyy-MM-dd")
    @ApiModelProperty(value = "时间")
    private Date recodTime;

    /** 制动灯 */
    @Excel(name = "制动灯")
    @ApiModelProperty(value = "制动灯")
    private Long breakLight;

    /** 提示接管类型，0：无提示  1：交通阻塞 */
    @Excel(name = "提示接管类型，0：无提示  1：交通阻塞")
    @ApiModelProperty(value = "提示接管类型，0：无提示  1：交通阻塞")
    private Long takeoverType;

}
