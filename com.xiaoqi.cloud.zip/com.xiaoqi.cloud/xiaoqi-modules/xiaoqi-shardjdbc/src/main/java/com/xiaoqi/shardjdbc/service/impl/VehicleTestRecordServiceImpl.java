package com.xiaoqi.shardjdbc.service.impl;


import com.xiaoqi.shardjdbc.domain.VehicleTestRecord;
import com.xiaoqi.shardjdbc.mapper.VehicleTestRecordMapper;
import com.xiaoqi.shardjdbc.service.IVehicleTestRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * 车辆行驶记录Service业务层处理
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@Service
public class VehicleTestRecordServiceImpl implements IVehicleTestRecordService
{
    @Autowired
    private VehicleTestRecordMapper vehicleTestRecordMapper;

    /**
     * 查询车辆行驶记录
     *
     * @param id 车辆行驶记录主键
     * @return 车辆行驶记录
     */
    @Override
    public VehicleTestRecord selectVehicleTestRecordById(Long id)
    {
        return vehicleTestRecordMapper.selectVehicleTestRecordById(id);
    }

    /**
     * 查询车辆行驶记录列表
     *
     * @param vehicleTestRecord 车辆行驶记录
     * @return 车辆行驶记录
     */
    @Override
    public List<VehicleTestRecord> selectVehicleTestRecordList(VehicleTestRecord vehicleTestRecord)
    {
        return vehicleTestRecordMapper.selectVehicleTestRecordList(vehicleTestRecord);
    }

    /**
     * 新增车辆行驶记录
     *
     * @param vehicleTestRecord 车辆行驶记录
     * @return 结果
     */
    @Override
    public int insertVehicleTestRecord(VehicleTestRecord vehicleTestRecord)
    {
        return vehicleTestRecordMapper.insertVehicleTestRecord(vehicleTestRecord);
    }

    /**
     * 修改车辆行驶记录
     *
     * @param vehicleTestRecord 车辆行驶记录
     * @return 结果
     */
    @Override
    public int updateVehicleTestRecord(VehicleTestRecord vehicleTestRecord)
    {
        return vehicleTestRecordMapper.updateVehicleTestRecord(vehicleTestRecord);
    }

    /**
     * 批量删除车辆行驶记录
     *
     * @param ids 需要删除的车辆行驶记录主键
     * @return 结果
     */
    @Override
    public int deleteVehicleTestRecordByIds(Long[] ids)
    {
        return vehicleTestRecordMapper.deleteVehicleTestRecordByIds(ids);
    }

    /**
     * 删除车辆行驶记录信息
     *
     * @param id 车辆行驶记录主键
     * @return 结果
     */
    @Override
    public int deleteVehicleTestRecordById(Long id)
    {
        return vehicleTestRecordMapper.deleteVehicleTestRecordById(id);
    }


}
