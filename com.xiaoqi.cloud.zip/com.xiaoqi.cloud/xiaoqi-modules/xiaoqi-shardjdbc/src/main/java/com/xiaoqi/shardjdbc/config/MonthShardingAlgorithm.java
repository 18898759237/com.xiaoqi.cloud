package com.xiaoqi.shardjdbc.config;

import cn.hutool.core.date.DateUtil;
import com.google.common.collect.Range;
import com.xiaoqi.shardjdbc.utils.DBUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingValue;
import org.apache.shardingsphere.api.sharding.standard.RangeShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.standard.RangeShardingValue;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import static com.xiaoqi.shardjdbc.utils.DBUtil.checkTable;

/**
 * 按年-Vin复合分表
 */
@Slf4j
public class MonthShardingAlgorithm implements PreciseShardingAlgorithm, RangeShardingAlgorithm<Timestamp> {


    /**
     * 精确命中
     *
     * @param availableTargetNames
     * @param shardingValue
     * @return
     */
    @SneakyThrows
    @Override
    public String doSharding(Collection availableTargetNames, PreciseShardingValue shardingValue) {

        String logicTableName = shardingValue.getLogicTableName();
        // 按时间构建分表名称
        String value = shardingValue.getValue().toString();
        Date date = DateUtil.parseDate(value);
        String tableName = getTableName(date, logicTableName);
        for (Object table : availableTargetNames) {
            if (table.toString().equals(tableName)) {
                checkTable(logicTableName, tableName);
                return tableName;
            }
        }
        log.error("分表:{}不在分表策略范围内!", tableName);
        return null;
    }

    /**
     * 范围命中
     *
     * @param availableTargetNames
     * @param shardingValue
     * @return
     */
    @SneakyThrows
    @Override
    public Collection<String> doSharding(Collection<String> availableTargetNames, RangeShardingValue<Timestamp> shardingValue) {

        String logicTableName = shardingValue.getLogicTableName();

        Collection<String> availables = new ArrayList<>();

        Range valueRange = shardingValue.getValueRange();

        for (String target : availableTargetNames) {
            if (valueRange.hasLowerBound() && valueRange.hasUpperBound()) {
                Date lowerDate = DateUtil.parseDate(shardingValue.getValueRange().lowerEndpoint().toString());
                Date upperDate = DateUtil.parseDate(shardingValue.getValueRange().upperEndpoint().toString());
                Date tableDate = DateUtil.parse(target.replace(logicTableName + "_", ""), "yyyy_MM");
                // 一月的开始时间
                tableDate = DateUtil.beginOfMonth(tableDate);
                if (tableDate.getTime() >= lowerDate.getTime() && tableDate.getTime() <= upperDate.getTime()) {
                    availables.add(target);
                }
            }
        }
        // 没命中,扫所有分表
        return availables.size() == 0 ? availableTargetNames : availables;
    }

    /**
     * 按时间平均分表名称
     *
     * @param date           时间
     * @param logicTableName 表名
     * @return
     */
    private String getTableName(Date date, String logicTableName) {

        // 按时间构建分表名称
        int year = DateUtil.year(date);
        int month = DateUtil.month(date) + 1;
        String monthStr = month > 9 ? month + "" : "0".concat(month + "");
        String tableName = logicTableName + "_" + year + "_" + monthStr;
        return tableName;
    }
}
