package com.xiaoqi.shardjdbc.config;

import cn.hutool.core.date.DateUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Range;
import com.xiaoqi.shardjdbc.utils.DBUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.shardingsphere.api.sharding.complex.ComplexKeysShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.complex.ComplexKeysShardingValue;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * 按年-Vin复合分表
 */
@Slf4j
public class YearComplexAlgorithm implements ComplexKeysShardingAlgorithm<Date> {


    /**
     * 复合查询
     * -- vin = 'LTIC08871524F10920'  columnNameAndShardingValuesMap命中, columnNameAndRangeValuesMap为空;
     * <p>
     * -- recodTime BETWEEN ? AND ? columnNameAndShardingValuesMap为空, columnNameAndRangeValuesMap命中;
     * <p>
     * -- vin = 'LTIC08871524F10920' and recodTime BETWEEN ? AND ?  columnNameAndShardingValuesMap命中, columnNameAndRangeValuesMap命中;
     * <p>
     * -- vin = 'LTIC08871524F10920' and recodTime BETWEEN ?, 范围查询,只有一半; columnNameAndShardingValuesMap命中, columnNameAndRangeValuesMap为空;
     * <p>
     * -- recodTime BETWEEN ?, 不命中,不走此分表策略
     *
     * @param availableTargetNames 分表配置中所有表
     * @param shardingValue        命中字段
     * @return
     */
    @SneakyThrows
    @Override
    public Collection<String> doSharding(Collection availableTargetNames, ComplexKeysShardingValue shardingValue) {

        // 分表名称样例 vehicle_test_record_2023_vin_5

        // 逻辑表名称, 如 vehicle_test_record
        String logicTableName = shardingValue.getLogicTableName();
        //实现精确匹配, 等于或者in的值
        String vin = "";
        String recodTime = "";
        Map shardingMap = shardingValue.getColumnNameAndShardingValuesMap();
        if (shardingMap != null && shardingMap.size() > 0) {
            Object vinList = shardingMap.get("vin");
            Object recodTimeList = shardingMap.get("recod_time");
            if (vinList != null && ((List) vinList).size() > 0) {
                vin = ((List) vinList).get(0).toString();
            }
            if (recodTimeList != null && ((List) recodTimeList).size() > 0) {
                recodTime = ((List) recodTimeList).get(0).toString();
            }
        }

        // 实现  >，>=, <=，<  和 BETWEEN AND 等操作 的值
        Range range = null;
        Map rangeMap = shardingValue.getColumnNameAndRangeValuesMap();
        if (rangeMap != null && rangeMap.size() > 0) {
            range = (Range) rangeMap.get("recod_time");
        }

        // 将Collection<Object>转成List<String>
        List<String> tableList = Lists.newArrayList();
        availableTargetNames.stream().forEach(vo -> {
            tableList.add(vo.toString());
        });

        // range过滤
        List<String> rangeList = selectTableByRange(tableList, logicTableName, range);

        // vin过滤
        List<String> vinList = selectTableByVin(rangeList, logicTableName, vin);

        // recodTime过滤
        List<String> timeList = selectTableByRecodTime(vinList, logicTableName, recodTime);

        for (String table : timeList) {
            DBUtil.checkTable(logicTableName, table);
        }
        return timeList.size() == 0 ? tableList : timeList;

    }

    /**
     * 筛选要命中的表
     *
     * @param tableList      所有表
     * @param logicTableName 原始表名
     * @param range          recod_time 时间范围
     * @return
     */
    private List<String> selectTableByRange(List<String> tableList, String logicTableName, Range range) {

        // range为空,不处理
        if (null == range) {
            return tableList;
        }
        List<String> rangeList = Lists.newArrayList();

        Date lowerDate = DateUtil.parseDate(range.lowerEndpoint().toString());
        Date upperDate = DateUtil.parseDate(range.upperEndpoint().toString());
        for (String table : tableList) {
            String[] logic = table.replace(logicTableName.concat("_"), "").split("_");
            Date tableDate = DateUtil.parseDate(logic[0].concat("-01").concat("-01"));
            tableDate = DateUtil.beginOfMonth(tableDate);
            if (tableDate.getTime() >= lowerDate.getTime() && tableDate.getTime() <= upperDate.getTime()) {
                rangeList.add(table);
            }
        }
        return rangeList.size() == 0 ? tableList : rangeList;
    }


    /**
     * 筛选要命中的表
     *
     * @param tableList      所有表
     * @param logicTableName 原始表名
     * @param vin            车辆vin码(精确匹配)
     * @return
     */
    private List<String> selectTableByVin(List<String> tableList, String logicTableName, String vin) {

        // vin为空,不处理
        if (StringUtils.isEmpty(vin)) {
            return tableList;
        }
        // recodTime精准时间筛选基础上进行vin精确筛选
        List<String> vinList = Lists.newArrayList();
        // vin哈希处理之后可能为负数
        Integer vinNum = ((vin.hashCode() & Integer.MAX_VALUE) % 10) + 1;
        for (String table : tableList) {
            String[] logic = table.replace(logicTableName.concat("_"), "").split("_");
            Integer vinIndex = Integer.parseInt(logic[2]);
            if (vinNum == vinIndex) {
                vinList.add(table);
            }
        }
        return vinList.size() == 0 ? tableList : vinList;
    }

    /**
     * 筛选要命中的表
     *
     * @param tableList      所有表
     * @param logicTableName 原始表名
     * @param recodTime      时间(精确匹配)
     * @return
     */
    private List<String> selectTableByRecodTime(List<String> tableList, String logicTableName, String recodTime) {

        // recodTime为空,不处理
        if (StringUtils.isEmpty(recodTime)) {
            return tableList;
        }
        // 范围删选基础上进行recodTime精准时间筛选
        List<String> recodTimeList = Lists.newArrayList();
        Date date = DateUtil.parseDate(recodTime);
        Integer month = DateUtil.month(date) + 1;
        String tableName = logicTableName.concat("_").concat(DateUtil.year(date) + "");
        for (String table : tableList) {
            if (table.contains(tableName)) {
                recodTimeList.add(table);
            }
        }
        return recodTimeList.size() == 0 ? tableList : recodTimeList;
    }
}
