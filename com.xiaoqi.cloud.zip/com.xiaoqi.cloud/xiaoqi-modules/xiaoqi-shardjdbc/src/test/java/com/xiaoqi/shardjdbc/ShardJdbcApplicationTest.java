package com.xiaoqi.shardjdbc;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.RandomUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.xiaoqi.common.core.utils.uuid.IdGenerater;
import com.xiaoqi.shardjdbc.domain.VehicleTestRecord;
import com.xiaoqi.shardjdbc.service.IVehicleTestRecordService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.List;
import java.util.Map;

@SpringBootTest
@Slf4j
public class ShardJdbcApplicationTest {
    @Autowired
    private IVehicleTestRecordService vehicleTestRecordService;
    public static List<Map<String, String>> vinList = Lists.newArrayList();


    @Before
    public void testBefore() throws InterruptedException {
        Map<String, String> map1 = Maps.newHashMap();
        map1.put("vin", "LFPHC7PEXM1B14885");
        map1.put("customerName", "百度");
        vinList.add(map1);
        Map<String, String> map2 = Maps.newHashMap();
        map2.put("vin", "LFPHC7PE0M1B15110");
        map2.put("customerName", "小马");
        vinList.add(map2);
        Map<String, String> map3 = Maps.newHashMap();
        map3.put("vin", "LFPHC7PE1M1B14712");
        map3.put("customerName", "AutoX");
        vinList.add(map3);
        Map<String, String> map4 = Maps.newHashMap();
        map4.put("vin", "LFPHC7PE2M1B14668");
        map4.put("customerName", "比亚迪");
        vinList.add(map4);
    }

    @Test
    public void testShardJdbc() throws InterruptedException {
        testBefore();
        int m = 0;
        while (m < 1000) {
            VehicleTestRecord record = new VehicleTestRecord();

            record.setId(IdGenerater.getInstance().nextId());
            record.setVin(vinList.get(RandomUtil.randomInt(0, 4)).get("vin"));
            record.setCustomerName(vinList.get(RandomUtil.randomInt(0, 4)).get("customerName"));
            record.setDrivingMode(RandomUtil.randomLong(0, 2));
            record.setSpeed(RandomUtil.randomLong(20, 60));
            record.setTotalMileage(RandomUtil.randomLong(20, 60));
            record.setRecodTime(DateUtil.offsetDay(new Date(), RandomUtil.randomInt(0, 365 * 2) * (-1)));
            vehicleTestRecordService.insertVehicleTestRecord(record);

            m++;
        }

    }
}
