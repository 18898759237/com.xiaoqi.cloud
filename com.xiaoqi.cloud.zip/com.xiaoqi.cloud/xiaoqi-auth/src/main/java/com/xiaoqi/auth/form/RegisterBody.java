package com.xiaoqi.auth.form;

/**
 * 用户注册对象
 * 
 * @author xiaoqi
 */
public class RegisterBody extends LoginBody
{

}
