/*
Navicat MySQL Data Transfer

Source Server         : 小七虚拟机-130
Source Server Version : 50616
Source Host           : 192.168.136.130:3306
Source Database       : xiaoqi_cloud

Target Server Type    : MYSQL
Target Server Version : 50616
File Encoding         : 65001

Date: 2024-01-06 23:39:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for gen_table
-- ----------------------------
DROP TABLE IF EXISTS `gen_table`;
CREATE TABLE `gen_table` (
  `table_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_name` varchar(200) DEFAULT '' COMMENT '表名称',
  `table_comment` varchar(500) DEFAULT '' COMMENT '表描述',
  `sub_table_name` varchar(64) DEFAULT NULL COMMENT '关联子表的表名',
  `sub_table_fk_name` varchar(64) DEFAULT NULL COMMENT '子表关联的外键名',
  `class_name` varchar(100) DEFAULT '' COMMENT '实体类名称',
  `tpl_category` varchar(200) DEFAULT 'crud' COMMENT '使用的模板（crud单表操作 tree树表操作）',
  `tpl_web_type` varchar(30) DEFAULT '' COMMENT '前端模板类型（element-ui模版 element-plus模版）',
  `package_name` varchar(100) DEFAULT NULL COMMENT '生成包路径',
  `module_name` varchar(30) DEFAULT NULL COMMENT '生成模块名',
  `business_name` varchar(30) DEFAULT NULL COMMENT '生成业务名',
  `function_name` varchar(50) DEFAULT NULL COMMENT '生成功能名',
  `function_author` varchar(50) DEFAULT NULL COMMENT '生成功能作者',
  `gen_type` char(1) DEFAULT '0' COMMENT '生成代码方式（0zip压缩包 1自定义路径）',
  `gen_path` varchar(200) DEFAULT '/' COMMENT '生成路径（不填默认项目路径）',
  `options` varchar(1000) DEFAULT NULL COMMENT '其它生成选项',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`table_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='代码生成业务表';

-- ----------------------------
-- Records of gen_table
-- ----------------------------

-- ----------------------------
-- Table structure for gen_table_column
-- ----------------------------
DROP TABLE IF EXISTS `gen_table_column`;
CREATE TABLE `gen_table_column` (
  `column_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_id` bigint(20) DEFAULT NULL COMMENT '归属表编号',
  `column_name` varchar(200) DEFAULT NULL COMMENT '列名称',
  `column_comment` varchar(500) DEFAULT NULL COMMENT '列描述',
  `column_type` varchar(100) DEFAULT NULL COMMENT '列类型',
  `java_type` varchar(500) DEFAULT NULL COMMENT 'JAVA类型',
  `java_field` varchar(200) DEFAULT NULL COMMENT 'JAVA字段名',
  `is_pk` char(1) DEFAULT NULL COMMENT '是否主键（1是）',
  `is_increment` char(1) DEFAULT NULL COMMENT '是否自增（1是）',
  `is_required` char(1) DEFAULT NULL COMMENT '是否必填（1是）',
  `is_insert` char(1) DEFAULT NULL COMMENT '是否为插入字段（1是）',
  `is_edit` char(1) DEFAULT NULL COMMENT '是否编辑字段（1是）',
  `is_list` char(1) DEFAULT NULL COMMENT '是否列表字段（1是）',
  `is_query` char(1) DEFAULT NULL COMMENT '是否查询字段（1是）',
  `query_type` varchar(200) DEFAULT 'EQ' COMMENT '查询方式（等于、不等于、大于、小于、范围）',
  `html_type` varchar(200) DEFAULT NULL COMMENT '显示类型（文本框、文本域、下拉框、复选框、单选框、日期控件）',
  `dict_type` varchar(200) DEFAULT '' COMMENT '字典类型',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`column_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='代码生成业务表字段';

-- ----------------------------
-- Records of gen_table_column
-- ----------------------------

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `config_id` int(5) NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `config_name` varchar(100) DEFAULT '' COMMENT '参数名称',
  `config_key` varchar(100) DEFAULT '' COMMENT '参数键名',
  `config_value` varchar(500) DEFAULT '' COMMENT '参数键值',
  `config_type` char(1) DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='参数配置表';

-- ----------------------------
-- Records of sys_config
-- ----------------------------
INSERT INTO `sys_config` VALUES ('1', '主框架页-默认皮肤样式名称', 'sys.index.skinName', 'skin-blue', 'Y', 'admin', '2024-01-06 21:59:38', '', null, '蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow');
INSERT INTO `sys_config` VALUES ('2', '用户管理-账号初始密码', 'sys.user.initPassword', '123456', 'Y', 'admin', '2024-01-06 21:59:38', '', null, '初始化密码 123456');
INSERT INTO `sys_config` VALUES ('3', '主框架页-侧边栏主题', 'sys.index.sideTheme', 'theme-dark', 'Y', 'admin', '2024-01-06 21:59:38', '', null, '深色主题theme-dark，浅色主题theme-light');
INSERT INTO `sys_config` VALUES ('4', '账号自助-是否开启用户注册功能', 'sys.account.registerUser', 'false', 'Y', 'admin', '2024-01-06 21:59:38', '', null, '是否开启注册用户功能（true开启，false关闭）');
INSERT INTO `sys_config` VALUES ('5', '用户登录-黑名单列表', 'sys.login.blackIPList', '', 'Y', 'admin', '2024-01-06 21:59:38', '', null, '设置登录IP黑名单限制，多个匹配项以;分隔，支持匹配（*通配、网段）');

-- ----------------------------
-- Table structure for sys_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_dept`;
CREATE TABLE `sys_dept` (
  `dept_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `parent_id` bigint(20) DEFAULT '0' COMMENT '父部门id',
  `ancestors` varchar(50) DEFAULT '' COMMENT '祖级列表',
  `dept_name` varchar(30) DEFAULT '' COMMENT '部门名称',
  `order_num` int(4) DEFAULT '0' COMMENT '显示顺序',
  `leader` varchar(20) DEFAULT NULL COMMENT '负责人',
  `phone` varchar(11) DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `status` char(1) DEFAULT '0' COMMENT '部门状态（0正常 1停用）',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8 COMMENT='部门表';

-- ----------------------------
-- Records of sys_dept
-- ----------------------------
INSERT INTO `sys_dept` VALUES ('100', '0', '0', '若依科技', '0', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('101', '100', '0,100', '深圳总公司', '1', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('102', '100', '0,100', '长沙分公司', '2', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('103', '101', '0,100,101', '研发部门', '1', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('104', '101', '0,100,101', '市场部门', '2', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('105', '101', '0,100,101', '测试部门', '3', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('106', '101', '0,100,101', '财务部门', '4', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('107', '101', '0,100,101', '运维部门', '5', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('108', '102', '0,100,102', '市场部门', '1', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);
INSERT INTO `sys_dept` VALUES ('109', '102', '0,100,102', '财务部门', '2', '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2024-01-06 21:59:34', '', null);

-- ----------------------------
-- Table structure for sys_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data` (
  `dict_code` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int(4) DEFAULT '0' COMMENT '字典排序',
  `dict_label` varchar(100) DEFAULT '' COMMENT '字典标签',
  `dict_value` varchar(100) DEFAULT '' COMMENT '字典键值',
  `dict_type` varchar(100) DEFAULT '' COMMENT '字典类型',
  `css_class` varchar(100) DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='字典数据表';

-- ----------------------------
-- Records of sys_dict_data
-- ----------------------------
INSERT INTO `sys_dict_data` VALUES ('1', '1', '男', '0', 'sys_user_sex', '', '', 'Y', '0', 'admin', '2024-01-06 21:59:38', '', null, '性别男');
INSERT INTO `sys_dict_data` VALUES ('2', '2', '女', '1', 'sys_user_sex', '', '', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '性别女');
INSERT INTO `sys_dict_data` VALUES ('3', '3', '未知', '2', 'sys_user_sex', '', '', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '性别未知');
INSERT INTO `sys_dict_data` VALUES ('4', '1', '显示', '0', 'sys_show_hide', '', 'primary', 'Y', '0', 'admin', '2024-01-06 21:59:38', '', null, '显示菜单');
INSERT INTO `sys_dict_data` VALUES ('5', '2', '隐藏', '1', 'sys_show_hide', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '隐藏菜单');
INSERT INTO `sys_dict_data` VALUES ('6', '1', '正常', '0', 'sys_normal_disable', '', 'primary', 'Y', '0', 'admin', '2024-01-06 21:59:38', '', null, '正常状态');
INSERT INTO `sys_dict_data` VALUES ('7', '2', '停用', '1', 'sys_normal_disable', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '停用状态');
INSERT INTO `sys_dict_data` VALUES ('8', '1', '正常', '0', 'sys_job_status', '', 'primary', 'Y', '0', 'admin', '2024-01-06 21:59:38', '', null, '正常状态');
INSERT INTO `sys_dict_data` VALUES ('9', '2', '暂停', '1', 'sys_job_status', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '停用状态');
INSERT INTO `sys_dict_data` VALUES ('10', '1', '默认', 'DEFAULT', 'sys_job_group', '', '', 'Y', '0', 'admin', '2024-01-06 21:59:38', '', null, '默认分组');
INSERT INTO `sys_dict_data` VALUES ('11', '2', '系统', 'SYSTEM', 'sys_job_group', '', '', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '系统分组');
INSERT INTO `sys_dict_data` VALUES ('12', '1', '是', 'Y', 'sys_yes_no', '', 'primary', 'Y', '0', 'admin', '2024-01-06 21:59:38', '', null, '系统默认是');
INSERT INTO `sys_dict_data` VALUES ('13', '2', '否', 'N', 'sys_yes_no', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '系统默认否');
INSERT INTO `sys_dict_data` VALUES ('14', '1', '通知', '1', 'sys_notice_type', '', 'warning', 'Y', '0', 'admin', '2024-01-06 21:59:38', '', null, '通知');
INSERT INTO `sys_dict_data` VALUES ('15', '2', '公告', '2', 'sys_notice_type', '', 'success', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '公告');
INSERT INTO `sys_dict_data` VALUES ('16', '1', '正常', '0', 'sys_notice_status', '', 'primary', 'Y', '0', 'admin', '2024-01-06 21:59:38', '', null, '正常状态');
INSERT INTO `sys_dict_data` VALUES ('17', '2', '关闭', '1', 'sys_notice_status', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '关闭状态');
INSERT INTO `sys_dict_data` VALUES ('18', '99', '其他', '0', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '其他操作');
INSERT INTO `sys_dict_data` VALUES ('19', '1', '新增', '1', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '新增操作');
INSERT INTO `sys_dict_data` VALUES ('20', '2', '修改', '2', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '修改操作');
INSERT INTO `sys_dict_data` VALUES ('21', '3', '删除', '3', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '删除操作');
INSERT INTO `sys_dict_data` VALUES ('22', '4', '授权', '4', 'sys_oper_type', '', 'primary', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '授权操作');
INSERT INTO `sys_dict_data` VALUES ('23', '5', '导出', '5', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '导出操作');
INSERT INTO `sys_dict_data` VALUES ('24', '6', '导入', '6', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '导入操作');
INSERT INTO `sys_dict_data` VALUES ('25', '7', '强退', '7', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '强退操作');
INSERT INTO `sys_dict_data` VALUES ('26', '8', '生成代码', '8', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '生成操作');
INSERT INTO `sys_dict_data` VALUES ('27', '9', '清空数据', '9', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '清空操作');
INSERT INTO `sys_dict_data` VALUES ('28', '1', '成功', '0', 'sys_common_status', '', 'primary', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '正常状态');
INSERT INTO `sys_dict_data` VALUES ('29', '2', '失败', '1', 'sys_common_status', '', 'danger', 'N', '0', 'admin', '2024-01-06 21:59:38', '', null, '停用状态');

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type` (
  `dict_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) DEFAULT '' COMMENT '字典名称',
  `dict_type` varchar(100) DEFAULT '' COMMENT '字典类型',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`),
  UNIQUE KEY `dict_type` (`dict_type`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='字典类型表';

-- ----------------------------
-- Records of sys_dict_type
-- ----------------------------
INSERT INTO `sys_dict_type` VALUES ('1', '用户性别', 'sys_user_sex', '0', 'admin', '2024-01-06 21:59:37', '', null, '用户性别列表');
INSERT INTO `sys_dict_type` VALUES ('2', '菜单状态', 'sys_show_hide', '0', 'admin', '2024-01-06 21:59:37', '', null, '菜单状态列表');
INSERT INTO `sys_dict_type` VALUES ('3', '系统开关', 'sys_normal_disable', '0', 'admin', '2024-01-06 21:59:37', '', null, '系统开关列表');
INSERT INTO `sys_dict_type` VALUES ('4', '任务状态', 'sys_job_status', '0', 'admin', '2024-01-06 21:59:37', '', null, '任务状态列表');
INSERT INTO `sys_dict_type` VALUES ('5', '任务分组', 'sys_job_group', '0', 'admin', '2024-01-06 21:59:37', '', null, '任务分组列表');
INSERT INTO `sys_dict_type` VALUES ('6', '系统是否', 'sys_yes_no', '0', 'admin', '2024-01-06 21:59:37', '', null, '系统是否列表');
INSERT INTO `sys_dict_type` VALUES ('7', '通知类型', 'sys_notice_type', '0', 'admin', '2024-01-06 21:59:37', '', null, '通知类型列表');
INSERT INTO `sys_dict_type` VALUES ('8', '通知状态', 'sys_notice_status', '0', 'admin', '2024-01-06 21:59:37', '', null, '通知状态列表');
INSERT INTO `sys_dict_type` VALUES ('9', '操作类型', 'sys_oper_type', '0', 'admin', '2024-01-06 21:59:38', '', null, '操作类型列表');
INSERT INTO `sys_dict_type` VALUES ('10', '系统状态', 'sys_common_status', '0', 'admin', '2024-01-06 21:59:38', '', null, '登录状态列表');

-- ----------------------------
-- Table structure for sys_job
-- ----------------------------
DROP TABLE IF EXISTS `sys_job`;
CREATE TABLE `sys_job` (
  `job_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `job_name` varchar(64) NOT NULL DEFAULT '' COMMENT '任务名称',
  `job_group` varchar(64) NOT NULL DEFAULT 'DEFAULT' COMMENT '任务组名',
  `invoke_target` varchar(500) NOT NULL COMMENT '调用目标字符串',
  `cron_expression` varchar(255) DEFAULT '' COMMENT 'cron执行表达式',
  `misfire_policy` varchar(20) DEFAULT '3' COMMENT '计划执行错误策略（1立即执行 2执行一次 3放弃执行）',
  `concurrent` char(1) DEFAULT '1' COMMENT '是否并发执行（0允许 1禁止）',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1暂停）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT '' COMMENT '备注信息',
  PRIMARY KEY (`job_id`,`job_name`,`job_group`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='定时任务调度表';

-- ----------------------------
-- Records of sys_job
-- ----------------------------
INSERT INTO `sys_job` VALUES ('1', '系统默认（无参）', 'DEFAULT', 'ryTask.ryNoParams', '0/10 * * * * ?', '3', '1', '1', 'admin', '2024-01-06 21:59:38', '', null, '');
INSERT INTO `sys_job` VALUES ('2', '系统默认（有参）', 'DEFAULT', 'ryTask.ryParams(\'ry\')', '0/15 * * * * ?', '3', '1', '1', 'admin', '2024-01-06 21:59:38', '', null, '');
INSERT INTO `sys_job` VALUES ('3', '系统默认（多参）', 'DEFAULT', 'ryTask.ryMultipleParams(\'ry\', true, 2000L, 316.50D, 100)', '0/20 * * * * ?', '3', '1', '1', 'admin', '2024-01-06 21:59:38', '', null, '');

-- ----------------------------
-- Table structure for sys_job_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_job_log`;
CREATE TABLE `sys_job_log` (
  `job_log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务日志ID',
  `job_name` varchar(64) NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) NOT NULL COMMENT '任务组名',
  `invoke_target` varchar(500) NOT NULL COMMENT '调用目标字符串',
  `job_message` varchar(500) DEFAULT NULL COMMENT '日志信息',
  `status` char(1) DEFAULT '0' COMMENT '执行状态（0正常 1失败）',
  `exception_info` varchar(2000) DEFAULT '' COMMENT '异常信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定时任务调度日志表';

-- ----------------------------
-- Records of sys_job_log
-- ----------------------------

-- ----------------------------
-- Table structure for sys_logininfor
-- ----------------------------
DROP TABLE IF EXISTS `sys_logininfor`;
CREATE TABLE `sys_logininfor` (
  `info_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `user_name` varchar(50) DEFAULT '' COMMENT '用户账号',
  `ipaddr` varchar(128) DEFAULT '' COMMENT '登录IP地址',
  `status` char(1) DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) DEFAULT '' COMMENT '提示信息',
  `access_time` datetime DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`),
  KEY `idx_sys_logininfor_s` (`status`),
  KEY `idx_sys_logininfor_lt` (`access_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统访问记录';

-- ----------------------------
-- Records of sys_logininfor
-- ----------------------------
INSERT INTO `sys_logininfor` VALUES ('1', 'admin', '192.168.136.1', '0', '登录成功', '2024-01-06 23:32:17');

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) NOT NULL COMMENT '菜单名称',
  `parent_id` bigint(20) DEFAULT '0' COMMENT '父菜单ID',
  `order_num` int(4) DEFAULT '0' COMMENT '显示顺序',
  `path` varchar(200) DEFAULT '' COMMENT '路由地址',
  `component` varchar(255) DEFAULT NULL COMMENT '组件路径',
  `query` varchar(255) DEFAULT NULL COMMENT '路由参数',
  `is_frame` int(1) DEFAULT '1' COMMENT '是否为外链（0是 1否）',
  `is_cache` int(1) DEFAULT '0' COMMENT '是否缓存（0缓存 1不缓存）',
  `menu_type` char(1) DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `status` char(1) DEFAULT '0' COMMENT '菜单状态（0正常 1停用）',
  `perms` varchar(100) DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1061 DEFAULT CHARSET=utf8 COMMENT='菜单权限表';

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES ('1', '系统管理', '0', '1', 'system', null, '', '1', '0', 'M', '0', '0', '', 'system', 'admin', '2024-01-06 21:59:34', '', null, '系统管理目录');
INSERT INTO `sys_menu` VALUES ('2', '系统监控', '0', '2', 'monitor', null, '', '1', '0', 'M', '0', '0', '', 'monitor', 'admin', '2024-01-06 21:59:34', '', null, '系统监控目录');
INSERT INTO `sys_menu` VALUES ('3', '系统工具', '0', '3', 'tool', null, '', '1', '0', 'M', '0', '0', '', 'tool', 'admin', '2024-01-06 21:59:34', '', null, '系统工具目录');
INSERT INTO `sys_menu` VALUES ('4', '若依官网', '0', '4', 'http://xiaoqi.vip', null, '', '0', '0', 'M', '0', '0', '', 'guide', 'admin', '2024-01-06 21:59:34', '', null, '若依官网地址');
INSERT INTO `sys_menu` VALUES ('100', '用户管理', '1', '1', 'user', 'system/user/index', '', '1', '0', 'C', '0', '0', 'system:user:list', 'user', 'admin', '2024-01-06 21:59:34', '', null, '用户管理菜单');
INSERT INTO `sys_menu` VALUES ('101', '角色管理', '1', '2', 'role', 'system/role/index', '', '1', '0', 'C', '0', '0', 'system:role:list', 'peoples', 'admin', '2024-01-06 21:59:34', '', null, '角色管理菜单');
INSERT INTO `sys_menu` VALUES ('102', '菜单管理', '1', '3', 'menu', 'system/menu/index', '', '1', '0', 'C', '0', '0', 'system:menu:list', 'tree-table', 'admin', '2024-01-06 21:59:34', '', null, '菜单管理菜单');
INSERT INTO `sys_menu` VALUES ('103', '部门管理', '1', '4', 'dept', 'system/dept/index', '', '1', '0', 'C', '0', '0', 'system:dept:list', 'tree', 'admin', '2024-01-06 21:59:34', '', null, '部门管理菜单');
INSERT INTO `sys_menu` VALUES ('104', '岗位管理', '1', '5', 'post', 'system/post/index', '', '1', '0', 'C', '0', '0', 'system:post:list', 'post', 'admin', '2024-01-06 21:59:34', '', null, '岗位管理菜单');
INSERT INTO `sys_menu` VALUES ('105', '字典管理', '1', '6', 'dict', 'system/dict/index', '', '1', '0', 'C', '0', '0', 'system:dict:list', 'dict', 'admin', '2024-01-06 21:59:34', '', null, '字典管理菜单');
INSERT INTO `sys_menu` VALUES ('106', '参数设置', '1', '7', 'config', 'system/config/index', '', '1', '0', 'C', '0', '0', 'system:config:list', 'edit', 'admin', '2024-01-06 21:59:34', '', null, '参数设置菜单');
INSERT INTO `sys_menu` VALUES ('107', '通知公告', '1', '8', 'notice', 'system/notice/index', '', '1', '0', 'C', '0', '0', 'system:notice:list', 'message', 'admin', '2024-01-06 21:59:34', '', null, '通知公告菜单');
INSERT INTO `sys_menu` VALUES ('108', '日志管理', '1', '9', 'log', '', '', '1', '0', 'M', '0', '0', '', 'log', 'admin', '2024-01-06 21:59:34', '', null, '日志管理菜单');
INSERT INTO `sys_menu` VALUES ('109', '在线用户', '2', '1', 'online', 'monitor/online/index', '', '1', '0', 'C', '0', '0', 'monitor:online:list', 'online', 'admin', '2024-01-06 21:59:34', '', null, '在线用户菜单');
INSERT INTO `sys_menu` VALUES ('110', '定时任务', '2', '2', 'job', 'monitor/job/index', '', '1', '0', 'C', '0', '0', 'monitor:job:list', 'job', 'admin', '2024-01-06 21:59:34', '', null, '定时任务菜单');
INSERT INTO `sys_menu` VALUES ('111', 'Sentinel控制台', '2', '3', 'http://localhost:8718', '', '', '0', '0', 'C', '0', '0', 'monitor:sentinel:list', 'sentinel', 'admin', '2024-01-06 21:59:34', '', null, '流量控制菜单');
INSERT INTO `sys_menu` VALUES ('112', 'Nacos控制台', '2', '4', 'http://localhost:8848/nacos', '', '', '0', '0', 'C', '0', '0', 'monitor:nacos:list', 'nacos', 'admin', '2024-01-06 21:59:34', '', null, '服务治理菜单');
INSERT INTO `sys_menu` VALUES ('113', 'Admin控制台', '2', '5', 'http://localhost:9100/login', '', '', '0', '0', 'C', '0', '0', 'monitor:server:list', 'server', 'admin', '2024-01-06 21:59:34', '', null, '服务监控菜单');
INSERT INTO `sys_menu` VALUES ('114', '表单构建', '3', '1', 'build', 'tool/build/index', '', '1', '0', 'C', '0', '0', 'tool:build:list', 'build', 'admin', '2024-01-06 21:59:34', '', null, '表单构建菜单');
INSERT INTO `sys_menu` VALUES ('115', '代码生成', '3', '2', 'gen', 'tool/gen/index', '', '1', '0', 'C', '0', '0', 'tool:gen:list', 'code', 'admin', '2024-01-06 21:59:34', '', null, '代码生成菜单');
INSERT INTO `sys_menu` VALUES ('116', '系统接口', '3', '3', 'http://localhost:8080/swagger-ui/index.html', '', '', '0', '0', 'C', '0', '0', 'tool:swagger:list', 'swagger', 'admin', '2024-01-06 21:59:34', '', null, '系统接口菜单');
INSERT INTO `sys_menu` VALUES ('500', '操作日志', '108', '1', 'operlog', 'system/operlog/index', '', '1', '0', 'C', '0', '0', 'system:operlog:list', 'form', 'admin', '2024-01-06 21:59:34', '', null, '操作日志菜单');
INSERT INTO `sys_menu` VALUES ('501', '登录日志', '108', '2', 'logininfor', 'system/logininfor/index', '', '1', '0', 'C', '0', '0', 'system:logininfor:list', 'logininfor', 'admin', '2024-01-06 21:59:34', '', null, '登录日志菜单');
INSERT INTO `sys_menu` VALUES ('1000', '用户查询', '100', '1', '', '', '', '1', '0', 'F', '0', '0', 'system:user:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1001', '用户新增', '100', '2', '', '', '', '1', '0', 'F', '0', '0', 'system:user:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1002', '用户修改', '100', '3', '', '', '', '1', '0', 'F', '0', '0', 'system:user:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1003', '用户删除', '100', '4', '', '', '', '1', '0', 'F', '0', '0', 'system:user:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1004', '用户导出', '100', '5', '', '', '', '1', '0', 'F', '0', '0', 'system:user:export', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1005', '用户导入', '100', '6', '', '', '', '1', '0', 'F', '0', '0', 'system:user:import', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1006', '重置密码', '100', '7', '', '', '', '1', '0', 'F', '0', '0', 'system:user:resetPwd', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1007', '角色查询', '101', '1', '', '', '', '1', '0', 'F', '0', '0', 'system:role:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1008', '角色新增', '101', '2', '', '', '', '1', '0', 'F', '0', '0', 'system:role:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1009', '角色修改', '101', '3', '', '', '', '1', '0', 'F', '0', '0', 'system:role:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1010', '角色删除', '101', '4', '', '', '', '1', '0', 'F', '0', '0', 'system:role:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1011', '角色导出', '101', '5', '', '', '', '1', '0', 'F', '0', '0', 'system:role:export', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1012', '菜单查询', '102', '1', '', '', '', '1', '0', 'F', '0', '0', 'system:menu:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1013', '菜单新增', '102', '2', '', '', '', '1', '0', 'F', '0', '0', 'system:menu:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1014', '菜单修改', '102', '3', '', '', '', '1', '0', 'F', '0', '0', 'system:menu:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1015', '菜单删除', '102', '4', '', '', '', '1', '0', 'F', '0', '0', 'system:menu:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1016', '部门查询', '103', '1', '', '', '', '1', '0', 'F', '0', '0', 'system:dept:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1017', '部门新增', '103', '2', '', '', '', '1', '0', 'F', '0', '0', 'system:dept:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1018', '部门修改', '103', '3', '', '', '', '1', '0', 'F', '0', '0', 'system:dept:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1019', '部门删除', '103', '4', '', '', '', '1', '0', 'F', '0', '0', 'system:dept:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1020', '岗位查询', '104', '1', '', '', '', '1', '0', 'F', '0', '0', 'system:post:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1021', '岗位新增', '104', '2', '', '', '', '1', '0', 'F', '0', '0', 'system:post:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1022', '岗位修改', '104', '3', '', '', '', '1', '0', 'F', '0', '0', 'system:post:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1023', '岗位删除', '104', '4', '', '', '', '1', '0', 'F', '0', '0', 'system:post:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1024', '岗位导出', '104', '5', '', '', '', '1', '0', 'F', '0', '0', 'system:post:export', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1025', '字典查询', '105', '1', '#', '', '', '1', '0', 'F', '0', '0', 'system:dict:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1026', '字典新增', '105', '2', '#', '', '', '1', '0', 'F', '0', '0', 'system:dict:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1027', '字典修改', '105', '3', '#', '', '', '1', '0', 'F', '0', '0', 'system:dict:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1028', '字典删除', '105', '4', '#', '', '', '1', '0', 'F', '0', '0', 'system:dict:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1029', '字典导出', '105', '5', '#', '', '', '1', '0', 'F', '0', '0', 'system:dict:export', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1030', '参数查询', '106', '1', '#', '', '', '1', '0', 'F', '0', '0', 'system:config:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1031', '参数新增', '106', '2', '#', '', '', '1', '0', 'F', '0', '0', 'system:config:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1032', '参数修改', '106', '3', '#', '', '', '1', '0', 'F', '0', '0', 'system:config:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1033', '参数删除', '106', '4', '#', '', '', '1', '0', 'F', '0', '0', 'system:config:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1034', '参数导出', '106', '5', '#', '', '', '1', '0', 'F', '0', '0', 'system:config:export', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1035', '公告查询', '107', '1', '#', '', '', '1', '0', 'F', '0', '0', 'system:notice:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1036', '公告新增', '107', '2', '#', '', '', '1', '0', 'F', '0', '0', 'system:notice:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1037', '公告修改', '107', '3', '#', '', '', '1', '0', 'F', '0', '0', 'system:notice:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1038', '公告删除', '107', '4', '#', '', '', '1', '0', 'F', '0', '0', 'system:notice:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1039', '操作查询', '500', '1', '#', '', '', '1', '0', 'F', '0', '0', 'system:operlog:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1040', '操作删除', '500', '2', '#', '', '', '1', '0', 'F', '0', '0', 'system:operlog:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1041', '日志导出', '500', '3', '#', '', '', '1', '0', 'F', '0', '0', 'system:operlog:export', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1042', '登录查询', '501', '1', '#', '', '', '1', '0', 'F', '0', '0', 'system:logininfor:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1043', '登录删除', '501', '2', '#', '', '', '1', '0', 'F', '0', '0', 'system:logininfor:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1044', '日志导出', '501', '3', '#', '', '', '1', '0', 'F', '0', '0', 'system:logininfor:export', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1045', '账户解锁', '501', '4', '#', '', '', '1', '0', 'F', '0', '0', 'system:logininfor:unlock', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1046', '在线查询', '109', '1', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:online:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1047', '批量强退', '109', '2', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:online:batchLogout', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1048', '单条强退', '109', '3', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:online:forceLogout', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1049', '任务查询', '110', '1', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:job:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1050', '任务新增', '110', '2', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:job:add', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1051', '任务修改', '110', '3', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:job:edit', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1052', '任务删除', '110', '4', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:job:remove', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1053', '状态修改', '110', '5', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:job:changeStatus', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1054', '任务导出', '110', '6', '#', '', '', '1', '0', 'F', '0', '0', 'monitor:job:export', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1055', '生成查询', '115', '1', '#', '', '', '1', '0', 'F', '0', '0', 'tool:gen:query', '#', 'admin', '2024-01-06 21:59:35', '', null, '');
INSERT INTO `sys_menu` VALUES ('1056', '生成修改', '115', '2', '#', '', '', '1', '0', 'F', '0', '0', 'tool:gen:edit', '#', 'admin', '2024-01-06 21:59:36', '', null, '');
INSERT INTO `sys_menu` VALUES ('1057', '生成删除', '115', '3', '#', '', '', '1', '0', 'F', '0', '0', 'tool:gen:remove', '#', 'admin', '2024-01-06 21:59:36', '', null, '');
INSERT INTO `sys_menu` VALUES ('1058', '导入代码', '115', '2', '#', '', '', '1', '0', 'F', '0', '0', 'tool:gen:import', '#', 'admin', '2024-01-06 21:59:36', '', null, '');
INSERT INTO `sys_menu` VALUES ('1059', '预览代码', '115', '4', '#', '', '', '1', '0', 'F', '0', '0', 'tool:gen:preview', '#', 'admin', '2024-01-06 21:59:36', '', null, '');
INSERT INTO `sys_menu` VALUES ('1060', '生成代码', '115', '5', '#', '', '', '1', '0', 'F', '0', '0', 'tool:gen:code', '#', 'admin', '2024-01-06 21:59:36', '', null, '');

-- ----------------------------
-- Table structure for sys_notice
-- ----------------------------
DROP TABLE IF EXISTS `sys_notice`;
CREATE TABLE `sys_notice` (
  `notice_id` int(4) NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `notice_title` varchar(50) NOT NULL COMMENT '公告标题',
  `notice_type` char(1) NOT NULL COMMENT '公告类型（1通知 2公告）',
  `notice_content` longblob COMMENT '公告内容',
  `status` char(1) DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='通知公告表';

-- ----------------------------
-- Records of sys_notice
-- ----------------------------
INSERT INTO `sys_notice` VALUES ('1', '温馨提醒：2018-07-01 若依新版本发布啦', '2', 0xE696B0E78988E69CACE58685E5AEB9, '0', 'admin', '2024-01-06 21:59:38', '', null, '管理员');
INSERT INTO `sys_notice` VALUES ('2', '维护通知：2018-07-01 若依系统凌晨维护', '1', 0xE7BBB4E68AA4E58685E5AEB9, '0', 'admin', '2024-01-06 21:59:38', '', null, '管理员');

-- ----------------------------
-- Table structure for sys_oper_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_oper_log`;
CREATE TABLE `sys_oper_log` (
  `oper_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50) DEFAULT '' COMMENT '模块标题',
  `business_type` int(2) DEFAULT '0' COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100) DEFAULT '' COMMENT '方法名称',
  `request_method` varchar(10) DEFAULT '' COMMENT '请求方式',
  `operator_type` int(1) DEFAULT '0' COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) DEFAULT '' COMMENT '操作人员',
  `dept_name` varchar(50) DEFAULT '' COMMENT '部门名称',
  `oper_url` varchar(255) DEFAULT '' COMMENT '请求URL',
  `oper_ip` varchar(128) DEFAULT '' COMMENT '主机地址',
  `oper_location` varchar(255) DEFAULT '' COMMENT '操作地点',
  `oper_param` varchar(2000) DEFAULT '' COMMENT '请求参数',
  `json_result` varchar(2000) DEFAULT '' COMMENT '返回参数',
  `status` int(1) DEFAULT '0' COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000) DEFAULT '' COMMENT '错误消息',
  `oper_time` datetime DEFAULT NULL COMMENT '操作时间',
  `cost_time` bigint(20) DEFAULT '0' COMMENT '消耗时间',
  PRIMARY KEY (`oper_id`),
  KEY `idx_sys_oper_log_bt` (`business_type`),
  KEY `idx_sys_oper_log_s` (`status`),
  KEY `idx_sys_oper_log_ot` (`oper_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作日志记录';

-- ----------------------------
-- Records of sys_oper_log
-- ----------------------------

-- ----------------------------
-- Table structure for sys_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_post`;
CREATE TABLE `sys_post` (
  `post_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `post_code` varchar(64) NOT NULL COMMENT '岗位编码',
  `post_name` varchar(50) NOT NULL COMMENT '岗位名称',
  `post_sort` int(4) NOT NULL COMMENT '显示顺序',
  `status` char(1) NOT NULL COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='岗位信息表';

-- ----------------------------
-- Records of sys_post
-- ----------------------------
INSERT INTO `sys_post` VALUES ('1', 'ceo', '董事长', '1', '0', 'admin', '2024-01-06 21:59:34', '', null, '');
INSERT INTO `sys_post` VALUES ('2', 'se', '项目经理', '2', '0', 'admin', '2024-01-06 21:59:34', '', null, '');
INSERT INTO `sys_post` VALUES ('3', 'hr', '人力资源', '3', '0', 'admin', '2024-01-06 21:59:34', '', null, '');
INSERT INTO `sys_post` VALUES ('4', 'user', '普通员工', '4', '0', 'admin', '2024-01-06 21:59:34', '', null, '');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(30) NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) NOT NULL COMMENT '角色权限字符串',
  `role_sort` int(4) NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限 3：本部门数据权限 4：本部门及以下数据权限）',
  `menu_check_strictly` tinyint(1) DEFAULT '1' COMMENT '菜单树选择项是否关联显示',
  `dept_check_strictly` tinyint(1) DEFAULT '1' COMMENT '部门树选择项是否关联显示',
  `status` char(1) NOT NULL COMMENT '角色状态（0正常 1停用）',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='角色信息表';

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES ('1', '超级管理员', 'admin', '1', '1', '1', '1', '0', '0', 'admin', '2024-01-06 21:59:34', '', null, '超级管理员');
INSERT INTO `sys_role` VALUES ('2', '普通角色', 'common', '2', '2', '1', '1', '0', '0', 'admin', '2024-01-06 21:59:34', '', null, '普通角色');

-- ----------------------------
-- Table structure for sys_role_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_dept`;
CREATE TABLE `sys_role_dept` (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `dept_id` bigint(20) NOT NULL COMMENT '部门ID',
  PRIMARY KEY (`role_id`,`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色和部门关联表';

-- ----------------------------
-- Records of sys_role_dept
-- ----------------------------
INSERT INTO `sys_role_dept` VALUES ('2', '100');
INSERT INTO `sys_role_dept` VALUES ('2', '101');
INSERT INTO `sys_role_dept` VALUES ('2', '105');

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu` (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `menu_id` bigint(20) NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色和菜单关联表';

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES ('2', '1');
INSERT INTO `sys_role_menu` VALUES ('2', '2');
INSERT INTO `sys_role_menu` VALUES ('2', '3');
INSERT INTO `sys_role_menu` VALUES ('2', '4');
INSERT INTO `sys_role_menu` VALUES ('2', '100');
INSERT INTO `sys_role_menu` VALUES ('2', '101');
INSERT INTO `sys_role_menu` VALUES ('2', '102');
INSERT INTO `sys_role_menu` VALUES ('2', '103');
INSERT INTO `sys_role_menu` VALUES ('2', '104');
INSERT INTO `sys_role_menu` VALUES ('2', '105');
INSERT INTO `sys_role_menu` VALUES ('2', '106');
INSERT INTO `sys_role_menu` VALUES ('2', '107');
INSERT INTO `sys_role_menu` VALUES ('2', '108');
INSERT INTO `sys_role_menu` VALUES ('2', '109');
INSERT INTO `sys_role_menu` VALUES ('2', '110');
INSERT INTO `sys_role_menu` VALUES ('2', '111');
INSERT INTO `sys_role_menu` VALUES ('2', '112');
INSERT INTO `sys_role_menu` VALUES ('2', '113');
INSERT INTO `sys_role_menu` VALUES ('2', '114');
INSERT INTO `sys_role_menu` VALUES ('2', '115');
INSERT INTO `sys_role_menu` VALUES ('2', '116');
INSERT INTO `sys_role_menu` VALUES ('2', '500');
INSERT INTO `sys_role_menu` VALUES ('2', '501');
INSERT INTO `sys_role_menu` VALUES ('2', '1000');
INSERT INTO `sys_role_menu` VALUES ('2', '1001');
INSERT INTO `sys_role_menu` VALUES ('2', '1002');
INSERT INTO `sys_role_menu` VALUES ('2', '1003');
INSERT INTO `sys_role_menu` VALUES ('2', '1004');
INSERT INTO `sys_role_menu` VALUES ('2', '1005');
INSERT INTO `sys_role_menu` VALUES ('2', '1006');
INSERT INTO `sys_role_menu` VALUES ('2', '1007');
INSERT INTO `sys_role_menu` VALUES ('2', '1008');
INSERT INTO `sys_role_menu` VALUES ('2', '1009');
INSERT INTO `sys_role_menu` VALUES ('2', '1010');
INSERT INTO `sys_role_menu` VALUES ('2', '1011');
INSERT INTO `sys_role_menu` VALUES ('2', '1012');
INSERT INTO `sys_role_menu` VALUES ('2', '1013');
INSERT INTO `sys_role_menu` VALUES ('2', '1014');
INSERT INTO `sys_role_menu` VALUES ('2', '1015');
INSERT INTO `sys_role_menu` VALUES ('2', '1016');
INSERT INTO `sys_role_menu` VALUES ('2', '1017');
INSERT INTO `sys_role_menu` VALUES ('2', '1018');
INSERT INTO `sys_role_menu` VALUES ('2', '1019');
INSERT INTO `sys_role_menu` VALUES ('2', '1020');
INSERT INTO `sys_role_menu` VALUES ('2', '1021');
INSERT INTO `sys_role_menu` VALUES ('2', '1022');
INSERT INTO `sys_role_menu` VALUES ('2', '1023');
INSERT INTO `sys_role_menu` VALUES ('2', '1024');
INSERT INTO `sys_role_menu` VALUES ('2', '1025');
INSERT INTO `sys_role_menu` VALUES ('2', '1026');
INSERT INTO `sys_role_menu` VALUES ('2', '1027');
INSERT INTO `sys_role_menu` VALUES ('2', '1028');
INSERT INTO `sys_role_menu` VALUES ('2', '1029');
INSERT INTO `sys_role_menu` VALUES ('2', '1030');
INSERT INTO `sys_role_menu` VALUES ('2', '1031');
INSERT INTO `sys_role_menu` VALUES ('2', '1032');
INSERT INTO `sys_role_menu` VALUES ('2', '1033');
INSERT INTO `sys_role_menu` VALUES ('2', '1034');
INSERT INTO `sys_role_menu` VALUES ('2', '1035');
INSERT INTO `sys_role_menu` VALUES ('2', '1036');
INSERT INTO `sys_role_menu` VALUES ('2', '1037');
INSERT INTO `sys_role_menu` VALUES ('2', '1038');
INSERT INTO `sys_role_menu` VALUES ('2', '1039');
INSERT INTO `sys_role_menu` VALUES ('2', '1040');
INSERT INTO `sys_role_menu` VALUES ('2', '1041');
INSERT INTO `sys_role_menu` VALUES ('2', '1042');
INSERT INTO `sys_role_menu` VALUES ('2', '1043');
INSERT INTO `sys_role_menu` VALUES ('2', '1044');
INSERT INTO `sys_role_menu` VALUES ('2', '1045');
INSERT INTO `sys_role_menu` VALUES ('2', '1046');
INSERT INTO `sys_role_menu` VALUES ('2', '1047');
INSERT INTO `sys_role_menu` VALUES ('2', '1048');
INSERT INTO `sys_role_menu` VALUES ('2', '1049');
INSERT INTO `sys_role_menu` VALUES ('2', '1050');
INSERT INTO `sys_role_menu` VALUES ('2', '1051');
INSERT INTO `sys_role_menu` VALUES ('2', '1052');
INSERT INTO `sys_role_menu` VALUES ('2', '1053');
INSERT INTO `sys_role_menu` VALUES ('2', '1054');
INSERT INTO `sys_role_menu` VALUES ('2', '1055');
INSERT INTO `sys_role_menu` VALUES ('2', '1056');
INSERT INTO `sys_role_menu` VALUES ('2', '1057');
INSERT INTO `sys_role_menu` VALUES ('2', '1058');
INSERT INTO `sys_role_menu` VALUES ('2', '1059');
INSERT INTO `sys_role_menu` VALUES ('2', '1060');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `dept_id` bigint(20) DEFAULT NULL COMMENT '部门ID',
  `user_name` varchar(30) NOT NULL COMMENT '用户账号',
  `nick_name` varchar(30) NOT NULL COMMENT '用户昵称',
  `user_type` varchar(2) DEFAULT '00' COMMENT '用户类型（00系统用户）',
  `email` varchar(50) DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) DEFAULT '' COMMENT '手机号码',
  `sex` char(1) DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) DEFAULT '' COMMENT '头像地址',
  `password` varchar(100) DEFAULT '' COMMENT '密码',
  `status` char(1) DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(128) DEFAULT '' COMMENT '最后登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '最后登录时间',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', '103', 'admin', '若依', '00', 'ry@163.com', '15888888888', '1', '', '$2a$10$7JB720yubVSZvUI0rEqK/.VqGOZTH.ulu33dHOiBE8ByOhJIrdAu2', '0', '0', '127.0.0.1', '2024-01-06 21:59:34', 'admin', '2024-01-06 21:59:34', '', null, '管理员');
INSERT INTO `sys_user` VALUES ('2', '105', 'ry', '若依', '00', 'ry@qq.com', '15666666666', '1', '', '$2a$10$7JB720yubVSZvUI0rEqK/.VqGOZTH.ulu33dHOiBE8ByOhJIrdAu2', '0', '0', '127.0.0.1', '2024-01-06 21:59:34', 'admin', '2024-01-06 21:59:34', '', null, '测试员');

-- ----------------------------
-- Table structure for sys_user_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_post`;
CREATE TABLE `sys_user_post` (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `post_id` bigint(20) NOT NULL COMMENT '岗位ID',
  PRIMARY KEY (`user_id`,`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户与岗位关联表';

-- ----------------------------
-- Records of sys_user_post
-- ----------------------------
INSERT INTO `sys_user_post` VALUES ('1', '1');
INSERT INTO `sys_user_post` VALUES ('2', '2');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role` (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户和角色关联表';

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES ('1', '1');
INSERT INTO `sys_user_role` VALUES ('2', '2');

-- ----------------------------
-- Table structure for undo_log
-- ----------------------------
DROP TABLE IF EXISTS `undo_log`;
CREATE TABLE `undo_log` (
  `branch_id` bigint(20) NOT NULL COMMENT 'branch transaction id',
  `xid` varchar(100) NOT NULL COMMENT 'global transaction id',
  `context` varchar(128) NOT NULL COMMENT 'undo_log context,such as serialization',
  `rollback_info` longblob NOT NULL COMMENT 'rollback info',
  `log_status` int(11) NOT NULL COMMENT '0:normal status,1:defense status',
  `log_created` datetime(6) NOT NULL COMMENT 'create datetime',
  `log_modified` datetime(6) NOT NULL COMMENT 'modify datetime',
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AT transaction mode undo table';

-- ----------------------------
-- Records of undo_log
-- ----------------------------

-- ----------------------------
-- Table structure for vehicle_info
-- ----------------------------
DROP TABLE IF EXISTS `vehicle_info`;
CREATE TABLE `vehicle_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `customer_id` int(11) DEFAULT NULL COMMENT '客户id',
  `vin` varchar(32) DEFAULT NULL COMMENT 'vin码',
  `vehicle_type` int(1) DEFAULT '0' COMMENT '类型(0:公交车，1:小轿车，2:SUV  数据字典)',
  `vehicle_ascription` int(1) DEFAULT NULL COMMENT '车辆属性(0:封闭测试(场内)，1:道路测试(场外)，2:示范运营，3:商业文化应用)',
  `license` varchar(32) DEFAULT NULL COMMENT '车牌',
  `vehicle_model` varchar(32) DEFAULT NULL COMMENT '车辆型号 A4 A6数据字典',
  `vehicle_brand` varchar(32) DEFAULT NULL COMMENT '车辆品牌生产商',
  `vehicle_img` varchar(255) DEFAULT NULL COMMENT '车型图片地址',
  `is_test` int(1) DEFAULT NULL COMMENT '是否在测试(0:是；1：否)',
  `safety_id` int(11) DEFAULT NULL COMMENT '安全员',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `operator` int(10) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vin` (`vin`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1418 DEFAULT CHARSET=utf8 COMMENT='测试车辆基础信息';

-- ----------------------------
-- Records of vehicle_info
-- ----------------------------
INSERT INTO `vehicle_info` VALUES ('148', '15', 'LTIC08871524F1092', '5', '0', '湘BN9156', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/9f4edd32f5dd409287363ffeedd8e5cf.png', '1', '36', '2023-03-29 15:44:24', '2021-07-14 16:02:37', '134');
INSERT INTO `vehicle_info` VALUES ('149', '16', 'LAN12345678909888', '1', '0', '粤B23049', '1', '1', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210715/28e7dcc779184193b302334f155a8cba.png', '1', '36', '2021-07-16 11:08:26', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('150', '17', 'LTIC369E27E66W49K', null, '0', '粤B23049', '22', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('151', '18', 'LTIC1QN6302S2W753', '3', '0', '粤B0Z23', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/9ae87a264962414da9488ff8cf9e6944.png', '1', '36', '2021-07-23 11:36:32', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('152', '21', 'LTIC875582V1I4778', null, '0', '粤B0R18', '23', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('153', '22', 'LTIC920S2463DI684', null, '0', '湘BN91561', '24', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('154', '19', 'LTICRY4QB91225K3Y', null, '0', '粤B0Z24', 'x1', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('155', '20', 'LTIC8O2VD2377G3DE', null, '0', '粤B0Z25', 'x2', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('156', '23', 'LTIC6808322I68C5K', null, '0', '湘BN91562', 'x3', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('157', '24', 'LTICDNZ152FS99X12', null, '0', '湘BN91563', 'x4', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('158', '25', 'LTIC65NEKG321H034', null, '0', '湘BN91564', 'x5', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('159', '26', 'LTICN834RY5VWS01Q', null, '0', '湘BN91566', 'x6', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('160', '26', 'LTICO833OK8P31434', null, '0', '湘BN91567', 'x7', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('161', '27', 'LTICTUN24700ES1F9', null, '0', '湘BN91568', 'x8', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('162', '27', 'LTICY581QN32A1731', null, '0', '湘BN91569', 'x9', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('163', '27', 'LTIC3R08QX2J5A3G8', null, '0', '湘BN91570', 'x10', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('164', '28', 'LTICQX4P733I35G19', null, '0', '湘BN91571', 'x11', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('165', '17', 'LTICV0133I1S61G59', null, '0', '湘BN91572', 'x12', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('166', '19', 'LTIC0I4C462564FJ9', null, '0', '湘BN91573', 'x13', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('167', '20', 'LTICA1J8P8539JNGV', null, '0', '湘BN91574', 'x14', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('168', '23', 'LTICH24T45NDI9B65', null, '0', '湘BN91576', 'x15', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('169', '24', 'LTICK775M0VJOL251', null, '0', '湘BN91577', 'x16', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('170', '25', 'LTICRSIR273EKI9XX', null, '0', '湘BN91578', 'x17', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('171', '26', 'LTICP377X28WWMZ68', null, '0', '湘BN91579', 'x18', null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('172', '26', 'LTIC5EWC5Y81ODB18', null, '0', '湘BN91580', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('173', '27', 'LTIC003SSC93YB16P', null, '0', '湘BN91581', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('174', '27', 'LTIC1EQ24S253VD21', null, '0', '湘BN91582', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('175', '27', 'LTIC9P0LU6411E459', null, '0', '湘BN91583', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('176', '28', 'LTICT50RUTC6PX865', null, '0', '湘BN91584', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('177', '17', 'LTIC4YBYXO3K554ZS', null, '0', '湘BN91585', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('178', '19', 'LTICD119O8B96X9VP', null, '0', '湘BN91586', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('179', '20', 'LTIC0HE25HOV38H8W', null, '0', '湘BN91587', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('180', '23', 'LTIC1960R4362B5C6', null, '0', '湘BN91589', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('181', '24', 'LTICD8JV3F4AN2504', null, '0', '湘BN91590', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('182', '25', 'LTIC5S225Y3635H6B', null, '0', '湘BN91591', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('183', '26', 'LTICP9HCVF132YS63', null, '0', '湘BN91592', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('184', '26', 'LTIC00TA3UZ181E4C', null, '0', '湘BN91593', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('185', '27', 'LTIC0323OA6ZKEYNW', null, '0', '湘BN91594', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('186', '27', 'LTIC06V00WO40LT1P', null, '0', '湘BN91595', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('187', '27', 'LTICGQ2AHE24D8M50', null, '0', '湘BN91596', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('188', '28', 'LTIC66525474CQ75J', null, '0', '湘BN91597', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('189', '17', 'LTIC72X230CH9E121', null, '0', '湘BN91598', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('190', '19', 'LTIC699Z4M2459W6R', null, '0', '湘BN91599', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('191', '20', 'LTIC33K45RZ082H49', null, '0', '湘BN91699', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('192', '18', 'LTIC3V118546823O7', '3', '0', '粤B96UIY', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/111d22d04c4545ffb8d9f33a1e6d1295.png', '1', '36', '2021-07-23 14:05:09', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('193', '18', 'LTICCZ223PC7JW19O', '3', '0', '粤B61298', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/3a38a3c1476b4edc87b4979da3403bb3.png', '1', '36', '2021-07-23 14:05:42', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('194', '15', 'LTIC1H59TD7S45S22', '5', '0', '湘BN9155', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/87eff688df4542bc87b270f251e96445.png', '1', '36', '2023-03-29 15:44:20', '2021-07-14 16:02:37', '134');
INSERT INTO `vehicle_info` VALUES ('195', '15', 'LTIC8HLBE5H6BP1LW', null, '0', '湘BM3746', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('196', '18', 'LTIC2X7KZE6VWQ1O1', '3', '0', '粤B97UIY', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/53e5ea0779874626abdac01b2fcf5e08.png', '1', '36', '2021-07-23 14:10:11', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('197', '18', 'LTIC4R07J32H03SQ2', '3', '0', '粤B98UIY', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/fed6a9f37f044400afc7b2caca600710.png', '1', '36', '2021-07-23 14:10:40', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('198', '18', 'LTICMH415827J8G26', '3', '0', '粤B0Z21', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/0a737938ea534752bc497aabd2271d70.png', '1', '36', '2021-07-23 14:10:54', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('199', '18', 'LTIC2K449E9Y9P67U', '3', '0', '粤B0Z22', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/07aa8c6fcf004ab5b12fd1c6fe6e05ca.png', '1', '36', '2021-07-23 14:11:05', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('200', '15', 'LTICA3H4895BF153T', '5', '0', '湘BP4398', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/42b2b4cbd37d415eb112a1e5ba3e5de0.png', '1', '36', '2023-03-29 15:44:11', '2021-07-14 16:02:37', '134');
INSERT INTO `vehicle_info` VALUES ('201', '30', 'LTIC7211128GBUB52', '1', '0', '鄂A F22676', '7', '9', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/1debd9a4997c4c86b8d1196f6e867f88.png', '1', '36', '2021-07-23 14:16:41', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('202', '30', 'LTIC670592630W159', '1', '0', '鄂A F11201', '7', '9', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/f22a9bfc4a964c589a72a1c5970cc867.png', '1', '36', '2021-07-23 14:18:23', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('203', '30', 'LTIC875582V1I1526', '1', '0', '粤A F22765', '11', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/d44ee495e87a49e8bd0c615eb552ace3.png', '1', '36', '2021-07-23 14:21:38', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('204', '30', 'LTICOU08094X70N82', '1', '0', '粤B FD6567', '7', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/32aed67111c24ad2a7dc274d4d77d283.png', '1', '36', '2021-07-23 14:22:41', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('205', '30', 'LTICJF34C1226L54P', '1', '0', '粤B P9094', '7', '10', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/8e241634c359425eaddf7033d98573c7.png', '1', '36', '2021-07-23 14:24:05', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('206', '30', 'LTIC86786K2S44NGX', '1', '0', '鄂A IR632', '7', '9', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/4b9449efa112420ab328373716e93bf6.png', '1', '36', '2021-07-23 14:24:25', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('207', '31', 'LTICAZ01NA95C1102', '1', '0', '粤B 07PJ3', '7', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/58082fe770b54db39bf9b2e06f41d42c.png', '1', '36', '2021-07-23 14:25:46', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('208', '31', 'LTICV1G0S96O6171S', '1', '0', '粤B 79MJ8', '12', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/b97f5e51993c4274bf7deeda410d7eb7.png', '1', '36', '2021-07-23 14:27:02', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('209', '31', 'LTICR5REC346J4222', '1', '0', '粤B 4YY51', '13', '12', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/18810ccde9a24021ac779f8113075163.png', '1', '36', '2021-07-23 14:33:49', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('210', '31', 'LTIC77W32918Q4L33', '1', '0', '粤B U543P', '14', '13', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/10f51d4f77ef4e1fb3b85fa52fd1bb78.png', '1', '36', '2021-07-23 14:34:07', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('211', '31', 'LTIC1Y8W10UG8C7U4', '1', '0', '粤B A79896', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/2e1b551b91f7489683525e2d30fff7f9.png', '1', '36', '2021-07-23 14:34:22', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('212', '31', 'LTIC7UN519169T0J1', '1', '0', '粤B D579T', '7', '15', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/fb6875083ea34127a550d462a2c0747e.png', '1', '36', '2021-07-23 14:34:38', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('213', '18', 'LTICFAQ815W34152O', null, '0', '粤BDZ22', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('214', '32', 'LTIC33G3EG5BS284Q', null, '0', '粤B60BZ6', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('215', '32', 'LTICI56D3641052R3', null, '0', '沪NZ4838', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('216', '32', 'LTICI0KF1ZOZ8U1B3', '1', '0', '粤BT22Y0', '15', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210906/3e427057d0ff43978a4df72d46bcd024.png', '1', '36', '2021-09-06 16:18:51', '2021-07-14 16:02:37', '125');
INSERT INTO `vehicle_info` VALUES ('217', '33', 'LTICN28D7V5S96K3Z', null, '0', '粤B8E36D', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('218', '33', 'LTICXS9428ZH0U42A', null, '0', '粤BN699Q', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('219', '33', 'LNAA33ED45TF00045', '1', '0', '苏EAX436', '3', '3', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210715/505ddb514d7c41cea81131770011f578.png', '1', '36', '2021-07-15 14:52:26', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('220', '32', 'LFPH4BCP4J2L01923', '1', '0', '鄂AF19817', '4', '4', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210715/6bce10149d1a4f83a937850a89bf5a15.png', '1', '36', '2021-07-15 14:53:11', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('221', '18', 'LTIC08871123F1999', null, '0', '粤B0Z23试', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('222', '16', 'LTIC08800011F1888', '1', '0', '粤B0R19', '1', '1', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210716/7f3774469a9941b78b37880ec9378a59.png', '1', '36', '2021-07-16 11:06:28', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('223', '35', 'LGXCE6CB6K0154104', '1', '0', '粤BD54104', '6', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210723/75c7a21e1e984349ae3bcb8c00acdcf5.png', '1', '36', '2021-11-25 10:44:04', '2021-07-14 16:02:37', '127');
INSERT INTO `vehicle_info` VALUES ('224', '16', 'LTIC08860023F2618', '0', '0', '粤B0Z35试', '1', '1', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210716/f442f9c50f624a81914e33b525339690.png', '1', '36', '2021-07-16 11:09:32', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('225', '21', 'LTIC08830025F1986', null, '0', '粤B7V41试', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('226', '15', '2C4RC2J75LR119808', '5', '1', '粤BQC767', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/d75b13cde8894b5c9f3dfee8a7cbd5c3.png', '1', '36', '2021-12-31 09:28:41', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('227', '15', '2C4RC2J75LR119273', null, '0', '粤B19273', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('228', '15', '2C4RC2J71LR119773', '5', '1', '苏G30930', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210914/5027410e3cea49f8b9020823575de155.jpg', '1', '36', '2021-12-06 10:24:26', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('229', '15', 'LTIC08860023B7734', null, '0', '赣B97734', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('230', '15', '2C4RC2J78LR119821', '5', '1', '苏G50518', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210914/ea1e15769bf540ffac3734d9d420b4f5.jpg', '1', '36', '2021-12-06 10:24:03', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('231', '15', 'LTIC0886002B97731', null, '0', '赣B97731', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('232', '15', 'LTIC0886002B97733', null, '0', '赣B97733', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('233', '28', 'LTIC0886002AN58H6', null, '0', '粤AN58H6', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('234', '28', 'LTIC0886002B97293', null, '0', '赣B97293', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('235', '28', 'LTIC0886002DQ2781', null, '0', '粤ADQ2781', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('236', '28', 'LTIC0886002E307FM', null, '0', '鲁E307FM', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('237', '28', 'LTIC0886002A015VE', null, '0', '粤A015VE', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('238', '28', 'LTIC0886002L570UK', null, '0', '粤L570UK', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('239', '28', 'LTIC0886002E8V812', null, '0', '湘E8V812', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('240', '28', 'LTIC0886002W91620', null, '0', '沪W9162试', null, null, null, '1', '36', '2021-07-14 16:02:37', '2021-07-14 16:02:37', '122');
INSERT INTO `vehicle_info` VALUES ('241', '35', 'DZQ12098456790000', '2', '0', '粤T88888', '34', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230627/4a6110501b3448ae916a6ee5eba34bcd.jpg', '1', '36', '2023-06-29 14:49:58', '2021-07-14 16:02:37', '134');
INSERT INTO `vehicle_info` VALUES ('275', '21', 'LGXCE6CC0H0163575', '1', '0', '粤BDE8030', '9', '5', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210716/65ae1b7718034c3b9c5dcbf8fcf7eeab.png', null, '36', '2021-07-22 09:36:37', '2021-07-16 13:58:00', '122');
INSERT INTO `vehicle_info` VALUES ('322', '15', '2C4RC2J77LR119809', '5', '1', '苏G51736', '10', '8', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/10601044832317192.jpg', null, '36', '2021-12-06 10:23:45', '2021-07-27 10:28:57', '122');
INSERT INTO `vehicle_info` VALUES ('323', '21', 'LTIC0886002E8V813', '1', '0', '粤BAN8616', '15', '5', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/9904997310507099.jpg', null, '36', '2021-08-03 14:10:37', '2021-07-19 09:08:25', '126');
INSERT INTO `vehicle_info` VALUES ('324', '21', 'LGXCE6CC2H0138080', '1', '0', '粤BDA6875', '7', '5', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/9910520251855609.jpg', null, '36', '2021-08-03 14:11:09', '2021-07-19 10:40:10', '126');
INSERT INTO `vehicle_info` VALUES ('325', '21', 'LC0C76C41M1007992', '1', '0', '粤B5V33试', '7', '5', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/9910981096496648.jpg', null, '36', '2021-08-03 14:11:23', '2021-07-19 10:48:10', '126');
INSERT INTO `vehicle_info` VALUES ('326', '21', 'LC0CF6CD1M1037139', '1', '0', '粤B5V90试', '7', '5', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/9911042211452681.jpg', null, '36', '2021-08-03 14:11:37', '2021-07-19 10:48:56', '126');
INSERT INTO `vehicle_info` VALUES ('327', '43', 'LB37844Z9JH076252', '1', '0', '粤BT362B', '16', '16', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/10690209105880471.jpg', null, '36', '2021-08-03 14:11:51', '2021-07-28 11:14:59', '126');
INSERT INTO `vehicle_info` VALUES ('328', '43', 'LBELMBKC8EY512549', '1', '0', '粤BN656L', '15', '16', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/10690475645604730.jpg', null, '36', '2021-08-03 14:12:06', '2021-07-28 11:19:26', '126');
INSERT INTO `vehicle_info` VALUES ('329', '43', 'LVHRW1817M7210433', '1', '0', '粤B92UP8', '15', '16', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/10690547449776694.jpg', null, '36', '2021-08-03 14:12:21', '2021-07-28 11:20:38', '126');
INSERT INTO `vehicle_info` VALUES ('337', '43', 'LFPM4ACC8EIA09616', '1', '0', '粤BB33SI', '15', '16', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210730/1ad59da45c85407c98f80ab355f004ad.jpg', null, '36', '2021-07-30 14:47:06', '2021-07-30 14:47:06', '125');
INSERT INTO `vehicle_info` VALUES ('338', '43', 'LC0CE6CD5L1007899', '1', '0', '粤B7W42试', '15', '16', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210730/fcb5750e082946b1bad379b02c57a6b6.jpg', null, '36', '2021-07-30 14:51:54', '2021-07-30 14:51:54', '125');
INSERT INTO `vehicle_info` VALUES ('339', '15', 'LTIC0886002W08999', '1', '0', '粤ADN8999', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/ed059b378de6469087b895aebbc18383.png', null, '36', '2021-08-02 13:42:10', '2021-08-02 13:42:10', '126');
INSERT INTO `vehicle_info` VALUES ('340', '31', 'LTIC0886002B4YY51', '1', '0', '粤B4YY51', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/6c99ca09641d4c08beb1e80387cb9758.png', null, '39', '2021-08-02 13:55:49', '2021-08-02 13:55:49', '122');
INSERT INTO `vehicle_info` VALUES ('341', '31', 'LTIC0886002BU543P', '1', '0', '粤BU543P', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/4a508d3bcdd4461d92f18d3c8dfd5fc1.png', null, '39', '2021-08-02 14:03:35', '2021-08-02 14:03:35', '122');
INSERT INTO `vehicle_info` VALUES ('342', '31', 'LTIC0886002A79896', '1', '0', '粤BA79896', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/33894a8fc079487a984eb2c23aa4fbdf.png', null, '39', '2021-08-02 14:07:57', '2021-08-02 14:07:57', '122');
INSERT INTO `vehicle_info` VALUES ('343', '31', 'LTIC0886002B79MJ8', '1', '0', '粤B79MJ8', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/380d1cd2df8b4358a8139f6403156137.png', null, '17', '2021-08-02 14:12:43', '2021-08-02 14:12:43', '122');
INSERT INTO `vehicle_info` VALUES ('344', '31', 'LTIC0886002B15EA5', '1', '0', '粤B15EA5', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/900e48840b4c42bb8cdc1c3ae378ea44.png', null, '36', '2021-08-02 14:30:03', '2021-08-02 14:30:03', '122');
INSERT INTO `vehicle_info` VALUES ('345', '31', 'LTIC0886002BD5239', '1', '0', '粤BD5239', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/df6dfcce1bb44941837315a5549fe184.png', null, '36', '2021-08-02 15:24:25', '2021-08-02 15:24:25', '122');
INSERT INTO `vehicle_info` VALUES ('346', '31', 'LTIC0886002BLN635', '4', '0', '粤BLN635', '17', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/65e1a73c47354b55b896b248a77aae10.png', null, '36', '2021-08-02 15:40:57', '2021-08-02 15:40:57', '122');
INSERT INTO `vehicle_info` VALUES ('347', '44', 'LTIC0886002BB4F04', '1', '0', '桂B4F04试', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/b62536b797cf4e30a2dd86e271dd436c.png', null, '36', '2021-08-02 16:00:26', '2021-08-02 16:00:26', '122');
INSERT INTO `vehicle_info` VALUES ('348', '18', 'LTIC0886002BB0Z36', '3', '0', '粤B0Z36试', '2', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', null, '36', '2021-08-02 16:10:20', '2021-08-02 16:10:20', '122');
INSERT INTO `vehicle_info` VALUES ('350', '44', 'LVSHFCAC3LH496030', '1', '0', '粤B281K6', '7', '18', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210813/3536f76f7ef34e3da5ce95c4f8d303a8.jpg', null, '36', '2021-08-13 10:40:43', '2021-08-13 10:39:45', '125');
INSERT INTO `vehicle_info` VALUES ('351', '28', 'LSJE24098MS032368', '2', '0', '粤BAM3941', '18', '19', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210817/79b03d60b60241af8692bd6269ec379d.jpg', null, '39', '2021-08-17 09:28:09', '2021-08-17 09:28:09', '127');
INSERT INTO `vehicle_info` VALUES ('352', '28', 'LM8F7D196MA001525', '2', '0', '粤BFA4632', '8', '20', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210817/a11a571354a84c7ab284a087d59945ab.jpg', null, '39', '2021-08-17 09:36:09', '2021-08-17 09:36:09', '127');
INSERT INTO `vehicle_info` VALUES ('353', '28', 'FVVB9E72M5100631', '2', '0', '吉AB997试', '8', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210817/cb2dbc4c8d454f3db3457d0ed32eaf5c.jpg', null, '39', '2021-08-17 09:40:13', '2021-08-17 09:40:13', '127');
INSERT INTO `vehicle_info` VALUES ('354', '28', 'LGWFF6A77MH250454', '2', '0', '粤A00KD7', '19', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210817/c637d89ef0704cb08c0a110f18af5de1.jpg', null, '39', '2021-08-17 09:49:05', '2021-08-17 09:49:05', '127');
INSERT INTO `vehicle_info` VALUES ('355', '28', 'LJDDAA22000622475', '1', '0', '鲁E307FM', '20', '22', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210817/65f8153530e54c668b3a91665cc7aee7.jpg', null, '39', '2021-08-17 09:53:21', '2021-08-17 09:53:21', '127');
INSERT INTO `vehicle_info` VALUES ('356', '28', 'LRVSB2110L1002918', '1', '0', '渐GD72291', '21', '23', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210817/e4225c2ae8f0466bb89bb36bd160b3cc.jpg', null, '39', '2021-08-17 09:56:45', '2021-08-17 09:56:45', '127');
INSERT INTO `vehicle_info` VALUES ('357', '28', 'LRW3E7FA7MC154424', '1', '0', '粤ADR0106', '22', '24', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210818/f5507f84ec1d404ba01afe9203d8b2a2.jpg', null, '39', '2021-08-18 16:46:45', '2021-08-18 16:46:45', '127');
INSERT INTO `vehicle_info` VALUES ('358', '28', 'LRW3E7FA3MC199179', '1', '0', '粤BAJ9710', '22', '24', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210820/f1f02ff35409479e8fbb52776225b6de.jpg', null, '39', '2021-08-20 09:27:35', '2021-08-20 09:27:35', '127');
INSERT INTO `vehicle_info` VALUES ('359', '21', 'LC0CF6CD8L1053773', '1', '0', '粤BAD8272', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210820/b2ab9c9df9dc470c984c81e463ba4ad6.jpg', null, '39', '2023-03-16 11:23:13', '2021-08-20 09:29:55', '127');
INSERT INTO `vehicle_info` VALUES ('360', '18', 'LL3ABCJ20LA011300', '3', '0', '粤B1G81试', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210906/f6fe80b6770f473cac84c48fc5263fa7.jpg', null, '17', '2021-11-12 15:17:07', '2021-08-20 15:22:33', '127');
INSERT INTO `vehicle_info` VALUES ('361', '18', 'LNAB1AB30K5501437', '2', '0', '粤B03B6试', '8', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230106/f76a9479ed9648c0aab19fd666eb50ae.jpg', null, '36', '2023-01-06 16:50:45', '2021-08-23 15:35:09', '127');
INSERT INTO `vehicle_info` VALUES ('363', '15', '同119809', '5', '0', '闽AP5547', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210825/ec59d8efb125445298df19f957d21f5f.jpg', null, '39', '2023-03-29 15:43:19', '2021-08-25 11:06:47', '134');
INSERT INTO `vehicle_info` VALUES ('364', '21', 'LGXCD4D31J0101307', '2', '0', '粤BF82696', '24', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210825/e3d03c748da34ad6bdbbd8912527faf2.jpg', null, '39', '2021-08-25 17:18:32', '2021-08-25 17:18:32', '127');
INSERT INTO `vehicle_info` VALUES ('365', '46', 'LTICFCAC3LHB96001', '1', '0', '粤B96001', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('366', '45', 'LTICFCAC3LHB96002', '1', '0', '粤B96002', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('367', '45', 'LTICFCAC3LHB96003', '1', '0', '粤B96003', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('368', '45', 'LTICFCAC3LHB96004', '1', '0', '粤B96004', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('369', '45', 'LTICFCAC3LHB96005', '1', '0', '粤B96005', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('370', '45', 'LTICFCAC3LHB96006', '1', '0', '粤B96006', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('371', '45', 'LTICFCAC3LHB96007', '1', '0', '粤B96007', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('372', '45', 'LTICFCAC3LHB96008', '1', '0', '粤B96008', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('373', '45', 'LTICFCAC3LHB96009', '1', '0', '粤B96009', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('374', '45', 'LTICFCAC3LHB96010', '1', '0', '粤B96010', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('375', '45', 'LTICFCAC3LHB96011', '1', '0', '粤B96011', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('376', '45', 'LTICFCAC3LHB96012', '1', '0', '粤B96012', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('377', '45', 'LTICFCAC3LHB96013', '1', '0', '粤B96013', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('378', '45', 'LTICFCAC3LHB96014', '1', '0', '粤B96014', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('379', '45', 'LTICFCAC3LHB96015', '1', '0', '粤B96015', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('380', '45', 'LTICFCAC3LHB96016', '1', '0', '粤B96016', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('381', '45', 'LTICFCAC3LHB96017', '1', '0', '粤B96017', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('382', '45', 'LTICFCAC3LHB96018', '1', '0', '粤B96018', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('383', '45', 'LTICFCAC3LHB96019', '1', '0', '粤B96019', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('384', '45', 'LTICFCAC3LHB96020', '1', '0', '粤B96020', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('385', '45', 'LTICFCAC3LHB96021', '1', '0', '粤B96021', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('386', '45', 'LTICFCAC3LHB96022', '1', '0', '粤B96022', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:34:58', '2021-09-06 17:34:58', '122');
INSERT INTO `vehicle_info` VALUES ('387', '45', 'LTICFCAC3LHB96023', '1', '0', '粤B96023', '16', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210802/f0344bbf4a754ccd92c3f0b0d1522ec5.png', '1', '36', '2021-09-06 17:51:40', '2021-09-06 17:34:58', '126');
INSERT INTO `vehicle_info` VALUES ('388', '18', 'LL3ABCJ20LA011298', '3', '2', '粤B1Z12试', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210907/af15846c7bce477bacc898c45c6b4d8b.jpg', null, '39', '2021-09-07 09:29:33', '2021-09-07 09:29:33', '127');
INSERT INTO `vehicle_info` VALUES ('389', '15', '2C4BC2J76LR119400', '5', '2', '鲁G483EA', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210913/7f53f30981f64e26bd5c8a3b8c767114.jpg', null, '39', '2023-03-29 15:43:24', '2021-09-13 17:42:33', '134');
INSERT INTO `vehicle_info` VALUES ('390', '47', 'LGXCE6DB8H0173924', '1', '0', '粤BDK7209', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210914/498615d92cd74f1d895c9cea6432ac86.jpg', null, '39', '2021-09-14 14:48:57', '2021-09-14 14:48:57', '127');
INSERT INTO `vehicle_info` VALUES ('391', '15', '2C4RC2J72LR119779', '5', '1', '苏G50519', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210914/395e519d112c444cbcc546ffdcda9eef.jpg', null, '39', '2021-12-06 10:24:42', '2021-09-14 14:57:44', '122');
INSERT INTO `vehicle_info` VALUES ('392', '15', '2C4RC2J72LR119765', '5', '1', '苏G50517', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210914/ff1306c7cab641ad92ca3d231528094c.jpg', null, '39', '2021-12-06 10:23:31', '2021-09-14 14:59:34', '122');
INSERT INTO `vehicle_info` VALUES ('393', '15', '2C4RC2J76LR233588', '5', '2', '粤B50232', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210914/8f6eb34c62fc49c6a9f49647ee88c9e6.jpg', null, '39', '2023-03-29 14:40:54', '2021-09-14 15:25:55', '134');
INSERT INTO `vehicle_info` VALUES ('394', '28', 'LRWYGCEE2MC000751', '2', '0', '粤ADU9261', '25', '24', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210916/7716be7cdea34faa9e333f581fba5d7e.jpg', null, '39', '2021-09-16 09:36:16', '2021-09-16 09:36:16', '127');
INSERT INTO `vehicle_info` VALUES ('395', '28', 'LNACDAB33M5S3057', '2', '0', '渝A6437试', '8', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210916/045b7a6d4fe3450fada692cf4b32726e.jpg', null, '39', '2021-09-16 09:38:07', '2021-09-16 09:38:07', '127');
INSERT INTO `vehicle_info` VALUES ('396', '28', 'LNACBAB36M5S30623', '2', '0', '渝A6427试', '8', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210916/1d1c1d1d59c24093b765162b7ca6445a.jpg', null, '39', '2021-09-16 09:39:37', '2021-09-16 09:39:37', '127');
INSERT INTO `vehicle_info` VALUES ('397', '28', 'LHGGM2514D2023619', '1', '0', '桂RKZ988', '7', '9', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210917/bb4263af1e3c43e38a4fdc122dc68006.jpg', null, '39', '2021-09-17 09:09:47', '2021-09-17 09:09:47', '127');
INSERT INTO `vehicle_info` VALUES ('398', '18', 'LL3ABCJ25LA011115', '3', '2', '粤BIZ78试', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210918/3c222158bee44bc18519667cbefe54d9.jpg', null, '39', '2021-12-28 10:07:09', '2021-09-18 16:41:27', '122');
INSERT INTO `vehicle_info` VALUES ('399', '28', 'L1NSPGHB9LA005032', '1', '0', '粤ADA3666', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210923/2e9f9b66d26f44e3b59964f3a59beb33.jpg', null, '39', '2021-09-23 09:26:18', '2021-09-23 09:26:18', '127');
INSERT INTO `vehicle_info` VALUES ('400', '28', 'L1NSPGHB4LA009277', '1', '0', '粤ADT1829', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210923/1734ab2545664317866beb0d3eea0d78.jpg', null, '39', '2021-09-23 11:21:53', '2021-09-23 11:21:53', '127');
INSERT INTO `vehicle_info` VALUES ('401', '28', 'LRW3E7EA3LC027654', '1', '0', '粤BD59129', '22', '24', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210923/99c681e2f643410f83af6028d9cddab5.jpg', null, '39', '2021-09-23 11:23:07', '2021-09-23 11:23:07', '127');
INSERT INTO `vehicle_info` VALUES ('402', '28', 'L1NSPGHBXLA001653', '1', '0', '粤ADA0512', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210923/430b84f1af2a47dab14b8faf1bf14ffc.jpg', null, '39', '2021-09-23 15:13:53', '2021-09-23 15:13:53', '127');
INSERT INTO `vehicle_info` VALUES ('403', '21', 'LC0CE6CD6M1033803', '1', '0', '粤B9T72试', '23', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210923/4e652da772484a92a784202a085d152f.jpg', null, '39', '2021-09-23 15:16:03', '2021-09-23 15:16:03', '127');
INSERT INTO `vehicle_info` VALUES ('404', '28', 'LFMB0ABB0H0039757', '1', '0', '粤B823GQ', '7', '26', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210924/494f0604a9f343048db59a3344ca4f2d.jpg', null, '39', '2021-09-24 09:43:47', '2021-09-24 09:43:47', '127');
INSERT INTO `vehicle_info` VALUES ('405', '21', 'LGXCG4DF6C0260611', '2', '0', '粤N94361', '26', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210928/886bc3a3a7294cd09bf26a13d2fc7ce0.jpg', null, '39', '2021-09-28 11:19:49', '2021-09-28 11:19:49', '127');
INSERT INTO `vehicle_info` VALUES ('406', '21', 'LCDCE4CB3M0027062', '2', '0', '粤B7T47试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20210928/22a620af64fc48f69bbe32dafc46aa58.jpg', null, '39', '2021-09-28 11:22:21', '2021-09-28 11:22:21', '127');
INSERT INTO `vehicle_info` VALUES ('407', '48', '3LN6L5CN8KR616274', '1', '0', '粤A5J5MI', '7', '27', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211011/97adc1d13ca145aeadb7d18fe04d8707.jpg', null, '39', '2023-03-29 14:37:38', '2021-10-11 15:58:32', '134');
INSERT INTO `vehicle_info` VALUES ('408', '15', '2C4RC2J75LR110761', '5', '0', '赣D99467', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211018/c59436b76f9b4f11a6cb364a57c6c108.jpg', null, '39', '2023-03-29 15:43:27', '2021-10-18 11:13:47', '134');
INSERT INTO `vehicle_info` VALUES ('409', '24', 'LRW3E7FA2LC147380', '1', '0', '苏G24537f', '22', '24', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211019/d61d7194208f4bb7a9cff2adaaed170d.jpg', null, '39', '2021-10-19 11:57:21', '2021-10-19 11:57:21', '127');
INSERT INTO `vehicle_info` VALUES ('410', '48', 'LBE3SBXD8KW000126', '2', '0', '粤ADX2955', '8', '28', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211020/d699d3e5ef6e4a7aa7eb6938ae14ff8f.jpg', null, '39', '2021-10-20 13:57:56', '2021-10-20 13:53:55', '127');
INSERT INTO `vehicle_info` VALUES ('411', '48', 'LBE3SBXD6LW001812', '2', '0', '粤ADV6932', '8', '28', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211020/908e933b4d774c96a26af7322532619e.jpg', null, '39', '2021-10-20 13:59:15', '2021-10-20 13:59:15', '127');
INSERT INTO `vehicle_info` VALUES ('412', '49', 'LFPHC7PE9M1B15106', '2', '0', '粤BD15106', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211025/d56d2d80f88c417f88d7ce177d9cbf7a.jpg', null, '39', '2023-03-29 14:44:48', '2021-10-22 13:45:55', '134');
INSERT INTO `vehicle_info` VALUES ('413', '24', 'LN6L5SU0JR626739', '1', '0', '苏G803823', '7', '27', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211023/67bfab72592c49deb5f13cdd6b0cb382.jpg', null, '39', '2021-10-23 11:05:50', '2021-10-23 11:05:50', '127');
INSERT INTO `vehicle_info` VALUES ('414', '31', 'L1NSPGHB4LA005391', '1', '0', '粤BA79876', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211023/08f5f62791f749758319ad20bc8a5d3b.jpg', null, '39', '2021-10-23 11:08:15', '2021-10-23 11:08:15', '127');
INSERT INTO `vehicle_info` VALUES ('415', '31', 'LSVSH60R5LN012796', '1', '0', '粤B79MJ8', '7', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211023/e7c33da9051443d69bc5acee4d0438a2.jpg', null, '39', '2021-10-23 11:11:24', '2021-10-23 11:11:24', '127');
INSERT INTO `vehicle_info` VALUES ('416', '31', 'LVRHDFAC2LN068296', '1', '0', '粤BU543P', '7', '13', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211023/de7e859d9f6e434283b28da2c07c3c7e.jpg', null, '39', '2021-10-23 11:13:59', '2021-10-23 11:13:59', '127');
INSERT INTO `vehicle_info` VALUES ('417', '49', 'LFPHC7PE2M1B14668', '2', '0', '粤BD14668', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211025/06e43805389a46799922bd6fd5f683d6.jpg', null, '39', '2023-03-29 14:46:13', '2021-10-24 10:55:00', '134');
INSERT INTO `vehicle_info` VALUES ('418', '31', 'LFWSRXSJ3L1F50232', '4', '0', '粤BLN635', '17', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211024/70fa342a15f044c785f40eedf631be2c.jpg', null, '39', '2021-10-24 13:59:07', '2021-10-24 13:59:07', '127');
INSERT INTO `vehicle_info` VALUES ('419', '31', 'LSVUB6E41M2013891', '2', '0', '粤BAJ3098', '8', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211024/ebbc070430ed4d8a8d18018fdb745141.jpg', null, '39', '2021-10-24 14:04:55', '2021-10-24 14:04:55', '127');
INSERT INTO `vehicle_info` VALUES ('420', '31', 'LE4ZG4CB5KL299794', '1', '0', '粤B4YY51', '15', '12', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211024/9945ee0334f34588bf13b7ce1c1ea055.jpg', null, '39', '2021-10-24 14:08:25', '2021-10-24 14:08:25', '127');
INSERT INTO `vehicle_info` VALUES ('421', '31', 'LGWEF7A53MH509019', '2', '0', '粤B821ZS', '8', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211024/8418a48cbf7448b2b207327bbe37d1f7.jpg', null, '39', '2021-10-24 14:10:40', '2021-10-24 14:10:40', '127');
INSERT INTO `vehicle_info` VALUES ('422', '49', 'LFPHC7PEXM1B14885', '2', '0', '粤BD14885', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211024/f238c5c82c274c6dab8032f67ce7e37f.jpg', null, '39', '2023-03-29 14:45:33', '2021-10-24 14:31:04', '134');
INSERT INTO `vehicle_info` VALUES ('424', '49', 'LFPHC7PE0M1B14703', '2', '0', '粤BD14073', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211025/416d7a2fcaee4ae883eee6151d87fb7a.jpg', null, '39', '2023-03-29 14:45:57', '2021-10-25 13:15:26', '134');
INSERT INTO `vehicle_info` VALUES ('425', '15', '2C4RC2J7XLB119805', '5', '0', '粤BAUTOX1', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211026/8b6912db9d6d47efb0dde52b6f774b6f.jpg', null, '39', '2023-03-29 15:43:29', '2021-10-26 13:41:16', '134');
INSERT INTO `vehicle_info` VALUES ('426', '48', 'JTJBGMCA4L2061602', '2', '1', '粤B1Z85试', '34', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211026/525bb58ee0254d4dae28b9d396defd58.jpg', null, '36', '2023-06-29 14:49:08', '2021-10-26 13:43:11', '134');
INSERT INTO `vehicle_info` VALUES ('427', '49', 'LFPHC7PE1M1B14712', '2', '0', '粤BD14712', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211026/639d7a0e5c13477cb7bdd4a3419ff6a0.jpg', null, '39', '2023-03-29 14:45:54', '2021-10-26 16:56:41', '134');
INSERT INTO `vehicle_info` VALUES ('428', '49', 'LFPHC7PE0M1B15110', '2', '0', '粤BD15110', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211026/8d7a4ba2602042afb9243ed48431af0b.jpg', null, '39', '2023-03-29 14:44:44', '2021-10-26 17:10:49', '134');
INSERT INTO `vehicle_info` VALUES ('429', '28', 'LRWYGCEE4MC000833', '2', '0', '粤ADN5976', '25', '24', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211114/212a62fe36c440a493850d13f5dfe636.jpg', null, '39', '2021-11-14 11:32:18', '2021-11-14 11:32:18', '127');
INSERT INTO `vehicle_info` VALUES ('430', '28', 'LHOCKEBJ7MH001300', '2', '0', '粤AA05956', '8', '29', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211114/d0a156af4c97406b85b1e0e23c0e3874.jpg', null, '39', '2021-11-14 11:40:38', '2021-11-14 11:40:38', '127');
INSERT INTO `vehicle_info` VALUES ('431', '28', 'LNAMBAB34M5S00095', '2', '0', '粤E3545试', '8', '31', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211114/e4a31707f1884b1a9b1b773eb7cc6ed2.jpg', null, '39', '2021-11-14 11:41:53', '2021-11-14 11:41:53', '127');
INSERT INTO `vehicle_info` VALUES ('432', '28', 'LW433B113M1025298', '2', '0', '粤AFD4222', '8', '30', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211114/669fb025b98a4919bd1b474e522de21b.jpg', null, '39', '2021-11-14 11:43:09', '2021-11-14 11:43:09', '127');
INSERT INTO `vehicle_info` VALUES ('433', '28', 'LB37852Z4MS008733', '2', '0', '粤AU01N7', '8', '32', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211114/17df57f6e9574036bbc12916f4cd2cb8.jpg', null, '39', '2021-11-14 11:45:29', '2021-11-14 11:45:29', '127');
INSERT INTO `vehicle_info` VALUES ('434', '28', 'LFV2A2157L6197951', '1', '0', '粤EP0W27', '7', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211114/0f35b0382e674d38b7388990e74755e7.jpg', null, '39', '2021-11-14 11:46:54', '2021-11-14 11:46:54', '127');
INSERT INTO `vehicle_info` VALUES ('435', '50', 'LZYTGGAW1M1002347', '3', '0', '粤A2R46试', '2', '33', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211115/a673ef4a180a4978b6f69bc4d0736371.jpg', null, '39', '2021-11-15 16:24:30', '2021-11-15 16:24:30', '127');
INSERT INTO `vehicle_info` VALUES ('436', '33', 'LFV3A23C3L3104456', '1', '0', '苏U27G71', '3', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211117/520ae78b4e814fdbb886fc9160b000ae.jpg', null, '39', '2021-11-17 11:39:50', '2021-11-17 11:39:50', '127');
INSERT INTO `vehicle_info` VALUES ('437', '15', '2C4RC2J75LR119212', '5', '1', '苏G93270', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211206/27179f2fc03b456394b0e22491d51901.png', null, '39', '2021-12-31 09:48:18', '2021-11-19 12:53:30', '122');
INSERT INTO `vehicle_info` VALUES ('438', '15', '2C4RC2J77LR119650', '5', '1', '苏G39071', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211206/ccf0d09235af4b0da92e3ca54913cc6a.png', null, '39', '2021-12-31 09:56:15', '2021-11-19 13:08:01', '122');
INSERT INTO `vehicle_info` VALUES ('439', '15', '2C4RC2J76LR233459', '5', '1', '鲁GU974Q', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211119/06f7a5d9d5b64c9690136dd06a41f82e.jpg', null, '39', '2021-12-31 10:10:36', '2021-11-19 13:08:35', '122');
INSERT INTO `vehicle_info` VALUES ('440', '49', 'LNBMCB4K6LZ000123', '2', '1', ' 粤A12345', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211123/21eafbe942614f898e9cef4e84357845.jpg', null, '39', '2023-03-29 14:47:08', '2021-11-23 16:54:09', '134');
INSERT INTO `vehicle_info` VALUES ('441', '15', '2C4RC2J73LR233600', '5', '1', '苏G84066', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211206/025abbccc1e4410fbc723ca397863738.png', null, '39', '2021-12-31 10:03:28', '2021-11-24 12:53:55', '122');
INSERT INTO `vehicle_info` VALUES ('442', '15', '2C4RC2J75LR119694', '5', '1', '苏G48223', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220725/1d9260d33bc24b9c98c16f763afcd79a.jpg', null, '39', '2022-07-25 15:25:26', '2021-11-25 11:20:19', '122');
INSERT INTO `vehicle_info` VALUES ('443', '49', 'LFPHC7PE2M1B14511', '2', '1', '粤BD14511', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:46:35', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('444', '49', 'LFPHC7PE7M1B14620', '2', '1', '粤BD14620', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:46:17', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('445', '49', 'LFPHC7PE7M1B14729', '2', '1', '粤BD14729', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:45:50', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('446', '49', 'LFPHC7PE1M1B14970', '2', '1', '粤DB14970', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:45:20', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('447', '49', 'LFPHC7PE2M1B14685', '2', '1', '粤BD14685', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:46:09', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('448', '49', 'LFPHC7PE2M1B14377', '2', '1', '粤BD14377', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:46:42', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('450', '49', 'LFPHC7PE2M1B14380', '2', '1', '粤BD14380', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:46:39', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('451', '49', 'LFPHC7PE7M1B14794', '2', '1', '粤BD14794', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:45:40', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('453', '49', 'LFPHC7PE4M1B14994', '2', '1', '粤BD14994', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:45:04', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('454', '49', 'LFPHC7PE8M1B15890', '2', '1', '粤BD15890', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:44:41', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('455', '49', 'LFPHC7PE3M1B14890', '2', '1', '粤BD14890', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:45:30', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('456', '49', 'LFPHC7PE3M1B15005', '2', '1', '粤BD15005', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/fb26c445f8384534969d4f125bd8c3d1.jpg', null, '39', '2023-03-29 14:44:57', '2021-11-29 16:28:29', '134');
INSERT INTO `vehicle_info` VALUES ('457', '49', 'LFPHC7PE6M1B14852', '2', '1', '粤BD14852', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/06f25d33182d416c981ea6b3bb94aae8.jpg', null, '39', '2023-03-29 14:45:36', '2021-11-29 16:40:24', '134');
INSERT INTO `vehicle_info` VALUES ('458', '49', 'LFPHC7PE8M1B16831', '2', '1', '粤BD16831', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/0c5013106cbf4f4081168854fd15dbe5.jpg', null, '39', '2023-03-29 14:44:35', '2021-11-29 16:47:06', '134');
INSERT INTO `vehicle_info` VALUES ('459', '49', 'LFPHC7PEXM1B14515', '2', '1', '粤BD14515', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/f3edea7802434ba9bb0f8cd45b1fbfce.jpg', null, '39', '2023-03-29 14:46:32', '2021-11-29 16:48:40', '134');
INSERT INTO `vehicle_info` VALUES ('460', '49', 'LFPHC7PE5M1B14308', '2', '1', '粤BD14308', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/0220b006b2a9434a9df46f5ef4317b61.jpg', null, '39', '2023-03-29 14:46:46', '2021-11-29 16:50:43', '134');
INSERT INTO `vehicle_info` VALUES ('461', '49', 'LFPHC7PE3M1B14694', '2', '1', '粤BD14694', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/3989b6e722d84a798220c906b7589fec.jpg', null, '39', '2023-03-29 14:46:02', '2021-11-29 16:52:21', '134');
INSERT INTO `vehicle_info` VALUES ('462', '49', 'LFPHC7PE3M1B14579', '2', '1', '粤BD14579', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/30d45aa516c5491b887a7ab93f88a4e5.jpg', null, '39', '2023-03-29 14:46:25', '2021-11-29 16:53:44', '134');
INSERT INTO `vehicle_info` VALUES ('463', '49', 'LFPHC7PE9M1B15039', '2', '1', '粤BD15039', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/d9f1314d8a9444e18fa59ab620ab54fb.jpg', null, '39', '2023-03-29 14:44:52', '2021-11-29 16:54:59', '134');
INSERT INTO `vehicle_info` VALUES ('464', '49', 'LFPHC7PE2M1B14525', '2', '1', '粤BD14525', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/37a4b58955a3443f85bb2bb9940e1a26.jpg', null, '39', '2023-03-29 14:46:29', '2021-11-29 16:57:37', '134');
INSERT INTO `vehicle_info` VALUES ('465', '49', 'LFPHC7PE1M1B14919', '2', '1', '粤BD14919', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/6fd12476f2424e0ea0916d18333bbbf8.jpg', null, '39', '2023-03-29 14:45:24', '2021-11-29 16:58:51', '134');
INSERT INTO `vehicle_info` VALUES ('466', '49', 'LFPHC7PEXM1B14997', '2', '1', '粤BD14997', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/19b3837e9ae94f648eff5a96389467e3.jpg', null, '39', '2023-03-29 14:45:00', '2021-11-29 17:00:06', '134');
INSERT INTO `vehicle_info` VALUES ('467', '49', 'LFPHC7PE3M1B14601', '2', '1', '粤BD14601', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/86549dd2463f410bb6d2c668957f99f8.jpg', null, '39', '2023-03-29 14:46:21', '2021-11-29 17:01:30', '134');
INSERT INTO `vehicle_info` VALUES ('468', '49', 'LFPHC7PE8M1B14688', '2', '1', '粤BD14688', '16', '4', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211129/6991ad39346b4015b66031b639bde7c9.jpg', null, '39', '2023-03-29 14:46:05', '2021-11-29 17:02:58', '134');
INSERT INTO `vehicle_info` VALUES ('469', '28', 'LW433B116M1020015', '2', '0', '粤AFA3310', '8', '30', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211208/cfaae89a439a41ba941e09f32d87a52f.jpg', null, '39', '2021-12-08 10:16:56', '2021-12-08 10:16:56', '127');
INSERT INTO `vehicle_info` VALUES ('470', '28', 'LGWEFUA54MH250474', '2', '0', '苏E4165Y', '8', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211208/d01d0677d2454db9857e4ed39d4b6377.jpg', null, '39', '2021-12-08 10:18:22', '2021-12-08 10:18:22', '127');
INSERT INTO `vehicle_info` VALUES ('471', '28', 'LJD8AC3F1M001109', '2', '0', '粤AA35583', '8', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211208/da5f99f2512e4bad81e63ca898070a40.jpg', null, '39', '2021-12-08 10:19:41', '2021-12-08 10:19:41', '127');
INSERT INTO `vehicle_info` VALUES ('472', '28', 'LW6AFG2A2MC001970', '2', '0', '苏E4501Y', '8', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211208/c0c48746cfea402ab8aa25ea11186172.jpg', null, '39', '2021-12-08 10:21:55', '2021-12-08 10:21:55', '127');
INSERT INTO `vehicle_info` VALUES ('473', '28', 'LVHFE1673N6000206', '1', '0', '鄂A16H38', '15', '9', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211208/ccf726d8e74a4b739fbbefdddc0013ca.jpg', null, '39', '2021-12-08 10:23:31', '2021-12-08 10:23:31', '127');
INSERT INTO `vehicle_info` VALUES ('474', '28', 'L1NSPGH92MA062574', '1', '0', '粤A3CH47', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211208/f99a1d46205147b2a21be5d2acbe2ce6.jpg', null, '39', '2021-12-08 14:23:04', '2021-12-08 14:23:04', '127');
INSERT INTO `vehicle_info` VALUES ('475', '28', 'LW433B114M1045706', '2', '0', '粤AFD3348', '8', '30', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211210/e0dc95f8573440c8b278359e0c1be39e.jpg', null, '39', '2021-12-10 11:00:09', '2021-12-10 11:00:09', '127');
INSERT INTO `vehicle_info` VALUES ('476', '28', 'LVGB4B9E2LG413909', '1', '0', '粤A8L03J', '15', '26', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211210/481ca18d299646eb9e8b024a050c1045.jpg', null, '39', '2021-12-10 11:01:42', '2021-12-10 11:01:42', '127');
INSERT INTO `vehicle_info` VALUES ('477', '21', 'LC0CE6CD0M1062732', '1', '0', '粤BAN2991', '23', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211214/0eb91829d2b44256bec07b65c50399a1.jpg', null, '39', '2021-12-14 09:31:09', '2021-12-14 09:31:09', '127');
INSERT INTO `vehicle_info` VALUES ('478', '52', 'L66CB1A45M1000045', '3', '0', '粤BDM0045', '2', '35', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211224/42703fb3bdad4437a2f15bbc6392ab09.jpg', null, '39', '2021-12-24 10:40:18', '2021-12-24 10:40:18', '127');
INSERT INTO `vehicle_info` VALUES ('479', '48', 'JTJBGMCA8L2061070', '2', '1', '粤B1Z84试', '34', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211224/a55379909cf9427da45899528248c87b.png', null, '36', '2023-06-29 14:49:12', '2021-12-24 10:55:09', '134');
INSERT INTO `vehicle_info` VALUES ('480', '48', 'JTJBGMCA9L2061658', '2', '1', '粤B1Z86试', '34', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211224/cd1abcbc191e4eeba6749467cb183aee.png', null, '36', '2023-06-29 14:49:04', '2021-12-24 10:55:55', '134');
INSERT INTO `vehicle_info` VALUES ('481', '48', 'JTJBGMCA5L2061883', '2', '1', '粤B1Z73试', '34', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211224/3c15ea4ff9ad4ebd82a30328e1f45e1e.png', null, '36', '2023-06-29 14:48:59', '2021-12-24 10:57:45', '134');
INSERT INTO `vehicle_info` VALUES ('483', '50', '3LN6L5MU6JR609182', '1', '0', '粤BD09182', '7', '27', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211227/63b4b709ab27451a87d24cf6a9bd67c2.jpg', null, '36', '2023-03-29 14:38:05', '2021-12-27 10:32:54', '134');
INSERT INTO `vehicle_info` VALUES ('484', '54', 'LMTZSV017MC000049', '6', '1', '粤BD00049', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/f486f2e3d12f4dd1a5bf37aba513f54d.png', null, '39', '2023-08-29 13:54:39', '2021-12-27 14:11:44', '134');
INSERT INTO `vehicle_info` VALUES ('485', '18', 'LL3ABCJ26LA011298', '3', '2', '粤BIZ77试', '2', '2', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211228/d17a9e81d92b44b786a8dab070e9f213.jpg', null, '36', '2021-12-28 10:15:24', '2021-12-28 10:15:24', '122');
INSERT INTO `vehicle_info` VALUES ('486', '15', '2C4RC2J79LR119374', '5', '1', '粤B50233', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211230/d17c37de364b4fc9a766935825f9d021.png', null, '36', '2021-12-31 09:27:36', '2021-12-30 14:19:38', '122');
INSERT INTO `vehicle_info` VALUES ('487', '15', '2C4RC2J71LR119174', '5', '1', '桂JI9H70', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/095b6a9051c34b3cbc296260ba812b51.png', null, '36', '2021-12-31 09:37:38', '2021-12-31 09:37:38', '122');
INSERT INTO `vehicle_info` VALUES ('488', '15', '2C4RC2J76LR119400', '5', '1', '湘MW9015', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/fb0d64970d504007b2d687ad2ac178fd.png', null, '36', '2021-12-31 09:40:15', '2021-12-31 09:40:15', '122');
INSERT INTO `vehicle_info` VALUES ('489', '15', '2C4RC2J70LR233585', '5', '1', '赣B97734', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/d885f56eab2446d4a1f1c8e45a68447f.png', null, '36', '2021-12-31 09:46:00', '2021-12-31 09:46:00', '122');
INSERT INTO `vehicle_info` VALUES ('490', '15', '2C4RC2J77LR233468', '5', '1', '赣B97731', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/3adb72f9f3a0425887b8421d4cfdfbd9.png', null, '36', '2021-12-31 09:49:43', '2021-12-31 09:49:43', '122');
INSERT INTO `vehicle_info` VALUES ('491', '15', '2C4RC2J70LR233490', '5', '1', '苏G66903', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/bb86d30133e14bc58b964da0d03c2b15.png', null, '36', '2021-12-31 09:58:28', '2021-12-31 09:58:28', '122');
INSERT INTO `vehicle_info` VALUES ('492', '15', '2C4RC2J78LR119575', '5', '1', '苏G66901', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/e85b2fd2e3894669b35b8f5af4b7cfa1.png', null, '36', '2021-12-31 10:00:36', '2021-12-31 10:00:36', '122');
INSERT INTO `vehicle_info` VALUES ('493', '15', '2C4RC2J7XLR233531', '5', '1', '苏G35070', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/07794b03add64214b0398f63bb27b353.png', null, '36', '2021-12-31 10:01:56', '2021-12-31 10:01:56', '122');
INSERT INTO `vehicle_info` VALUES ('494', '15', '2C4RC2J78LR233530', '5', '1', '湘M03570', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/12e4253e69414f31870e2d434e6cf437.png', null, '36', '2021-12-31 10:05:48', '2021-12-31 10:05:48', '122');
INSERT INTO `vehicle_info` VALUES ('495', '15', '2C4RC2J78LR119656', '5', '1', '苏G48224', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/d6bc3c046ba14ed8be1cc0bb34933b81.png', null, '36', '2021-12-31 10:07:13', '2021-12-31 10:07:13', '122');
INSERT INTO `vehicle_info` VALUES ('496', '15', '2C4RC2J75LR233470', '5', '1', '粤BPG673', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/62d27ecf8eca4ccf9ac007eacb7ea1af.png', null, '36', '2021-12-31 10:08:34', '2021-12-31 10:08:34', '122');
INSERT INTO `vehicle_info` VALUES ('497', '15', '2C4RC2J70LR233442', '5', '1', '苏G48225', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/f5841404d99943478c3567f8174a7683.png', null, '36', '2021-12-31 10:12:58', '2021-12-31 10:12:58', '122');
INSERT INTO `vehicle_info` VALUES ('498', '15', '2C4RC2J73LR119807', '5', '1', '苏G01724', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/bf4ccb5be2814c13a6d1852630ff45bd.png', null, '36', '2021-12-31 10:14:29', '2021-12-31 10:14:29', '122');
INSERT INTO `vehicle_info` VALUES ('499', '15', 'LVHCV6651L5012145', '5', '1', '苏G57289', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/43a2b46938d24a69a018017f458fc242.png', null, '36', '2021-12-31 10:50:42', '2021-12-31 10:50:42', '122');
INSERT INTO `vehicle_info` VALUES ('500', '15', 'LHGCV3680M8023997', '5', '1', '苏G75076', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/eb13e8ffdc124536ad4eb906a2f097aa.png', null, '36', '2021-12-31 10:51:56', '2021-12-31 10:51:56', '122');
INSERT INTO `vehicle_info` VALUES ('501', '15', 'LHGCV3682M8030269', '5', '1', '苏G75073', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/b780a7871ca84cc19652454851308dd4.png', null, '36', '2021-12-31 10:53:06', '2021-12-31 10:53:06', '122');
INSERT INTO `vehicle_info` VALUES ('502', '15', 'LHGCV3686M8024006', '5', '1', '苏G75074', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20211231/c2c89fac63c54343a13849ce6b71111f.png', null, '36', '2021-12-31 10:54:17', '2021-12-31 10:54:17', '122');
INSERT INTO `vehicle_info` VALUES ('503', '15', 'LJD8AB3F0M0012181', '5', '0', '苏G91578', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220107/e7201fac45504d1f8ca91fdba86c2678.jpg', null, '39', '2023-03-29 15:42:20', '2022-01-07 15:17:44', '134');
INSERT INTO `vehicle_info` VALUES ('504', '55', '12345678910HX9JLC', '3', '0', '粤BHX9JLC', '2', '36', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220110/ae3adc72e795466e9ea7124c44b2a3d7.jpg', null, '39', '2022-01-10 09:45:08', '2022-01-10 09:45:08', '127');
INSERT INTO `vehicle_info` VALUES ('505', '28', 'LVSHPCHAOMS239607', '2', '0', '粤AD24458', '8', '37', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220215/6e505259806f4c7f87181b3d5c1d5770.jpg', null, '39', '2022-02-15 14:04:20', '2022-02-15 14:04:20', '127');
INSERT INTO `vehicle_info` VALUES ('506', '28', 'LSVFA6E93M2012345', '2', '0', '粤AD30458', '8', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220215/e87fb37438fe4b438802c627a54a643b.jpg', null, '39', '2022-02-15 14:08:36', '2022-02-15 14:08:36', '127');
INSERT INTO `vehicle_info` VALUES ('507', '28', 'LDP95E962ME012988', '2', '0', '粤AFB4369', '8', '22', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220215/4e99ac745ac34ca48470cfb1f88b592e.jpg', null, '39', '2022-02-15 16:05:35', '2022-02-15 16:05:35', '127');
INSERT INTO `vehicle_info` VALUES ('508', '28', 'LSJW56091MG087447', '1', '0', '粤BDD6277', '7', '19', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220216/9db528c2d0ae49a18cd109d7ccf442a7.jpg', null, '39', '2022-02-16 14:25:35', '2022-02-16 14:25:35', '127');
INSERT INTO `vehicle_info` VALUES ('509', '28', 'LMGJC3S801MS00077', '2', '0', '粤CY4230', '8', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220216/535362dabdd0435ab641483286f5d574.jpg', null, '39', '2022-02-16 15:35:18', '2022-02-16 15:35:18', '127');
INSERT INTO `vehicle_info` VALUES ('510', '15', 'LJD8AC3F6M0010876', '5', '0', '湘MW9016', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220221/5af56a0a12c343e5ade5c268b399030c.jpg', null, '39', '2023-03-29 15:41:56', '2022-02-21 11:15:37', '134');
INSERT INTO `vehicle_info` VALUES ('511', '31', 'YV2XG20C3JA825824', '4', '0', '粤BLV140', '17', '38', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220224/29dac3ed84ef40b39fcfaca0f53d2e67.jpg', null, '39', '2022-02-24 13:24:38', '2022-02-24 13:24:38', '127');
INSERT INTO `vehicle_info` VALUES ('512', '56', 'LLAYKZC2102011000004', '6', '1', '粤B0V020', '5', '42', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220304/405e1da208e2465eb162302442725deb.jpg', null, '39', '2023-08-08 10:22:20', '2022-03-04 10:56:18', '134');
INSERT INTO `vehicle_info` VALUES ('513', '56', 'LLAYKZC2102011000006', '6', '1', '粤B0V022', '5', '42', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220304/ab877e080f9f4e018f1eb1ddadb43207.jpg', null, '39', '2023-08-08 10:22:16', '2022-03-04 10:57:27', '134');
INSERT INTO `vehicle_info` VALUES ('514', '28', 'L1NSSGH98MA080172', '2', '0', '粤AD21458', '8', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220308/b10df7c89d1243f19f6759317f267219.jpg', null, '39', '2022-03-08 09:43:30', '2022-03-08 09:43:30', '127');
INSERT INTO `vehicle_info` VALUES ('515', '28', 'LB37852D8MS008237', '2', '0', '粤AW36N6', '8', '32', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220308/a10c56dd359647678b2b043f2df8ba64.jpg', null, '39', '2022-03-08 09:45:01', '2022-03-08 09:45:01', '127');
INSERT INTO `vehicle_info` VALUES ('516', '28', 'LGWFF7A60NH500065', '2', '0', '苏E6748M', '8', '39', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220308/ad72039ee6674d8e948cd51f828122f7.jpg', null, '39', '2022-03-08 09:54:30', '2022-03-08 09:54:30', '127');
INSERT INTO `vehicle_info` VALUES ('517', '28', 'L1NSPGH93MA054208', '1', '0', '粤AD31458', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220308/d70b06f5b98c4ba6906333fad3527824.jpg', null, '39', '2022-03-08 10:00:33', '2022-03-08 10:00:33', '127');
INSERT INTO `vehicle_info` VALUES ('518', '21', 'LC0CF6CD9M1117353', '1', '0', '粤BAM6651', '23', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220412/7379ddf1c276487f889f36e7b5c79013.jpg', null, '39', '2022-04-12 16:22:52', '2022-04-12 16:22:52', '127');
INSERT INTO `vehicle_info` VALUES ('519', '15', '2C4RC2J70LR233487', '5', '1', '赣AR8619', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220420/c0cc5f28e89c4341ad749527715011b5.jpg', null, '36', '2022-04-20 15:38:38', '2022-04-20 15:38:38', '122');
INSERT INTO `vehicle_info` VALUES ('520', '15', '2C4RC2J73LR233631', '5', '1', '粤BD33631', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220420/671f06662bdb44fe96343cc3d41ea9ab.jpg', null, '36', '2023-03-29 14:41:01', '2022-04-20 15:44:02', '134');
INSERT INTO `vehicle_info` VALUES ('521', '21', 'LC0CE6CD0M1112495', '1', '0', '粤B75C0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220424/0a01174207004f0a9afe3df2d670f100.jpg', null, '39', '2022-04-24 10:30:30', '2022-04-24 10:30:30', '127');
INSERT INTO `vehicle_info` VALUES ('522', '21', 'LC0CE6CD9N1022327', '1', '0', '粤B37C9试', '15', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220424/894fb5bf709b4b0ab3d69b4ea8709954.jpg', null, '39', '2022-08-15 14:20:07', '2022-04-24 10:47:25', '127');
INSERT INTO `vehicle_info` VALUES ('523', '21', 'LC0CF6CD3M1112505', '1', '0', '粤B6Y87试', '15', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220424/5e88731c70e9448b81c1c8321f7b4375.jpg', null, '39', '2022-11-17 09:36:47', '2022-04-24 16:03:06', '127');
INSERT INTO `vehicle_info` VALUES ('524', '21', 'LC0CD4C46N1005170', '2', '0', '粤BFK6402', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220428/6064e1afafe243c2bf6fc8f998e3d6b0.jpg', null, '39', '2022-04-28 09:32:06', '2022-04-28 09:32:06', '127');
INSERT INTO `vehicle_info` VALUES ('525', '21', 'LC0C76C44N1030345', '1', '0', '粤B11A2试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220428/e9faaf131b744ecca9c74841866c1ebd.jpg', null, '39', '2022-04-28 10:17:27', '2022-04-28 10:17:27', '127');
INSERT INTO `vehicle_info` VALUES ('526', '15', '2C4RC2J74LR119606', '5', '1', '赣AJ5309', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220516/4ed7675be1314f719521e8e79eda39c8.jpg', null, '36', '2022-05-16 15:38:32', '2022-05-16 15:38:32', '122');
INSERT INTO `vehicle_info` VALUES ('527', '15', '2C4RC2J72LR119328', '5', '1', '赣AJ5312', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220516/0ce93aedc7fc424899b772af462a487e.jpg', null, '36', '2022-05-16 15:40:53', '2022-05-16 15:40:53', '122');
INSERT INTO `vehicle_info` VALUES ('528', '15', '2C4RC2J75LR233629', '5', '1', '赣AJ5077', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220516/8145b0d3a4cd434c89ce9e29ed439a88.jpg', null, '36', '2022-05-16 15:42:40', '2022-05-16 15:42:40', '122');
INSERT INTO `vehicle_info` VALUES ('529', '21', 'LC0CE4CB9M0027051', '1', '0', '粤B18AO试', '15', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220518/9bb0ec95e06146979196d4fe62a6561f.jpg', null, '39', '2022-05-18 10:31:50', '2022-05-18 10:31:50', '127');
INSERT INTO `vehicle_info` VALUES ('530', '21', 'LC0C76C46N1030315', '1', '0', '粤B21A1试', '15', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220518/684ba234bb1b4c6c81fdfd1c063ce3c2.jpg', null, '39', '2022-05-18 10:56:34', '2022-05-18 10:56:34', '127');
INSERT INTO `vehicle_info` VALUES ('532', '21', 'L1NSPGH9XNA085666', '1', '0', '粤BDM9443', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220519/43ac304c773347279cc953212efd5af8.jpg', null, '39', '2023-02-11 19:33:52', '2022-05-19 22:09:10', '127');
INSERT INTO `vehicle_info` VALUES ('533', '21', 'LC0CE6CD0M1097884', '2', '0', '苏E0109试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220520/b5774598f5c8470b9aabe365ec5bee54.jpg', null, '39', '2022-08-22 17:40:52', '2022-05-20 14:09:50', '127');
INSERT INTO `vehicle_info` VALUES ('534', '21', 'LMELBL4W5NRY00001', '2', '0', '苏C4711试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220520/cc06e90ef2ab420f9895b74f07bd6eaa.jpg', null, '39', '2022-05-20 14:11:25', '2022-05-20 14:11:25', '127');
INSERT INTO `vehicle_info` VALUES ('535', '15', '2C4RC2J77LR233552', '5', '1', '赣AJ5078', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220523/ece5b9b6963f42af8d796162d2fb9b9b.jpg', null, '36', '2022-05-23 15:16:03', '2022-05-23 15:16:03', '122');
INSERT INTO `vehicle_info` VALUES ('536', '44', 'LK6ADAE2XNB037411', '1', '0', '桂BIU26试', '15', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220525/c202111dd4a345fdaa703b59fb415b32.jpg', null, '39', '2022-08-09 10:42:04', '2022-05-25 09:31:01', '127');
INSERT INTO `vehicle_info` VALUES ('537', '21', 'LC0CF6CD6M1086594', '1', '0', '粤BDJ1286', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230411/a98fc2b2b2e54599b36824709b65b156.jpg', null, '36', '2023-04-11 16:13:20', '2022-05-25 10:02:15', '127');
INSERT INTO `vehicle_info` VALUES ('538', '21', 'LC0CE4CB3M0027062', '1', '0', '粤B62C3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220526/4da204fa28a1425d87e6b4c24054ecbb.jpg', null, '39', '2022-05-26 14:49:28', '2022-05-26 14:49:28', '127');
INSERT INTO `vehicle_info` VALUES ('539', '21', 'LGWFFVA7XNH250654', '2', '0', '粤BF45756', '19', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220530/401786b1ede94c48b42fb09d9886de0a.jpg', null, '39', '2022-05-30 10:02:27', '2022-05-30 10:02:27', '127');
INSERT INTO `vehicle_info` VALUES ('540', '28', 'LM8F7D894NA008528', '2', '0', '粤EFD7892', '8', '20', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220530/8eb89430b0fb4bb3a0fee8b64a25e5db.jpg', null, '39', '2022-05-30 10:03:51', '2022-05-30 10:03:51', '127');
INSERT INTO `vehicle_info` VALUES ('541', '28', 'LRWYGCEE4MC002968', '1', '0', '粤BAG5120', '15', '24', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220530/4af7c3dac47947c094d0c6d54b15d02d.jpg', null, '39', '2022-05-30 10:09:39', '2022-05-30 10:09:39', '127');
INSERT INTO `vehicle_info` VALUES ('542', '28', 'LNACDAB34M5027118', '2', '0', '粤BD57289', '8', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220530/81ab1e7d30cf489699bf3689c2a697fb.jpg', null, '39', '2022-05-30 10:10:56', '2022-05-30 10:10:56', '127');
INSERT INTO `vehicle_info` VALUES ('543', '28', 'LVGC61AZ9NG001352', '2', '0', '粤A7G58D', '8', '26', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220531/05db5cd498a74c25964e7e7b2f038c0f.jpg', null, '39', '2022-05-31 09:34:58', '2022-05-31 09:34:58', '127');
INSERT INTO `vehicle_info` VALUES ('544', '28', 'LVSHFFAC0MS211337', '2', '0', '苏E6078Y', '8', '18', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220531/a95540f4587e4b139fdba3d854425582.jpg', null, '39', '2022-05-31 09:36:20', '2022-05-31 09:36:20', '127');
INSERT INTO `vehicle_info` VALUES ('545', '21', 'LC0CD4C43N1008205', '1', '0', '粤BFM5589', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220607/aa5ca5e3d93345d9bdb7ac83f7cd8e40.jpg', null, '39', '2022-06-07 10:05:30', '2022-06-07 10:05:30', '127');
INSERT INTO `vehicle_info` VALUES ('546', '21', 'LGXCH6CD0N2002997', '2', '0', '粤B26C8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220613/ca7070af596b40518dc5a533f34796ab.jpg', null, '39', '2022-06-13 10:31:21', '2022-06-13 10:31:21', '127');
INSERT INTO `vehicle_info` VALUES ('547', '21', 'LC0CF4CD2N1013602', '2', '0', '粤B87C2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220613/c679f3bd60374177a80e6341889d4214.jpg', null, '39', '2022-07-28 09:16:53', '2022-06-13 10:35:04', '127');
INSERT INTO `vehicle_info` VALUES ('549', '21', 'LC0CE4CB0M0027066', '2', '0', '粤B18A1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220613/546a9226f333498891cf87ecebb69b53.jpg', null, '39', '2022-06-13 11:06:01', '2022-06-13 11:06:01', '127');
INSERT INTO `vehicle_info` VALUES ('550', '15', '2C4RC2J75LR233419', '5', '0', '粤BD33419', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220613/928376377ebd4cb4b14df6e267c2f78c.jpg', null, '39', '2023-04-06 12:28:06', '2022-06-13 15:30:58', '134');
INSERT INTO `vehicle_info` VALUES ('551', '15', '2C4RC2J7XLR233514', '5', '0', '粤BD33514', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220613/509958d68de54e6eb1ea23758efaf8ff.jpg', null, '39', '2023-04-06 12:29:10', '2022-06-13 15:32:31', '134');
INSERT INTO `vehicle_info` VALUES ('552', '15', '2C4RC2J73LR233385', '5', '0', '粤BD33385', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220613/d351484fa3e34cca8d52ef2d6ecec0ae.jpg', null, '39', '2023-04-06 12:28:54', '2022-06-13 15:33:28', '134');
INSERT INTO `vehicle_info` VALUES ('553', '15', '2C4RC2J78LR119544', '5', '0', '粤BD19544', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220613/319b8e27fe9f4989bd70a1ebcdc26ce0.jpg', null, '39', '2023-04-06 12:26:16', '2022-06-13 15:34:34', '134');
INSERT INTO `vehicle_info` VALUES ('554', '15', '2C4RC2J70LR233425', '5', '0', '粤BD33425', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220613/98b367df489042b5b7be8ea9646271ae.jpg', null, '39', '2023-04-06 12:27:35', '2022-06-13 15:35:33', '134');
INSERT INTO `vehicle_info` VALUES ('555', '21', 'LGXC76D44L0265472', '1', '0', '粤B265472', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220622/9d106c078e4a4458bdbbd5764e219702.jpg', null, '39', '2022-06-22 11:47:02', '2022-06-22 11:47:02', '127');
INSERT INTO `vehicle_info` VALUES ('556', '21', 'LGXCE6CB0N0084393', '2', '0', '陕A4219试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220622/08e6befa6fa148669af5dabe5953a4be.jpg', null, '39', '2022-06-22 11:48:32', '2022-06-22 11:48:32', '127');
INSERT INTO `vehicle_info` VALUES ('557', '21', 'LC0CD6C43M1112543', '1', '0', '粤B20F8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220622/5d9616f4fe0c44d499d5d55626dff8b6.jpg', null, '39', '2023-04-06 14:14:00', '2022-06-22 11:54:00', '127');
INSERT INTO `vehicle_info` VALUES ('558', '21', 'LGXC76C45M0030680', '1', '0', '粤B71C1试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220622/800e260a604c4ad8bccfeace8582cdda.jpg', null, '39', '2022-06-22 13:15:00', '2022-06-22 13:15:00', '127');
INSERT INTO `vehicle_info` VALUES ('559', '23', 'LB378B2Z9NS020117', '2', '0', '浙B35NL5', '8', '32', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220624/02d573fe3d524ca685d6bbf93248c22e.jpg', null, '39', '2022-06-24 14:45:43', '2022-06-24 14:45:43', '127');
INSERT INTO `vehicle_info` VALUES ('560', '21', 'LC0CF6CDXL1031287', '1', '0', '粤BA91640', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220624/892a81966ff24c6c9de45fbc4f3605d8.jpg', null, '36', '2023-04-13 14:02:36', '2022-06-24 14:48:04', '127');
INSERT INTO `vehicle_info` VALUES ('561', '21', 'LC0CE4DCXM0012002', '2', '0', '粤B7IC3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220627/a927ffef8a4c486cae5d745ca35bc78f.jpg', null, '39', '2022-06-27 10:26:49', '2022-06-27 10:26:49', '127');
INSERT INTO `vehicle_info` VALUES ('562', '21', 'LGXC74C49M0411338', '2', '0', '粤B35C5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220627/564e6ccd977643f283459710d4f04a30.jpg', null, '39', '2022-06-27 13:56:39', '2022-06-27 13:56:39', '127');
INSERT INTO `vehicle_info` VALUES ('563', '21', 'LC0C76C44M0999924', '2', '0', '陕A4224试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220627/47a09e94003d46deace9a6ffc7f63cef.jpg', null, '39', '2022-06-27 13:58:03', '2022-06-27 13:58:03', '127');
INSERT INTO `vehicle_info` VALUES ('564', '21', 'LGXC74C42M0411326', '2', '0', '苏E9336试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220627/c818a00ca86143d2a4958a8c66d07ef6.jpg', null, '39', '2022-06-27 17:03:57', '2022-06-27 14:02:16', '127');
INSERT INTO `vehicle_info` VALUES ('565', '21', 'LC0CD6C43M1097879', '1', '0', '苏E9499试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220707/bd675879efce47ab8b69325e0e6777ed.jpg', null, '39', '2022-07-07 09:32:21', '2022-07-07 09:32:21', '127');
INSERT INTO `vehicle_info` VALUES ('566', '15', 'LJD8AB3F0N0015535', '5', '0', '赣AR7336', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220708/7edc706eb20f4846b739cbec52bf4fe8.jpg', null, '36', '2023-03-29 15:41:22', '2022-07-08 15:07:10', '134');
INSERT INTO `vehicle_info` VALUES ('567', '15', 'LJD8AB3F3M0014281', '5', '0', '粤BD14281', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220708/a63c1dca2288477c9c74efe46054f49e.jpg', null, '36', '2023-06-06 11:21:14', '2022-07-08 15:12:53', '134');
INSERT INTO `vehicle_info` VALUES ('568', '21', 'LRW3E7FA4LC093614', '1', '0', '粤AH1233', '7', '24', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220711/5e1579a3717d44dcaeccd721221c8e93.jpg', null, '39', '2022-07-11 10:27:34', '2022-07-11 10:27:34', '127');
INSERT INTO `vehicle_info` VALUES ('569', '15', 'LJD8AB3F2M0014238', '5', '0', '粤BD14238', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/9c05396c0d9a4e2d99f386ebbfeb6e46.jpg', null, '39', '2023-03-29 15:40:54', '2022-07-12 10:27:46', '134');
INSERT INTO `vehicle_info` VALUES ('570', '15', 'LJD8AB3F8N0014665', '5', '0', '粤BD14665', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', null, '39', '2023-03-29 15:40:16', '2022-07-12 10:28:58', '134');
INSERT INTO `vehicle_info` VALUES ('571', '21', 'LC0CE6CD2M1112496', '1', '0', '苏E9395试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/7faf718dc8694e4c9efbd07e68147e5e.jpg', null, '39', '2022-07-12 13:44:00', '2022-07-12 13:44:00', '127');
INSERT INTO `vehicle_info` VALUES ('572', '21', 'L1NSPGHB5LA007053', '1', '0', '粤BAE1889', '7', '14', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/9f172fa3059d41a299119cceb483a4fc.jpg', null, '39', '2023-02-11 19:35:06', '2022-07-12 13:46:20', '127');
INSERT INTO `vehicle_info` VALUES ('573', '15', 'LJD8AB3F2N0015357', '5', '0', '粤BD15357', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/6ee879ec9e184932a0b69e087ed1a21e.jpg', null, '39', '2023-03-29 15:40:04', '2022-07-12 15:04:26', '134');
INSERT INTO `vehicle_info` VALUES ('574', '20', 'HJRPBGGB0NB300234', '2', '0', '皖BFU74试', '8', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220718/7527c6f0f34d476184c1434a30f55ad7.jpg', null, '39', '2022-07-18 13:34:42', '2022-07-18 13:34:42', '127');
INSERT INTO `vehicle_info` VALUES ('575', '20', 'LNAB1AB37M5504175', '2', '0', '粤BDC1242', '8', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220718/1b91ed1141c843f8b78d7bbba2a373ad.jpg', null, '39', '2022-07-18 13:35:51', '2022-07-18 13:35:51', '127');
INSERT INTO `vehicle_info` VALUES ('576', '21', 'LC0CE6CB3N1999008', '1', '0', '粤B25C1试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220720/d85cd19dbf1648e5916ab21a47f9dd87.jpg', null, '39', '2022-07-20 13:27:23', '2022-07-20 13:27:23', '127');
INSERT INTO `vehicle_info` VALUES ('577', '21', 'LC0DD4C46N1061565', '2', '0', '苏E9345试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220720/26f8ee73e9c84b7eaeccdcd1bac25be5.jpg', null, '39', '2022-07-20 16:31:55', '2022-07-20 16:31:55', '127');
INSERT INTO `vehicle_info` VALUES ('578', '21', 'LC0CE6CD0M1112500', '1', '0', '粤B88C4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220721/b8bc2391eee44eb3978fb4b1b12fd5af.jpg', null, '39', '2022-07-21 14:45:14', '2022-07-21 14:45:14', '127');
INSERT INTO `vehicle_info` VALUES ('579', '21', 'LC0E4CB5M0055865', '1', '0', '粤B01D6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220725/5c7c2215aa4f4000b8c3ba31a8ec834d.jpg', null, '39', '2022-07-25 09:52:52', '2022-07-25 09:52:52', '127');
INSERT INTO `vehicle_info` VALUES ('580', '21', 'LGXCF6CD7N2002968', '1', '0', '粤B78C3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220725/d25ba374013b462782cb98592468e32c.jpg', null, '39', '2022-07-25 09:53:51', '2022-07-25 09:53:51', '127');
INSERT INTO `vehicle_info` VALUES ('582', '21', 'LC0CE4CD1M1144621', '2', '0', '粤BIY55试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220728/945dcf0e65084578bf7b3c0771c27b1f.jpg', null, '39', '2022-07-28 09:18:06', '2022-07-28 09:18:06', '127');
INSERT INTO `vehicle_info` VALUES ('583', '20', 'LSVCH7NPXJN020858', '1', '0', '苏A92M8J', '7', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220728/9597b5b03c824fa091be62c81452de17.jpg', null, '39', '2022-07-28 09:20:02', '2022-07-28 09:20:02', '127');
INSERT INTO `vehicle_info` VALUES ('584', '20', 'LNAB1AB35M5504157', '2', '0', '粤BA94095', '29', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220728/b89272167c1a41b9b1d83031f36d57eb.jpg', null, '39', '2022-08-30 14:39:04', '2022-07-28 09:21:14', '134');
INSERT INTO `vehicle_info` VALUES ('585', '21', 'LC0C76C46N1143536', '1', '0', '粤BF58604', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220815/5780f0ea1ad14f2ea98079f12ff68e64.jpg', null, '39', '2022-08-15 09:43:14', '2022-08-15 09:43:14', '127');
INSERT INTO `vehicle_info` VALUES ('586', '21', 'LC0CE6CD7N1131708', '1', '0', '粤BAX4025', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220815/86a5c891acd948fd9a6862ec9875fd9c.jpg', null, '39', '2022-08-15 10:16:46', '2022-08-15 10:16:46', '127');
INSERT INTO `vehicle_info` VALUES ('587', '21', 'LC0C76C48N1143442', '1', '0', '粤BF03904', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220815/57f7c80d0b574a90afaade47e3e87ef1.jpg', null, '39', '2022-08-15 10:22:19', '2022-08-15 10:19:14', '127');
INSERT INTO `vehicle_info` VALUES ('588', '21', 'LJ1EFATR4M4061060', '1', '0', '浙AAD8982', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220815/617790b0ae974fb4b6cf26fce17f5b29.jpg', null, '39', '2022-08-15 10:23:23', '2022-08-15 10:23:23', '127');
INSERT INTO `vehicle_info` VALUES ('589', '21', 'LFV2B21K5B3257907', '1', '0', '粤BV0729', '7', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220815/1974eb3267554b4f8970c91692945fa3.jpg', null, '39', '2022-08-15 10:25:02', '2022-08-15 10:25:02', '127');
INSERT INTO `vehicle_info` VALUES ('590', '28', '5A2DJW3NA250100', '1', '0', '渝B8315试', '15', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/57996aa27176444080ce0e8ff3275d35.jpg', null, '39', '2022-08-16 09:15:01', '2022-08-16 09:15:01', '127');
INSERT INTO `vehicle_info` VALUES ('591', '28', 'LC0CF6CD4N1053997', '1', '0', '粤B85C3试', '15', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/5189eff8fd0d437fbb2653925dc35138.jpg', null, '39', '2022-08-16 10:53:20', '2022-08-16 09:16:20', '127');
INSERT INTO `vehicle_info` VALUES ('592', '28', 'LSJE36094NS077480', '1', '0', '粤B48G18试', '15', '19', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/aca8e6ba77724625b86380fb8547bd9b.jpg', null, '39', '2022-08-16 10:53:57', '2022-08-16 09:18:39', '127');
INSERT INTO `vehicle_info` VALUES ('593', '28', 'L6T79T2E7NP026531', '2', '0', '粤AJK315', '15', '32', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/d10a69c562ab4a279163bbc203d74060.jpg', null, '39', '2022-08-16 10:54:42', '2022-08-16 09:20:12', '127');
INSERT INTO `vehicle_info` VALUES ('594', '21', 'LC0C76C42N1143503', '1', '0', '粤BFL5471', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/f0a6a9b1121f47c59ce67fd71a0328bf.jpg', null, '39', '2022-08-16 09:33:17', '2022-08-16 09:33:17', '127');
INSERT INTO `vehicle_info` VALUES ('595', '21', 'LGXDF4CD9N2999030', '2', '0', '粤B3Y89试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/7b246f502ebf411685a18010b1b16f6d.jpg', null, '39', '2022-08-16 09:40:13', '2022-08-16 09:40:13', '127');
INSERT INTO `vehicle_info` VALUES ('596', '21', 'LGXCD1C42N0999009', '2', '0', '陕A9007试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/60aa249e168445d594e6f7a3041664e1.jpg', null, '39', '2022-08-16 10:10:17', '2022-08-16 10:10:17', '127');
INSERT INTO `vehicle_info` VALUES ('597', '21', 'LC0CF6CD3N1042229', '1', '0', '粤B85C6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/f55eca4c0f6e4216a75fb27f56fd4093.jpg', null, '39', '2022-08-16 10:19:53', '2022-08-16 10:19:53', '127');
INSERT INTO `vehicle_info` VALUES ('598', '28', 'LS5A2DJW3NA250100', '1', '0', '渝B8314试', '7', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/d8261e6b2fc9418294aae9bf5764e99a.jpg', null, '39', '2022-08-16 10:45:46', '2022-08-16 10:45:46', '127');
INSERT INTO `vehicle_info` VALUES ('599', '28', 'LJ1EFAUU7NG026807', '1', '0', '粤AAF0171', '7', '30', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220816/5e6b0bbc848d4ba6a7e6b1c449422e58.jpg', null, '39', '2022-08-16 14:57:27', '2022-08-16 14:57:27', '127');
INSERT INTO `vehicle_info` VALUES ('600', '28', 'LVSHNFAC6NE268337', '1', '0', '粤A66PDI', '7', '27', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220818/aa82226f05114761aa10a5e273f5a88f.jpg', null, '39', '2022-08-18 10:06:49', '2022-08-18 10:06:49', '127');
INSERT INTO `vehicle_info` VALUES ('601', '44', 'LK6ADAE27MB153101', '1', '0', '桂B1U20试', '7', '6', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220822/c6f6ca810b4448eca11bc80eabebf0b0.jpg', null, '39', '2022-08-22 09:13:18', '2022-08-22 09:13:18', '127');
INSERT INTO `vehicle_info` VALUES ('602', '21', 'LC0D74C47N0999121', '2', '0', '苏E9524试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220822/83786f6b7bed436c86bb9b672b57fbd9.jpg', null, '39', '2022-08-22 17:38:47', '2022-08-22 17:38:47', '127');
INSERT INTO `vehicle_info` VALUES ('603', '21', 'LFB1F0093N2A03920', '2', '0', '吉A9420试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220822/8525cf6216b04819880e155b4166341d.jpg', null, '39', '2022-08-22 20:54:10', '2022-08-22 20:54:10', '127');
INSERT INTO `vehicle_info` VALUES ('604', '21', 'LC0C76C43M1143493', '1', '0', '粤BFK0497', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220822/9bc986634b9e499da42d59bc035c1b09.jpg', null, '39', '2022-08-22 20:57:09', '2022-08-22 20:57:09', '127');
INSERT INTO `vehicle_info` VALUES ('605', '20', 'LNAB1AB33M5504674', '2', '0', '粤BDJ5719', '29', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220825/400553b407d843e6819c9887f0e40f74.jpg', null, '39', '2022-08-30 14:38:59', '2022-08-25 09:18:56', '134');
INSERT INTO `vehicle_info` VALUES ('606', '21', 'LC0DD4C49N0999114', '2', '0', '苏E9337试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220825/61e626c3a8984ebd8e1c434d15b08ac5.jpg', null, '39', '2022-08-25 09:19:54', '2022-08-25 09:19:54', '127');
INSERT INTO `vehicle_info` VALUES ('607', '21', 'LC0C76C48N1162489', '1', '0', '粤BM0419', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220905/57472e47c7264d61a753d1d90efcdba4.jpg', null, '36', '2023-04-17 12:06:05', '2022-09-05 09:43:16', '127');
INSERT INTO `vehicle_info` VALUES ('608', '21', 'LC0CE6CD2N1163045', '1', '0', '粤B9745Y', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220905/00c9321d8ac7480398e4bb7dddb88e22.jpg', null, '39', '2022-09-05 09:44:54', '2022-09-05 09:44:54', '127');
INSERT INTO `vehicle_info` VALUES ('609', '21', 'LC0D74C40N0104178', '5', '0', '粤B6Y97试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220905/192758764b0e41d19b69ced89659abd0.jpg', null, '39', '2022-12-12 09:56:43', '2022-09-05 14:01:17', '127');
INSERT INTO `vehicle_info` VALUES ('610', '21', 'LC0CE6CD2N1163014', '1', '0', '粤B9652Y', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220907/ecbc79486e934e7a8bcdbda4ea3ff80d.jpg', null, '39', '2022-09-07 16:00:51', '2022-09-07 16:00:51', '127');
INSERT INTO `vehicle_info` VALUES ('611', '21', 'LC0C76C48N1162511', '1', '0', '粤BG77311', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220907/66670b91e77647beb12ce03c5aad26b5.jpg', null, '39', '2022-09-15 15:16:48', '2022-09-07 16:01:58', '127');
INSERT INTO `vehicle_info` VALUES ('612', '21', 'LGXCD1C45N0999019', '2', '0', '陕A9083试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220907/993f257f5eba46598e49844c061bac12.jpg', null, '39', '2022-10-25 13:40:30', '2022-09-07 16:39:34', '127');
INSERT INTO `vehicle_info` VALUES ('613', '21', 'LC0C76C41N1162530', '1', '0', '粤BG77415', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220909/fa57505f2b984770918b34053236ab51.jpg', null, '39', '2022-09-09 16:16:51', '2022-09-09 16:16:51', '127');
INSERT INTO `vehicle_info` VALUES ('614', '21', 'LC0C76C49N1162727', '1', '0', '粤BG77739', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220913/4111e2d0d5fb466ca7ce7becb55a5d64.jpg', null, '39', '2022-09-13 14:37:42', '2022-09-13 14:37:42', '127');
INSERT INTO `vehicle_info` VALUES ('615', '21', 'LC0C76C44N1162506', '1', '0', '粤BFP7921', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220913/da7405c289564a46aa23fef923688b91.jpg', null, '39', '2022-09-13 14:38:42', '2022-09-13 14:38:42', '127');
INSERT INTO `vehicle_info` VALUES ('616', '21', 'LC0CE6CD9N1163026', '1', '0', '粤BDH7046', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220914/527a11f138794cb99609c97cb342f807.jpg', null, '39', '2022-09-14 15:31:41', '2022-09-14 15:31:41', '127');
INSERT INTO `vehicle_info` VALUES ('617', '21', 'LC0CE6CD9N1119608', '1', '0', '粤BDH0469', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220914/06183cc732784e169705bcc28dc95c45.jpg', null, '39', '2022-09-14 15:32:59', '2022-09-14 15:32:59', '127');
INSERT INTO `vehicle_info` VALUES ('618', '21', 'LC0C76C48N1162589', '1', '0', '粤BFM0419', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220915/1c80a93f86d54a42930f4430e4f50c14.jpg', null, '39', '2022-09-15 11:09:20', '2022-09-15 11:09:20', '127');
INSERT INTO `vehicle_info` VALUES ('620', '21', 'LC0C76C46N1162510', '1', '0', '粤BFK6497', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220915/f50f3374554a405c96271617b6ceb9a6.jpg', null, '39', '2022-09-15 16:41:23', '2022-09-15 16:41:23', '127');
INSERT INTO `vehicle_info` VALUES ('621', '21', 'LC0CE6CD8N1163051', '1', '0', '粤BAW0460', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220915/e8977e6c03cd4f7191cf14331330d3b0.jpg', null, '39', '2022-09-15 16:47:05', '2022-09-15 16:47:05', '127');
INSERT INTO `vehicle_info` VALUES ('622', '59', 'LSJE2409XMS113842', '2', '0', '沪T4277试', '18', '40', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220919/93dad29ded404ed685874b3154755c6c.jpg', null, '39', '2023-03-29 14:42:17', '2022-09-19 09:56:43', '134');
INSERT INTO `vehicle_info` VALUES ('623', '59', 'LSJE24090MS113817', '2', '0', '沪T4270试', '18', '40', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220919/bcf202830ce4445e98f67e52b7b976a2.jpg', null, '39', '2023-03-29 14:42:19', '2022-09-19 09:58:04', '134');
INSERT INTO `vehicle_info` VALUES ('624', '21', 'LGXC74C40M0038934', '1', '0', '粤B8Y35试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220922/2db7267f0fae4ba9877c4c1db4b733d5.jpg', null, '39', '2022-09-22 09:31:35', '2022-09-22 09:31:35', '127');
INSERT INTO `vehicle_info` VALUES ('625', '24', '3LN6L5SU3LR608173', '1', '0', '鲁HV1712', '7', '27', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220922/4be6c57960774a4a876fdf1702ba4e76.jpg', null, '39', '2022-09-22 16:52:18', '2022-09-22 16:52:18', '127');
INSERT INTO `vehicle_info` VALUES ('626', '24', 'LNAB1AB35M5504093', '2', '0', '鲁HY7527', '29', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220922/3fb63c644d5a4d8c8e89eca8d6f4dfdd.jpg', null, '39', '2022-09-23 10:25:37', '2022-09-22 16:53:56', '134');
INSERT INTO `vehicle_info` VALUES ('628', '28', 'LW433B125N1005287', '2', '0', '粤BG70253', '8', '30', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221011/bc868f9fe0e54bd39ac2d0aecd71bf71.jpg', null, '39', '2022-10-11 09:44:33', '2022-10-11 09:44:33', '127');
INSERT INTO `vehicle_info` VALUES ('629', '28', 'LFZ63AL44MD004578', '2', '0', '粤AAF7777', '8', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221011/5ddf55bc561942959a3d481657dbc027.jpg', null, '39', '2022-10-11 09:45:59', '2022-10-11 09:45:59', '127');
INSERT INTO `vehicle_info` VALUES ('630', '28', 'LM8F7D797NA084195', '2', '0', '粤BG30375', '8', '20', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221011/5e92449f3bde436f8a4cd9a2327471c6.jpg', null, '39', '2022-10-11 09:47:41', '2022-10-11 09:47:41', '127');
INSERT INTO `vehicle_info` VALUES ('631', '28', 'LGWFFVA7XMH250006', '2', '0', '湘H33788', '8', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221011/6634983f03ee4be1855c92343cda84c2.jpg', null, '39', '2022-10-11 09:49:10', '2022-10-11 09:49:10', '127');
INSERT INTO `vehicle_info` VALUES ('632', '21', 'LGWEF7A59KH508843', '2', '0', '冀A7Q1D7', '8', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221011/04bb32b3a92644228a743197163dbe91.jpg', null, '39', '2022-10-11 09:50:39', '2022-10-11 09:50:39', '127');
INSERT INTO `vehicle_info` VALUES ('633', '28', 'LSJE36097NS076629', '1', '0', '粤AAW6588', '7', '19', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221011/cf18846c240c47148e7baedf3fdf32fa.jpg', null, '39', '2022-10-11 10:45:15', '2022-10-11 10:45:15', '127');
INSERT INTO `vehicle_info` VALUES ('634', '21', 'LC0C76C45N1162529', '1', '0', '粤BFN7568', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221017/0dd7dccd395e4e1ea1f2596271126c6e.jpg', null, '39', '2023-03-14 14:07:30', '2022-10-17 13:44:36', '127');
INSERT INTO `vehicle_info` VALUES ('635', '21', 'LC0CE6CD3N120525', '1', '0', '粤B6Y94试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221017/8151b170a9404480ac38df9f48b050ab.jpg', null, '39', '2022-10-17 13:47:44', '2022-10-17 13:47:44', '127');
INSERT INTO `vehicle_info` VALUES ('636', '21', 'LC0CE6CD1N1209173', '1', '0', '粤B6Y90试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221017/c3cd1a4b13b94a0cbee35dd8b6305dc5.jpg', null, '39', '2022-10-17 13:48:48', '2022-10-17 13:48:48', '127');
INSERT INTO `vehicle_info` VALUES ('637', '49', 'LNBMC52K4NZ001436', '2', '0', '粤BD01436', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221018/5da30759cf3443a2b2791a16ba3bfb88.jpg', null, '39', '2022-10-18 17:15:06', '2022-10-18 16:03:04', '134');
INSERT INTO `vehicle_info` VALUES ('638', '49', 'LNBMC52KXNZ001537', '2', '0', '粤BD01537', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221018/53b65e8cee514bcea9e9765f0acb4c45.jpg', null, '39', '2022-10-18 17:32:22', '2022-10-18 17:32:22', '134');
INSERT INTO `vehicle_info` VALUES ('639', '49', 'LNBMC52K7NZ001527', '2', '0', '粤BD01527', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221019/9959c66cce404b619b5f12c016e78778.jpg', null, '39', '2022-10-19 09:37:51', '2022-10-19 09:37:51', '134');
INSERT INTO `vehicle_info` VALUES ('640', '49', 'LNBMC52KXNZ001487', '2', '0', '粤BD01487', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221019/4e62af9363a749f68d2e70bd14e4475c.jpg', null, '39', '2022-10-19 09:38:46', '2022-10-19 09:38:46', '134');
INSERT INTO `vehicle_info` VALUES ('641', '21', 'GXDF4CD6N29991010', '2', '0', '粤B7Y76试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221020/1111bbd6d35e4381afc4c6f58ae0a9e1.jpg', null, '39', '2022-10-20 14:42:28', '2022-10-20 14:42:28', '127');
INSERT INTO `vehicle_info` VALUES ('642', '21', 'LGXCE6CC6H0149163', '1', '0', '粤BDE8018', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221020/da45b0f9fe604dd9b5fe48959e44fdd4.jpg', null, '39', '2022-10-20 14:43:35', '2022-10-20 14:43:35', '127');
INSERT INTO `vehicle_info` VALUES ('644', '21', 'LC0C76C4XN1157780', '1', '0', '粤B7Y15试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221021/1559f8ff9e6c4b0980a236ee5e27ac74.jpg', null, '39', '2022-10-21 11:05:43', '2022-10-21 11:05:43', '127');
INSERT INTO `vehicle_info` VALUES ('645', '21', 'LGXC74C43N0528544', '2', '0', '粤B9Y25试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221025/f44936a1fdb84b399e325e13a47219fd.jpg', null, '39', '2023-03-20 09:08:48', '2022-10-25 13:41:53', '127');
INSERT INTO `vehicle_info` VALUES ('646', '21', 'LC0C74C40N1074458', '2', '0', '粤BFN0046', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221025/a3e11b23aeee4b878f4fe64dee6549ab.jpg', null, '39', '2022-10-25 13:43:06', '2022-10-25 13:43:06', '127');
INSERT INTO `vehicle_info` VALUES ('647', '21', 'LC0C76C48M115681', '1', '0', '粤B01A7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221101/3bbe3cdf9b8a488eb182e81f717aeefb.jpg', null, '39', '2022-11-01 13:28:44', '2022-11-01 13:28:44', '127');
INSERT INTO `vehicle_info` VALUES ('648', '21', 'LS4ASE2E8JJ182306', '1', '0', '苏A005AD', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221101/1cb6ad2f068742fc87cb96078b1fd31a.jpg', null, '39', '2022-11-01 13:30:03', '2022-11-01 13:30:03', '127');
INSERT INTO `vehicle_info` VALUES ('649', '21', 'LC0CF6CD1M1088981', '1', '0', '粤BAV5110', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221104/6a8186d4707e4211b3fc9e5c6381ef19.jpg', null, '39', '2022-11-04 10:35:33', '2022-11-04 10:35:33', '127');
INSERT INTO `vehicle_info` VALUES ('651', '21', 'LC0CE4CC8N0000238', '2', '0', '粤B83C0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221108/505d8ba17e7743a1aac1cbf03b5e1288.jpg', null, '39', '2022-11-08 15:30:25', '2022-11-08 15:30:25', '127');
INSERT INTO `vehicle_info` VALUES ('652', '21', 'LC0CE4CC7N0000196', '2', '0', '粤B8Y32试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221108/932f0682450b47a2b3b309decdfde578.jpg', null, '39', '2022-11-08 15:31:24', '2022-11-08 15:31:24', '127');
INSERT INTO `vehicle_info` VALUES ('653', '21', 'LLNC6AFC3K1014720', '2', '0', '浙F6GF36', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221109/0d96bbb7092941de87bbe20c90768131.jpg', null, '39', '2022-11-09 09:59:22', '2022-11-09 09:59:22', '127');
INSERT INTO `vehicle_info` VALUES ('654', '21', 'LGXC74C43N0431859', '2', '0', '粤BG70149', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221109/96d440a03ae34715a67bedcbb5f5e470.jpg', null, '39', '2022-11-09 17:04:04', '2022-11-09 17:04:04', '127');
INSERT INTO `vehicle_info` VALUES ('655', '21', 'LGXC74C4XM0411333', '2', '0', '粤B8625试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221110/411a8dd87a9d448484dc5af73d6e7a80.jpg', null, '39', '2022-11-10 14:21:04', '2022-11-10 14:21:04', '127');
INSERT INTO `vehicle_info` VALUES ('656', '21', 'LC0C74C44N1074348', '2', '0', '粤BFW2595', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221110/d88344c21a554091b06c17abfe8e6309.jpg', null, '39', '2022-11-10 16:20:01', '2022-11-10 16:20:01', '127');
INSERT INTO `vehicle_info` VALUES ('771', '49', 'LNBMC52K7NZ001415', '2', '1', '粤BD01415', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/296157f6855c40a8bba1c7250ba11f41.jpg', null, '39', '2023-03-29 14:04:00', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('772', '49', 'LNBMC52K2NZ001418', '2', '1', '粤BD01418', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/89579042ddfa417797ba53f3982a6b19.jpg', null, '39', '2023-03-29 14:03:55', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('773', '49', 'LNBMC52K3NZ001427', '2', '1', '粤BD01427', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/3c6a98d00ce34839aaee1cab3c41a879.jpg', null, '39', '2023-03-29 14:03:51', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('774', '49', 'LNBMC52K7NZ001432', '2', '1', '粤BD01432', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/4f5b02c89872416ba40dbce65fa4fdbd.jpg', null, '39', '2023-03-29 14:03:47', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('775', '49', 'LNBMC52KXNZ001439', '2', '1', '粤BD01439', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/acdc3bab403a4c64984dba41234434ea.jpg', null, '39', '2023-03-29 14:03:41', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('776', '49', 'LNBMC52K8NZ001441', '2', '1', '粤BD01441', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/01178875e8b6404aa74a263bf3b9132f.jpg', null, '39', '2023-03-29 14:05:12', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('777', '49', 'LNBMC52K1NZ001443', '2', '1', '粤BD01443', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/43774b6c035042549d9ea97e786cc374.jpg', null, '39', '2023-03-29 14:05:08', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('778', '49', 'LNBMC52K7NZ001446', '2', '1', '粤BD01446', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/9f4298870e374202b7f63f969c5feeee.jpg', null, '39', '2023-03-29 14:05:04', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('779', '49', 'LNBMC52K4NZ001453', '2', '1', '粤BD01453', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/75633bf109d443a59274a1e399545499.jpg', null, '39', '2023-03-29 14:05:00', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('780', '49', 'LNBMC52K7NZ001463', '2', '1', '粤BD01463', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/754f1a62cd9b443080a2fe99a0c6781f.jpg', null, '39', '2023-03-29 14:04:56', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('781', '49', 'LNBMC52K0NZ001465', '2', '1', '粤BD01465', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/125916c0df2643dcb951ec50f363a908.jpg', null, '39', '2023-03-29 14:04:52', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('782', '49', 'LNBMC52K4NZ001467', '2', '1', '粤BD01467', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/598829aeb08e4e6b8089b80d903edb59.jpg', null, '39', '2023-03-29 14:04:49', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('783', '49', 'LNBMC52K1NZ001474', '2', '1', '粤BD01474', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/90d228f68db24dc695c4c0500830e7fa.jpg', null, '39', '2023-03-29 14:04:45', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('784', '49', 'LNBMC52K7NZ001477', '2', '1', '粤BD01477', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/64a767cbaabd45e58acba2a56ffabffc.jpg', null, '39', '2023-03-29 14:02:58', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('785', '49', 'LNBMC52K9NZ001478', '2', '1', '粤BD01478', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/f6d6eed93e5d49ae8e112050d3a087d2.jpg', null, '39', '2023-03-29 14:02:48', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('786', '49', 'LNBMC52K1NZ001491', '2', '1', '粤BD01491', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/41b7b421db444e9dbb200790654926e9.jpg', null, '39', '2023-03-29 14:02:41', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('787', '49', 'LNBMC52K5NZ001493', '2', '1', '粤BD01493', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/bb099b4fa56544928b9b72106964b277.jpg', null, '39', '2023-03-29 14:02:37', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('788', '49', 'LNBMC52K7NZ001494', '2', '1', '粤BD01494', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/ecafd84e420e4575a7ad9ec409b2893a.jpg', null, '39', '2023-03-29 14:02:31', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('789', '49', 'LNBMC52K9NZ001500', '2', '1', '粤BD01500', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/313813e7a2374f4fa823b8b7ce35be1e.jpg', null, '39', '2023-03-29 14:02:27', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('790', '49', 'LNBMC52K1NZ001507', '2', '1', '粤BD01507', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/0f0d1c15c2fd417c8c09bab760ecc343.jpg', null, '39', '2023-03-29 14:02:23', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('791', '49', 'LNBMC52K7NZ001513', '2', '1', '粤BD01513', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/205324fdf7f8418fbe983837f22c1d8c.jpg', null, '39', '2023-03-29 14:02:20', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('792', '49', 'LNBMC52K6NZ001518', '2', '1', '粤BD01518', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/9051441e87134ede9bc9a642c89c981a.jpg', null, '39', '2023-03-29 14:02:15', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('793', '49', 'LNBMC52K9NZ001531', '2', '1', '粤BD01531', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/f5f0a2a35b2d4f0cb8354cd59e963324.jpg', null, '39', '2023-03-29 14:02:10', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('794', '49', 'LNBMC52K0NZ001532', '2', '1', '粤BD01532', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/f9218d0a0b4f4f58a2d13c0c12cfc815.jpg', null, '39', '2023-03-29 14:02:01', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('795', '49', 'LNBMC52K9NZ001545', '2', '1', '粤BD01545', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/559cbd9bbec94c7489bdb90203c02e99.jpg', null, '39', '2023-03-29 14:01:52', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('796', '49', 'LNBMC52K4NZ001548', '2', '1', '粤BD01548', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/13ea61118614407dbd87a07d893b5885.jpg', null, '39', '2023-03-29 14:01:47', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('797', '49', 'LNBMC52K4NZ001551', '2', '1', '粤BD01551', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/28b44cb5440c436bad96798b945852cc.jpg', null, '39', '2023-03-29 14:01:43', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('798', '49', 'LNBMC52K6NZ001552', '2', '1', '粤BD01552', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/e81c59b751f94dcc97c753062bb6aae5.jpg', null, '39', '2023-03-29 14:01:39', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('799', '49', 'LNBMC52KXNZ001554', '2', '1', '粤BD01554', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/aaa46c29e4264d84a9a8c97b2d230e7b.jpg', null, '39', '2023-03-29 14:01:33', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('800', '49', 'LNBMC52K5NZ001560', '2', '1', '粤BD01560', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/28a11c34cec04df8bfc1a1add6034745.jpg', null, '39', '2023-03-29 14:01:28', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('801', '49', 'LNBMC52K8NZ001567', '2', '1', '粤BD01567', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/e0b5fea7ed744adb996106d5e30c1f0a.jpg', null, '39', '2023-03-29 14:01:25', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('802', '49', 'LNBMC52K1NZ001572', '2', '1', '粤BD01572', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/11b0b8b205ba4d8790a83219bda3c00b.jpg', null, '39', '2023-03-29 14:01:21', '2022-11-14 09:39:05', '134');
INSERT INTO `vehicle_info` VALUES ('834', '21', 'LC0C74C4XN1074550', '2', '0', '粤BFN6660', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221114/1c6952511e5f4cbdbdeb43d059c75c50.jpg', null, '39', '2022-11-14 15:20:10', '2022-11-14 15:20:10', '127');
INSERT INTO `vehicle_info` VALUES ('835', '21', 'LSGGJ5457JS134402', '1', '0', '粤BJ551A', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221114/7876fca5b572420dbec65e683ec1dbc3.jpg', null, '39', '2022-11-14 15:21:16', '2022-11-14 15:21:16', '127');
INSERT INTO `vehicle_info` VALUES ('836', '21', 'LS6A2E16XNA502684', '1', '0', '粤AB11875', '7', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221116/48614e150aa445018d9f73644fc795a4.jpg', null, '39', '2022-11-16 10:03:00', '2022-11-16 10:03:00', '127');
INSERT INTO `vehicle_info` VALUES ('837', '21', 'L6179P2N4NP007538', '2', '0', '粤AAG8088', '8', '32', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221116/231ac0665a3049ae89600056121aea7e.jpg', null, '39', '2022-11-16 10:04:08', '2022-11-16 10:04:08', '127');
INSERT INTO `vehicle_info` VALUES ('838', '21', 'LGXCH6CD1N2107368', '1', '0', '粤B78D3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221116/59356d146e1b4884b062eb655ab53100.jpg', null, '39', '2022-11-16 10:37:49', '2022-11-16 10:37:49', '127');
INSERT INTO `vehicle_info` VALUES ('839', '21', 'LC0CE6CD4N1163094', '1', '0', '粤BDN4068', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221118/930e07465ca041d69124321767f4aeec.jpg', null, '39', '2022-11-18 15:01:09', '2022-11-18 15:01:09', '127');
INSERT INTO `vehicle_info` VALUES ('840', '21', 'LGXCD4C47N0132061', '2', '0', '陕A9108试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221118/6e1ba70d4182420487bebc104a85300e.jpg', null, '39', '2022-11-18 15:02:14', '2022-11-18 15:02:14', '127');
INSERT INTO `vehicle_info` VALUES ('842', '21', 'LC0CE6CD4N1162897', '1', '0', '粤BDN0486', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221125/708ab3294ffe409dbc9b59338d0172bd.jpg', null, '39', '2022-11-25 18:55:37', '2022-11-25 14:54:52', '127');
INSERT INTO `vehicle_info` VALUES ('843', '21', 'LC0CE6CDXN1162872', '1', '0', '粤BDN4401', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221126/5333911efa7c43d6891df5021e54c945.jpg', null, '39', '2022-11-26 10:39:35', '2022-11-26 10:39:35', '127');
INSERT INTO `vehicle_info` VALUES ('844', '21', 'LGXCD1C43N099021', '2', '0', '陕A9075试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221128/1be48ead711f4f9f8b674ed14ff54a88.jpg', null, '39', '2022-11-28 10:24:04', '2022-11-28 10:24:04', '127');
INSERT INTO `vehicle_info` VALUES ('845', '59', 'LSJE24093MS114265', '2', '1', '沪T4274试', '18', '40', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221128/2cd9e8f582534f1d8086309497cbcc39.jpg', null, '36', '2023-03-29 14:42:09', '2022-11-28 12:30:06', '134');
INSERT INTO `vehicle_info` VALUES ('846', '59', 'LSJE24099MS113377', '2', '0', '沪T4275试', '18', '40', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221128/9a25b791536c4fa7879efe9d46342663.jpg', null, '36', '2023-03-29 14:42:23', '2022-11-28 12:32:05', '134');
INSERT INTO `vehicle_info` VALUES ('847', '59', 'LSJE24092MS114256', '2', '1', '沪T4273试', '18', '40', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221128/125c5bccf5a94762bb016c386d4f4943.jpg', null, '36', '2023-03-29 14:42:12', '2022-11-28 12:33:05', '134');
INSERT INTO `vehicle_info` VALUES ('848', '21', 'LGXCF6CD7M2999100', '1', '0', '粤B70D4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221205/0f63781816e046d0ad3aa659c8cbcd1e.jpg', null, '39', '2022-12-05 16:30:03', '2022-12-05 16:30:03', '127');
INSERT INTO `vehicle_info` VALUES ('849', '21', 'LC0CD4C42N1037968', '2', '0', '粤B4Y66试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221206/7f7177652d594ca48b425c52e980ecc7.jpg', null, '39', '2022-12-06 10:04:29', '2022-12-06 10:04:29', '127');
INSERT INTO `vehicle_info` VALUES ('851', '21', 'LC0DE4CD2N0990221', '5', '0', '粤B81C3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221209/f70349f936524abfaf2c21807376ddca.jpg', null, '39', '2022-12-09 17:22:12', '2022-12-09 17:22:12', '127');
INSERT INTO `vehicle_info` VALUES ('853', '21', 'LGXCH6CD3N2177793', '1', '0', '粤AZ8200', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221212/bc1bfdca8263490a94a41b3744d49025.jpg', null, '39', '2022-12-12 13:25:09', '2022-12-12 13:25:09', '127');
INSERT INTO `vehicle_info` VALUES ('855', '21', 'LC0CE4CB0N0390324', '1', '0', '粤B8Y94试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221213/a4d7f835a0a64337ad6ba8925568d45d.jpg', null, '39', '2022-12-13 14:44:25', '2022-12-13 14:44:25', '127');
INSERT INTO `vehicle_info` VALUES ('856', '21', 'LC0CE4CB9M0038602', '1', '0', '粤B92C4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221213/b58e87ee850442de9ebd2243e1b5c151.jpg', null, '39', '2022-12-13 14:45:21', '2022-12-13 14:45:21', '127');
INSERT INTO `vehicle_info` VALUES ('857', '28', 'LE4EG2BB9NN000143', '2', '0', '冀T3030K', '8', '12', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221214/26ced49cce404a348f4e07f804a53700.jpg', null, '39', '2022-12-14 09:49:04', '2022-12-14 09:49:04', '127');
INSERT INTO `vehicle_info` VALUES ('858', '21', 'LC0DD4C43N0434857', '5', '0', '粤B05E1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221216/ae555dda552d455099ab061ba2926e2a.jpg', null, '39', '2022-12-16 17:42:13', '2022-12-16 17:42:13', '127');
INSERT INTO `vehicle_info` VALUES ('859', '21', 'LGWEF7A54KH504557', '2', '0', '晥HQ8324', '8', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221220/2a9ccae5a2f64e94838e3ee2ed7e75a2.jpg', null, '39', '2022-12-20 10:19:11', '2022-12-20 10:19:11', '127');
INSERT INTO `vehicle_info` VALUES ('860', '21', 'LC0C76C40M0999922', '1', '0', '陕A9137试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221220/e331a8786d0c4f55a3ee70d37f8ee180.jpg', null, '39', '2022-12-20 10:57:51', '2022-12-20 10:57:51', '127');
INSERT INTO `vehicle_info` VALUES ('861', '21', 'LC0C76C4GN1162650', '1', '0', '粤BFY4926', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221220/f79065747b8d4585a286509d9ef81096.jpg', null, '39', '2022-12-20 16:32:00', '2022-12-20 16:32:00', '127');
INSERT INTO `vehicle_info` VALUES ('862', '21', 'LGXC74C42N0528373', '2', '0', '粤B5Y74试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221220/bf6cbf6936d1471a9fb4b9c52acf6443.jpg', null, '39', '2023-03-29 15:16:41', '2022-12-20 16:33:11', '127');
INSERT INTO `vehicle_info` VALUES ('863', '21', 'LGXCE4CB0N2149669', '1', '0', '粤B61D1试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221221/d75559c54e8c4a85b50586ea138f7784.jpg', null, '39', '2022-12-21 10:06:23', '2022-12-21 10:06:23', '127');
INSERT INTO `vehicle_info` VALUES ('864', '21', 'LGXC74C40N0511720', '1', '0', '粤B5Y05试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221221/971df68e80e04eeb97cefe58194266a9.jpg', null, '39', '2022-12-21 16:53:54', '2022-12-21 16:53:54', '127');
INSERT INTO `vehicle_info` VALUES ('865', '21', 'LC0C76C49N1082053', '1', '0', '粤B7Y09试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221221/bff2a2f089184fd9b89fb7fd2bc0b613.jpg', null, '39', '2022-12-21 16:54:46', '2022-12-21 16:54:46', '127');
INSERT INTO `vehicle_info` VALUES ('866', '21', 'LC0CF6CD5N1237006', '1', '0', '粤B79D6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221222/d50b0a38ed184e8e82ebc3031b6a8329.jpg', null, '39', '2022-12-22 10:28:02', '2022-12-22 10:28:02', '127');
INSERT INTO `vehicle_info` VALUES ('867', '21', 'LC0CF6CD7N1236486', '1', '0', '粤B79D3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221222/3e90001d924c4b68adf05cec70ebdfd8.jpg', null, '39', '2022-12-22 14:16:03', '2022-12-22 14:16:03', '127');
INSERT INTO `vehicle_info` VALUES ('868', '21', 'LGXEK1C45N099905', '2', '0', '陕A4260试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221225/fc67e86205f040f7866ef1a71fbcaf12.jpg', null, '39', '2022-12-25 13:01:48', '2022-12-25 13:01:48', '127');
INSERT INTO `vehicle_info` VALUES ('869', '21', 'LC0CE6CD5N1163122', '1', '0', '粤BDM1943', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221225/54e7b37f86364bcbb65c11067197b0b1.jpg', null, '39', '2022-12-25 13:03:41', '2022-12-25 13:03:41', '127');
INSERT INTO `vehicle_info` VALUES ('871', '21', 'LGXC74C47N0545329', '2', '0', '粤B65D8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221227/1d24816efa6a4d9ebcdc97e1b4c7262d.jpg', null, '39', '2022-12-27 15:42:58', '2022-12-27 15:42:58', '127');
INSERT INTO `vehicle_info` VALUES ('873', '23', 'LGWEFUA59NH262685', '2', '0', '翼T3168K', '8', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20221228/34a2580942604db0ad32aa0d21609577.jpg', null, '39', '2022-12-28 09:19:05', '2022-12-28 09:19:05', '127');
INSERT INTO `vehicle_info` VALUES ('876', '21', 'LC0CE4CD2N0499448', '1', '0', '粤B95D8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230103/00a6a6b6374044eb891749b089556896.jpg', null, '39', '2023-01-03 09:11:48', '2023-01-03 09:11:48', '127');
INSERT INTO `vehicle_info` VALUES ('877', '21', 'LC0C74C47N1074375', '2', '0', '粤BFW5205', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230103/ead6bb0aff0542c0915a69dc64f390b1.jpg', null, '39', '2023-01-03 09:12:47', '2023-01-03 09:12:47', '127');
INSERT INTO `vehicle_info` VALUES ('878', '21', 'LC0C74C46N0397208', '1', '0', '粤B5Y45试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230103/5ec15b78cc3546d788e231dabe4d383c.jpg', null, '39', '2023-01-03 09:14:02', '2023-01-03 09:14:02', '127');
INSERT INTO `vehicle_info` VALUES ('879', '21', 'LC0CE6CD7N1163056', '1', '0', '粤BDG4456', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230103/720bc952df1748dab24244a7e742196f.jpg', null, '39', '2023-01-03 09:15:10', '2023-01-03 09:15:10', '127');
INSERT INTO `vehicle_info` VALUES ('880', '21', 'LGXC14C47N0528367', '2', '0', '粤BCY73试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230103/4c97ef3eeb984e03a3a3219b86c904e7.jpg', null, '39', '2023-01-03 09:16:12', '2023-01-03 09:16:12', '127');
INSERT INTO `vehicle_info` VALUES ('881', '21', 'LGXCF6CDXN2134087', '1', '0', '粤B6Y51试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230103/68fb737957d54901880c898a7b26e477.jpg', null, '39', '2023-01-03 09:20:43', '2023-01-03 09:20:43', '127');
INSERT INTO `vehicle_info` VALUES ('882', '21', 'LGXC74C4XN0548080', '1', '0', '粤B69D9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230412/6dfe42a015ee455583eb7b843ef6710d.jpg', null, '36', '2023-04-12 15:01:20', '2023-01-03 15:29:30', '127');
INSERT INTO `vehicle_info` VALUES ('883', '21', 'LGXCD1C4XN0999064', '2', '0', '陕A9086试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230105/557bc561374f4652b30895df6dad2cba.jpg', null, '39', '2023-01-05 10:28:05', '2023-01-05 10:28:05', '127');
INSERT INTO `vehicle_info` VALUES ('884', '21', 'LC0C74C48N0390247', '5', '0', '粤B57D4试', '3', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230109/5c94294b759f4edf8a388e4d758d4a14.jpg', null, '39', '2023-01-09 10:52:49', '2023-01-09 10:52:49', '127');
INSERT INTO `vehicle_info` VALUES ('886', '21', 'LC0C76C4XM0999913', '2', '0', '陕A9109试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230109/34f3e7de97554258b659576be72eccaa.jpg', null, '39', '2023-01-09 10:56:33', '2023-01-09 10:56:33', '127');
INSERT INTO `vehicle_info` VALUES ('887', '21', 'LGXDF4CD7N2999186', '2', '0', '粤B96D7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230110/0f967be11d3f4aa5b1b1aa1a075cc861.jpg', null, '39', '2023-01-10 14:21:11', '2023-01-10 14:21:11', '127');
INSERT INTO `vehicle_info` VALUES ('888', '21', 'LC0C76C44M0999910', '1', '0', '粤B06E5试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230131/656f6421e59041a8b59195e34f097d1e.jpg', null, '39', '2023-01-31 10:18:55', '2023-01-31 10:18:55', '127');
INSERT INTO `vehicle_info` VALUES ('889', '21', 'LC0CE4CBXN0345438', '1', '0', '粤B8Y95试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230131/dd486dee5775451e90637a5080eb665c.jpg', null, '39', '2023-01-31 10:36:58', '2023-01-31 10:36:58', '127');
INSERT INTO `vehicle_info` VALUES ('890', '21', 'LGXCE4CCXN0999685', '1', '0', '粤B20E8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230131/a6e53df58cf041eb9d165604bb78e7f9.jpg', null, '39', '2023-01-31 10:44:27', '2023-01-31 10:44:27', '127');
INSERT INTO `vehicle_info` VALUES ('891', '21', 'LSJES6095NS0853331', '1', '0', '苏EDT9031', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230201/27d75d540857498ca330c17dc2b2dbcd.jpg', null, '39', '2023-02-01 11:02:23', '2023-02-01 11:02:23', '127');
INSERT INTO `vehicle_info` VALUES ('892', '21', 'LC0CE4CB2N0390325', '1', '0', '粤B70D6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230201/5c78723f629a4b96ab2b23d436b916af.jpg', null, '39', '2023-02-01 11:04:23', '2023-02-01 11:04:23', '127');
INSERT INTO `vehicle_info` VALUES ('893', '21', 'LSGZR5356LH108618', '1', '0', '粤AD07K6', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230201/bc44ffab80ee47cf9e7b52bd893ee2fc.jpg', null, '39', '2023-02-01 11:09:00', '2023-02-01 11:09:00', '127');
INSERT INTO `vehicle_info` VALUES ('894', '21', 'LGXCL4CB9N2111311', '1', '0', '粤B61D0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230203/0d90677ce3134af7bfadc2a6e6a1f471.jpg', null, '39', '2023-02-03 16:08:50', '2023-02-03 16:08:50', '127');
INSERT INTO `vehicle_info` VALUES ('895', '21', 'LGXC74C43N0538667', '2', '0', '粤B5Y20试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230203/4288870463cf4c5387bcfa4587511635.jpg', null, '39', '2023-02-03 16:10:27', '2023-02-03 16:10:27', '127');
INSERT INTO `vehicle_info` VALUES ('896', '21', 'LGXC7445N0132065', '2', '0', '陕A9314试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230203/315c13c1ef11430bb516c78ef03f11c9.jpg', null, '39', '2023-02-03 16:11:27', '2023-02-03 16:11:27', '127');
INSERT INTO `vehicle_info` VALUES ('897', '21', 'LGXCD1C4XN0999050', '2', '0', '陕A4704试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230203/47c0c827fb664013a23ae072e729e1a5.jpg', null, '39', '2023-02-03 16:12:17', '2023-02-03 16:12:17', '127');
INSERT INTO `vehicle_info` VALUES ('898', '21', 'LGXEK1C43N0999048', '2', '0', '陕A9327试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230206/aba28714fd664cd083f73ff9a10fbc2f.jpg', null, '39', '2023-02-06 10:53:57', '2023-02-06 10:53:57', '127');
INSERT INTO `vehicle_info` VALUES ('899', '21', 'LC0D74C4XN0399774', '5', '0', '粤B67D6试', '3', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230207/ec05b568fe6a4112bce93817f2714b0a.jpg', null, '39', '2023-02-07 14:38:13', '2023-02-07 14:38:13', '127');
INSERT INTO `vehicle_info` VALUES ('900', '21', 'LGXDF4CD8N2999150', '2', '0', '粤B72D3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230207/d3a23a9a9b274724bdc358caa7e98ea3.jpg', null, '39', '2023-02-07 14:39:05', '2023-02-07 14:39:05', '127');
INSERT INTO `vehicle_info` VALUES ('901', '20', 'LGG8D3D13JZ438992', '2', '0', '苏A61R7L', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230207/fe85f2353707447fbe3eba2d46c0df52.jpg', null, '39', '2023-02-07 15:20:02', '2023-02-07 15:18:38', '127');
INSERT INTO `vehicle_info` VALUES ('902', '21', 'LGXEK1C43N099948', '2', '0', '陕A9327试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230207/b19fb8cae2994fb4b3a560fbb2377899.jpg', null, '39', '2023-02-07 15:21:21', '2023-02-07 15:21:21', '127');
INSERT INTO `vehicle_info` VALUES ('903', '20', 'HJRPBGGB5NB470198', '2', '0', '皖B3415试', '8', '21', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230208/29d165e227bf4f23b9b1546daa7c4ee4.jpg', null, '39', '2023-02-08 09:33:37', '2023-02-08 09:33:37', '127');
INSERT INTO `vehicle_info` VALUES ('904', '21', 'LGXCF4CFN0528543', '1', '0', '粤B9Y26试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230210/03367051b6fb4e93bf5f7c896a5e2bf5.jpg', null, '39', '2023-02-10 16:13:18', '2023-02-10 16:13:18', '127');
INSERT INTO `vehicle_info` VALUES ('905', '21', 'LC0CE4CB0N0162422', '1', '0', '粤B19E8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230210/0e9f1800445043d0ba9ec9114bd7146e.jpg', null, '39', '2023-02-10 16:14:11', '2023-02-10 16:14:11', '127');
INSERT INTO `vehicle_info` VALUES ('907', '21', 'LC0CE4DC0M0027303', '2', '0', '粤BAQ7358', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230211/ebef0a59145b416fafaed18e45634f14.jpg', null, '39', '2023-02-11 19:36:40', '2023-02-11 19:36:40', '127');
INSERT INTO `vehicle_info` VALUES ('908', '21', 'LC0CD4C48N0264457', '2', '0', '粤B68D9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230211/81f8d23a20a347ea959958866f9fffd3.jpg', null, '39', '2023-02-11 19:39:23', '2023-02-11 19:39:23', '127');
INSERT INTO `vehicle_info` VALUES ('909', '21', 'LW433B129N1029608', '2', '0', '粤BG71493', '8', '30', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230211/4d8e8615ae9048328b27307b1ce0237e.jpg', null, '39', '2023-02-11 19:40:43', '2023-02-11 19:40:43', '127');
INSERT INTO `vehicle_info` VALUES ('912', '21', 'LM8F7D793NA092665', '2', '0', '粤BFB1125', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230211/7e081bec68d84671ac8ea6fa163f1155.jpg', null, '39', '2023-02-11 19:45:07', '2023-02-11 19:45:07', '127');
INSERT INTO `vehicle_info` VALUES ('913', '21', 'LGXC74C48M0124301', '1', '0', '粤BFZ4753', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230211/de167925f81c4019b1fe7ecb6aeea2e6.jpg', null, '39', '2023-02-11 19:48:31', '2023-02-11 19:48:31', '127');
INSERT INTO `vehicle_info` VALUES ('914', '21', 'LGXC74C48N0460094', '2', '0', '粤B5Y43试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230211/82e00846b3004cc0a0d4494458fe44b0.jpg', null, '39', '2023-02-14 09:08:04', '2023-02-11 19:51:39', '127');
INSERT INTO `vehicle_info` VALUES ('915', '21', 'LC0CE6CD3M1020555', '1', '0', '粤B08956', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230214/a09ad99a6c2a41848b6cfb4a9ff6440b.jpg', null, '39', '2023-02-14 11:01:46', '2023-02-14 11:01:46', '127');
INSERT INTO `vehicle_info` VALUES ('917', '21', 'LSVX225N6K20230603', '1', '0', '浙JY36V8', '7', '3', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230214/f003365bbba342bca95cb947c1bf3537.jpg', null, '39', '2023-02-14 11:03:41', '2023-02-14 11:03:41', '127');
INSERT INTO `vehicle_info` VALUES ('918', '21', 'LGXC74C45N0511888', '2', '0', '粤B5Y03试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230214/ceaf5e004c8a48158e8e1558ddad2c1a.jpg', null, '39', '2023-02-14 14:11:56', '2023-02-14 14:11:56', '127');
INSERT INTO `vehicle_info` VALUES ('921', '21', 'LGXEK1C45N009991', '2', '0', '粤B42E7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230215/72df207694eb4f90939842cfed565bd2.jpg', null, '39', '2023-02-15 16:02:34', '2023-02-15 16:02:34', '127');
INSERT INTO `vehicle_info` VALUES ('922', '21', 'LC0C76C49N114365', '1', '0', '粤BFK4261', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230215/ffec4ae8822d4dc583f642b080ed38e1.jpg', null, '39', '2023-02-15 16:03:20', '2023-02-15 16:03:20', '127');
INSERT INTO `vehicle_info` VALUES ('923', '21', 'LC0C76C49N1146348', '1', '0', '粤B7Y13试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230215/cf1014be321b434ca7b75074f1be1667.jpg', null, '39', '2023-02-15 16:04:11', '2023-02-15 16:04:11', '127');
INSERT INTO `vehicle_info` VALUES ('924', '21', 'LC0D74C41N0441670', '5', '0', '粤B57D3试', '3', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230216/83e6bc8c716143ad884634a51225460e.jpg', null, '39', '2023-02-16 09:56:29', '2023-02-16 09:56:29', '127');
INSERT INTO `vehicle_info` VALUES ('925', '21', 'LC0DE4CD5N0432380', '5', '0', '粤B94D9试', '3', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230216/2b6860a0923845c29cc2127235c1e856.jpg', null, '39', '2023-02-16 10:08:40', '2023-02-16 10:08:40', '127');
INSERT INTO `vehicle_info` VALUES ('926', '20', 'LH16CGJ04NH002372', '2', '0', '琼A7977试', '8', '31', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230216/cff397f27e264c14a4db57f9ecd3f768.jpg', null, '39', '2023-02-16 14:17:18', '2023-02-16 14:17:18', '127');
INSERT INTO `vehicle_info` VALUES ('927', '20', 'LH16GGJ05NH002381', '2', '0', '琼A7978试', '8', '31', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230216/0633e7527370423d81020548bf7cb8bc.jpg', null, '39', '2023-02-17 10:48:44', '2023-02-16 14:18:07', '127');
INSERT INTO `vehicle_info` VALUES ('928', '21', 'LN16CGJ04NH002372', '1', '0', '粤A7978试', '7', '31', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230217/2048b09b5226476fac15fbe89ca7c985.jpg', null, '39', '2023-02-17 10:44:52', '2023-02-17 10:44:52', '127');
INSERT INTO `vehicle_info` VALUES ('929', '20', 'LH16GGJ04NH002372', '1', '0', '琼A7977试', '7', '31', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230217/ff6a918537e94b71861df3970910e80a.jpg', null, '39', '2023-02-17 10:48:37', '2023-02-17 10:48:37', '127');
INSERT INTO `vehicle_info` VALUES ('931', '21', 'LC0DF4CDXN0440875', '1', '0', '湘A2364试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230217/4b0267da9f044eab91de32536e84d8c2.jpg', null, '39', '2023-02-17 14:25:13', '2023-02-17 14:25:13', '127');
INSERT INTO `vehicle_info` VALUES ('932', '20', 'LH16GGJ03NH001729', '2', '0', '琼A8000试', '8', '31', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230220/854e60c322fc45948826c1a1f69df023.jpg', null, '39', '2023-02-20 09:16:40', '2023-02-20 09:16:40', '127');
INSERT INTO `vehicle_info` VALUES ('933', '20', 'LGXCD1C43N0999066', '2', '0', '陕A9088试', '8', '31', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230220/35c108bbd1be48ba85f3f6df4c115905.jpg', null, '39', '2023-02-20 09:17:20', '2023-02-20 09:17:20', '127');
INSERT INTO `vehicle_info` VALUES ('934', '21', 'LC0C76C42N0455892', '2', '0', '粤B25E1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230222/6bd4b229d84a45f0a2f12c6d745bf9f7.jpg', null, '39', '2023-02-22 13:45:28', '2023-02-22 13:45:28', '127');
INSERT INTO `vehicle_info` VALUES ('935', '21', 'LC0C76C47N0444497', '2', '0', '粤B24E9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230222/5377afd9ae74492fbd385a943b6c3eb0.jpg', null, '39', '2023-02-22 13:46:19', '2023-02-22 13:46:19', '127');
INSERT INTO `vehicle_info` VALUES ('936', '21', 'LC0CE4CB3N0999', '2', '0', '苏E0588试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230223/4fd6366d44c441a0a3789002f7bd9f2f.jpg', null, '39', '2023-02-23 09:58:42', '2023-02-23 09:58:42', '127');
INSERT INTO `vehicle_info` VALUES ('937', '21', 'LC0CE6CD2N1238245', '2', '0', '粤B71D8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230223/7d3dcd552080401fbefa7ea3413af604.jpg', null, '39', '2023-02-23 10:00:30', '2023-02-23 10:00:30', '127');
INSERT INTO `vehicle_info` VALUES ('938', '21', 'LC0C76C47N1276774', '2', '0', '粤B15E6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230223/e025d0fd0ca44dfc8a023f45e7da0f38.jpg', null, '39', '2023-02-23 10:02:00', '2023-02-23 10:02:00', '127');
INSERT INTO `vehicle_info` VALUES ('940', '21', 'LC0CE6CD5N1166327', '1', '0', '粤B37E8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230224/4af9a62d73a74f41a7225b1775d0b27d.jpg', null, '39', '2023-02-24 15:36:06', '2023-02-24 15:36:06', '127');
INSERT INTO `vehicle_info` VALUES ('941', '20', 'LH16GGJ0XNH001727', '2', '0', '琼A7999试', '8', '31', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230225/d28844f6011b41c294b2a4207527cd2b.jpg', null, '39', '2023-02-25 10:29:12', '2023-02-25 10:29:12', '127');
INSERT INTO `vehicle_info` VALUES ('942', '21', 'LC0DF4CD3N0387968', '5', '0', '粤B99D6试', '3', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230301/42333535c2c4417ea5a9f1900a95fa77.jpg', null, '39', '2023-03-01 14:08:33', '2023-03-01 14:08:33', '127');
INSERT INTO `vehicle_info` VALUES ('943', '21', 'LCOCF6CD3M1112505', '1', '0', '粤B6Y87试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230301/65fa391ec84345609e0d5a29cbf2613b.jpg', null, '39', '2023-03-01 14:09:27', '2023-03-01 14:09:27', '127');
INSERT INTO `vehicle_info` VALUES ('944', '21', 'LSJE36096NS093082', '1', '0', '粤B663NX', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230301/43ec944691e24a58a9251ee7d697f638.jpg', null, '39', '2023-03-01 14:10:05', '2023-03-01 14:10:05', '127');
INSERT INTO `vehicle_info` VALUES ('945', '21', 'LGXCF6CDIN2134088', '2', '0', '粤B9Y28试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230301/9740bc9661a94c59980bf92b7d1ca4ff.jpg', null, '39', '2023-03-01 14:10:54', '2023-03-01 14:10:54', '127');
INSERT INTO `vehicle_info` VALUES ('947', '21', 'LC0CE6CD7P1003505', '1', '0', '粤B37E6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230306/98e7cb926f7441e4901e1b71456d0d27.jpg', null, '39', '2023-03-06 09:22:01', '2023-03-06 09:22:01', '127');
INSERT INTO `vehicle_info` VALUES ('948', '21', 'LC0C76C42N0492490', '2', '0', '粤B84D6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230306/9187b7472b624d92958d9bfe2252d631.jpg', null, '39', '2023-03-06 09:23:17', '2023-03-06 09:23:17', '127');
INSERT INTO `vehicle_info` VALUES ('949', '21', 'LCODF4CD1N0227989', '2', '0', '粤B9Y08试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230306/5e846a82dcb04f5da7836ed2bdef6bb6.jpg', null, '39', '2023-03-06 10:42:41', '2023-03-06 10:42:41', '127');
INSERT INTO `vehicle_info` VALUES ('950', '21', 'LCOCF4CD6N1013610', '2', '0', '粤B7Y39试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230306/5b2bbe0a65ff4b3e8e8d4007d8890715.jpg', null, '39', '2023-03-08 10:08:15', '2023-03-06 14:38:16', '127');
INSERT INTO `vehicle_info` VALUES ('951', '21', 'LGACB7C46N0004199', '2', '0', '陕A9484试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230306/e4af8d9d8deb477190b26a063b52be66.jpg', null, '39', '2023-03-06 14:39:20', '2023-03-06 14:39:20', '127');
INSERT INTO `vehicle_info` VALUES ('952', '21', 'LGXCH6CBON2144880', '1', '0', '粤B6Y23试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230307/8b2d330f8297482886fc7005f65a9ed9.jpg', null, '39', '2023-03-07 15:13:03', '2023-03-07 15:13:03', '127');
INSERT INTO `vehicle_info` VALUES ('953', '21', 'LGXCE4CB4N0587316', '2', '0', '陕A9386试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230307/b07861b8dd4f4f908c154f43a8453260.jpg', null, '39', '2023-03-07 15:13:46', '2023-03-07 15:13:46', '127');
INSERT INTO `vehicle_info` VALUES ('954', '21', 'LC0CF6CD9N1289643', '1', '0', '粤B23E9试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230307/cfe0ad84795c4a07bf585013972b50a7.jpg', null, '39', '2023-03-07 15:46:35', '2023-03-07 15:46:35', '127');
INSERT INTO `vehicle_info` VALUES ('955', '21', 'LC0CE6CD9N1281464', '1', '0', '粤B23E7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230307/08e02cddff0246a69844b0452c20526a.jpg', null, '39', '2023-03-07 15:47:26', '2023-03-07 15:47:26', '127');
INSERT INTO `vehicle_info` VALUES ('956', '21', 'LCOD74C48N0383556', '5', '0', '粤B74D6试', '3', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230308/34cdec2a16f645ae877ed0434111dbbf.jpg', null, '39', '2023-03-08 14:06:26', '2023-03-08 14:06:26', '127');
INSERT INTO `vehicle_info` VALUES ('957', '21', 'LCOCF6CD4N1991126', '2', '0', '粤B17F8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230309/53a3e50ea6744b709f1a3d9046300e2b.jpg', null, '39', '2023-03-09 10:52:58', '2023-03-09 10:52:58', '127');
INSERT INTO `vehicle_info` VALUES ('958', '21', 'LCOCF6CD2N1991125', '2', '0', '粤B17F7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230309/ec5a91b738c14a81bb637b3f44851afe.jpg', null, '39', '2023-03-09 10:53:47', '2023-03-09 10:53:47', '127');
INSERT INTO `vehicle_info` VALUES ('959', '21', 'LS5A3DEE4KA403724', '2', '0', '京N663M1', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230309/5d84a4248b074815bfedbe0bb78f62fe.jpg', null, '39', '2023-03-09 10:54:53', '2023-03-09 10:54:53', '127');
INSERT INTO `vehicle_info` VALUES ('960', '21', 'LGXCE4CB8N2148110', '1', '0', '粤B62D7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230313/35b83615800040e58c45cd34d7314371.jpg', null, '39', '2023-03-13 09:22:40', '2023-03-13 09:22:40', '127');
INSERT INTO `vehicle_info` VALUES ('961', '21', 'LGXEK1C4XN0999077', '2', '0', '粤B17F1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230313/471dfb3cc7ba468eb550efc0f134c8e5.jpg', null, '39', '2023-03-13 09:23:36', '2023-03-13 09:23:36', '127');
INSERT INTO `vehicle_info` VALUES ('962', '21', 'LC0DD4C43N0239714', '5', '0', '粤B89D9试', '3', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230315/553795399e54446db879b6571da23932.jpg', null, '39', '2023-03-15 10:06:07', '2023-03-15 10:06:07', '127');
INSERT INTO `vehicle_info` VALUES ('963', '21', 'LGXCX6CB4N2101711', '1', '0', '粤B9Y291试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230315/28aaff5e42114f4191b8feb184ffe113.jpg', null, '39', '2023-03-15 10:07:04', '2023-03-15 10:07:04', '127');
INSERT INTO `vehicle_info` VALUES ('964', '21', 'LC0CF6CD5N1991121', '1', '0', '粤B38E4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230315/fb7df6009cf941379e85a965b02f402d.jpg', null, '39', '2023-03-15 16:05:42', '2023-03-15 16:05:42', '127');
INSERT INTO `vehicle_info` VALUES ('965', '21', 'LC0CF6CD4N1211531', '1', '0', '粤B81D0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230315/f00dd6bdedb045ca97cfdd9baef97955.jpg', null, '39', '2023-03-15 16:06:22', '2023-03-15 16:06:22', '127');
INSERT INTO `vehicle_info` VALUES ('966', '21', 'LC0CF4CD3N0250413', '1', '0', '粤B95D0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230316/b6a1c66bcb914ba09a64a5bc40cd391c.jpg', null, '39', '2023-03-16 10:16:37', '2023-03-16 10:16:37', '127');
INSERT INTO `vehicle_info` VALUES ('967', '21', 'LC0CE4CD2N0154615', '1', '0', '粤B95D7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230316/dc04cde154994659bf6ed67498333a10.jpg', null, '39', '2023-03-16 11:24:25', '2023-03-16 11:24:25', '127');
INSERT INTO `vehicle_info` VALUES ('968', '21', 'LC0CD4C48N0308974', '1', '0', '粤B96D0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230317/ad0159bdcfcd49bfb844e3d0078b732d.jpg', null, '39', '2023-03-17 11:26:43', '2023-03-17 11:26:43', '127');
INSERT INTO `vehicle_info` VALUES ('969', '21', 'LCOC74C45N0314206', '2', '0', '粤B96D2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230322/50e5b74471dd40bfbc643babb23f9c3e.jpg', null, '39', '2023-03-22 10:28:29', '2023-03-22 10:28:29', '127');
INSERT INTO `vehicle_info` VALUES ('970', '21', 'LMGBB1L88M3007979', '1', '0', '粤ED192N', '7', '25', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230323/6a8ba0d1378b4c6aaf8118e9be63a89f.jpg', null, '39', '2023-03-23 11:13:04', '2023-03-23 11:10:14', '127');
INSERT INTO `vehicle_info` VALUES ('971', '21', 'LS6C3E0X4NA711984', '2', '0', '沪AH07871', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230323/8f49a004f0004906888ccbed6e093994.jpg', null, '39', '2023-03-23 11:13:47', '2023-03-23 11:13:47', '127');
INSERT INTO `vehicle_info` VALUES ('972', '21', 'LC0C76C43N0444495', '1', '0', '粤B24E6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230419/2b118f6996e04fbcb1851885080acc0d.jpg', null, '36', '2023-04-19 15:32:11', '2023-03-24 10:14:29', '127');
INSERT INTO `vehicle_info` VALUES ('973', '15', '2C4RC2J75LR233565', '5', '0', '粤BD33565', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:32:57', '2023-03-24 13:00:55', '134');
INSERT INTO `vehicle_info` VALUES ('974', '15', '2C4RC2J77LR233664', '5', '0', '粤BD33664', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:29:58', '2023-03-24 13:06:28', '134');
INSERT INTO `vehicle_info` VALUES ('975', '15', '2C4RC2J76LR233669', '5', '0', '粤BD33669', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:29:42', '2023-03-24 13:11:02', '134');
INSERT INTO `vehicle_info` VALUES ('976', '15', '2C4RC2J72LR233460', '5', '0', '粤BD33460', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:36:22', '2023-03-24 13:14:54', '134');
INSERT INTO `vehicle_info` VALUES ('977', '15', '2C4RC2J7XLR233481', '5', '0', '粤BD33481', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:35:50', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('978', '15', '2C4RC2J75LR233436', '5', '0', '粤BD33436', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:37:04', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('979', '15', '2C4RC2J71LR233630', '5', '0', '粤BD33630', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:31:27', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('980', '15', '2C4RC2J78LR233477', '5', '0', '粤BD33477', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:36:10', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('981', '15', '2C4RC2J77LR233602', '5', '0', '粤BD33602', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:32:10', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('982', '15', '2C4RC2J78LR233544', '5', '0', '粤BD33544', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:33:51', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('983', '15', '2C4RC2J77LR233633', '5', '0', '粤BD33633', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:31:14', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('984', '15', '2C4RC2J77LR233566', '5', '0', '粤BD33566', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:32:50', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('985', '15', '2C4RC2J70LR233604', '5', '0', '粤BD33604', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:32:01', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('986', '15', '2C4RC2J74LR233525', '5', '0', '粤BD33525', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:34:18', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('987', '15', '2C4RC2J7XLR233657', '5', '0', '粤BD33657', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:30:28', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('988', '15', '2C4RC2J79LR233438', '5', '0', '粤BD33438', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:36:58', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('989', '15', '2C4RC2J77LR233499', '5', '0', '粤BD33499', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:35:27', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('990', '15', '2C4RC2J71LR233479', '5', '0', '粤BD33479', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:35:56', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('991', '15', '2C4RC2J73LR233550', '5', '0', '粤BD33550', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:33:37', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('992', '15', '2C4RC2J74LR233492', '5', '0', '粤BD33492', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:35:35', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('993', '15', '2C4RC2J74LR233489', '5', '0', '粤BD33489', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:35:42', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('994', '15', '2C4RC2J76LR233574', '5', '0', '粤BD33574', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:32:29', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('995', '15', '2C4RC2J72LR119300', '5', '0', '粤BD19300', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 14:52:17', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('996', '15', '2C4RC2J72LR233619', '5', '0', '粤BD33619', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:31:36', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('997', '15', '2C4RC2J79LR233570', '5', '0', '粤BD33570', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:32:36', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('998', '15', '2C4RC2J78LR233558', '5', '0', '粤BD33558', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:33:14', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('999', '15', '2C4RC2J70LR233568', '5', '0', '粤BD33568', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:32:43', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1000', '15', '2C4RC2J71LR233613', '5', '0', '粤BD33613', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:31:44', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1001', '15', '2C4RC2J79LR233536', '5', '0', '粤BD33536', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:34:11', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1002', '15', '2C4RC2J72LR233510', '5', '0', '粤BD33510', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:35:03', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1003', '15', '2C4RC2J78LR233513', '5', '0', '粤BD33513', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:34:55', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1004', '15', '2C4RC2J79LR233519', '5', '0', '粤BD33519', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:34:25', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1005', '15', '2C4RC2J78LR233642', '5', '0', '粤BD33642', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:30:56', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1007', '15', '2C4RC2J72LR233555', '5', '0', '粤BD33555', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:33:30', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1008', '15', '2C4RC2J79LR233634', '5', '0', '粤BD33634', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:31:04', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1009', '15', '2C4RC2J78LR119365', '5', '0', '粤BD19365', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 14:52:03', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1010', '15', '2C4RC2J70LR233473', '5', '0', '粤BD33473', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:36:16', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1011', '15', '2C4RC2J70LR233439', '5', '0', '粤BD33439', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:36:50', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1012', '15', '2C4RC2J71LR119224', '5', '0', '粤BD19224', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 14:52:38', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1013', '15', '2C4RC2J76LR233560', '5', '0', '粤BD33560', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:33:06', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1014', '15', '2C4RC2J73LR233516', '5', '0', '粤BD33516', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:34:33', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1015', '15', '2C4RC2J72LR233457', '5', '0', '粤BD33457', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:36:29', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1016', '15', '2C4RC2J77LR233650', '5', '0', '粤BD33650', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:30:46', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1017', '15', '2C4RC2J74LR233654', '5', '0', '粤BD33654', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:30:37', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1018', '15', '2C4RC2J73LR233449', '5', '0', '粤BD33449', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:36:43', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1019', '15', '2C4RC2J79LR233505', '5', '0', '粤BD33505', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:35:10', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1020', '15', '2C4RC2J77LR233549', '5', '0', '粤BD33549', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:33:44', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1021', '15', '2C4RC2J74LR233590', '5', '0', '粤BD33590', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:32:17', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1022', '15', '2C4RC2J75LR233663', '5', '0', '粤BD33663', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:30:18', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1023', '15', '2C4RC2J77LR119292', '5', '0', '粤BD19292', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 14:52:29', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1024', '15', '2C4RC2J77LR119566', '5', '0', '粤BD19566', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 14:51:14', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1025', '15', '2C4RC2J7XLR233500', '5', '0', '粤BD33500', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:35:18', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1026', '15', '2C4RC2J77LR233454', '5', '0', '粤BD33454', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:36:36', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1027', '15', '2C4RC2J78LR233432', '5', '0', '粤BD33432', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:37:12', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1028', '15', '2C4RC2J70LR233408', '5', '0', '粤BD33408', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:38:02', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1029', '15', '2C4RC2J75LR233355', '5', '0', '粤BD33355', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:39:20', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1030', '15', '2C4RC2J78LR233429', '5', '0', '粤BD33429', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:37:30', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1031', '15', '2C4RC2J72LR233359', '5', '0', '粤BD33359', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:39:12', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1032', '15', '2C4RC2J72LR119538', '5', '0', '粤BD19538', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 14:51:35', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1034', '15', '2C4RC2J76LR233428', '5', '0', '粤BD33428', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:37:43', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1036', '15', '2C4RC2J74LR233377', '5', '0', '粤BD33377', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:38:36', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1037', '15', '2C4RC2J76LR233347', '5', '0', '粤BD33347', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:39:38', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1038', '15', '2C4RC2J78LR233348', '5', '0', '粤BD33348', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:39:29', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1039', '15', '2C4RC2J75LR233372', '5', '0', '粤BD33372', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:39:02', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1040', '15', '2C4RC2J73LR119516', '5', '0', '粤BD19516', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-04-04 13:41:58', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1041', '15', '2C4RC2J77LR233373', '5', '0', '粤BD33373', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:38:43', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1042', '15', '2C4RC2J79LR233388', '5', '0', '粤BD33388', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:38:16', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1043', '15', '2C4RC2J75LR233405', '5', '0', '粤BD33405', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:38:09', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1044', '15', '2C4RC2J72LR233541', '5', '0', '粤BD33541', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:34:04', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1047', '15', '2C4RC2J76LR233543', '5', '0', '粤BD33543', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:33:58', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1048', '15', 'LJD8AB3F0N0015406', '5', '0', '粤BD15406', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:23:44', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1049', '15', 'LJD8AB3F9N0015338', '5', '0', '粤BD15338', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:25:34', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1051', '15', 'LJD8AB3F6M0014243', '5', '0', '粤BD14243', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:28:12', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1052', '15', 'LJD8AB3F0N0014661', '5', '0', '粤BD14661', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:27:29', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1054', '15', 'LJD8AB3F1N0014782', '5', '0', '粤BD14782', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:26:09', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1055', '15', 'LJD8AB3F3N0014735', '5', '0', '粤BD14735', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-04-06 12:33:06', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1056', '15', 'LJD8AB3F8N0015444', '5', '0', '粤BD15444', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:57:17', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1057', '15', 'LJD8AB3F0N0014725', '5', '0', '粤BD14725', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:26:57', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1058', '15', 'LJD8AB3F1N0015382', '5', '0', '粤BD15382', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:24:37', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1060', '15', 'LJD8AB3F5N0014767', '5', '0', '粤BD14767', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:26:21', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1061', '15', 'LJD8AB3F1N0015351', '5', '0', '粤BD15351', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:25:05', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1062', '15', 'LJD8AB3F9N0015405', '5', '0', '粤BD15405', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:23:52', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1063', '15', 'LJD8AB3F2N0015388', '5', '0', '粤BD15388', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:24:18', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1064', '15', 'LJD8AB3F1N0015317', '5', '0', '粤BD15317', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:25:47', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1065', '15', 'LJD8AB3F6N0015359', '5', '0', '粤BD15359', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:24:51', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1066', '15', 'LJD8AB3F7N0015791', '5', '0', '粤BD15791', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:57:01', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1067', '15', 'LJD8AB3F1N0015477', '5', '0', '粤BD15477', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:57:13', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1068', '15', 'LJD8AB3F2N0014788', '5', '0', '粤BD14788', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:25:58', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1069', '15', 'LJD8AB3F3N0015495', '5', '0', '粤BD15495', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:57:09', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1070', '15', 'LJD8AB3F3M0014264', '5', '0', '粤BD14264', '11', '34', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-03-29 15:27:50', '2023-03-24 13:15:52', '134');
INSERT INTO `vehicle_info` VALUES ('1073', '21', 'LGXCH6CD7N2062016', '1', '0', '粤B5Y02试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230329/743b903d61c84e65a04305efba050be3.jpg', null, '39', '2023-03-29 09:28:06', '2023-03-29 09:28:06', '127');
INSERT INTO `vehicle_info` VALUES ('1074', '21', '3LN6L5SU2JR609215', '1', '0', '苏UR091Q', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230329/bdef5f6a63ec419aa2bb144d65ec24e5.jpg', null, '39', '2023-03-29 09:28:59', '2023-03-29 09:28:59', '127');
INSERT INTO `vehicle_info` VALUES ('1075', '21', 'LGXDF4CD7N2999203', '2', '0', '粤B21E2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230329/a4c9e38d2c4d4693b2b1693e43b85ac9.jpg', null, '39', '2023-03-29 13:28:41', '2023-03-29 13:28:41', '127');
INSERT INTO `vehicle_info` VALUES ('1076', '21', 'LC0CF6CD1N1290897', '1', '0', '粤B20E3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230329/b4686578a88c4647b24f3dd0f3fa71f0.jpg', null, '39', '2023-03-29 15:10:54', '2023-03-29 15:10:54', '127');
INSERT INTO `vehicle_info` VALUES ('1079', '21', 'LC0CF6CD2N1991125', '2', '0', '粤B23FI试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230329/59e0fb5ce82e4b70b3d9e36670dff863.jpg', null, '39', '2023-03-29 15:15:29', '2023-03-29 15:15:29', '127');
INSERT INTO `vehicle_info` VALUES ('1080', '21', 'LGXCB4CB2N0375496', '1', '0', '陕A9189试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230329/f7cec379c0b84d1b9699c6320a9ad255.jpg', null, '39', '2023-03-29 15:19:16', '2023-03-29 15:19:16', '127');
INSERT INTO `vehicle_info` VALUES ('1081', '21', 'LGXEK1C48N0999031', '2', '0', '粤B60D7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230331/0447fbe822dc4f3f9112760b997dbd65.jpg', null, '39', '2023-03-31 10:41:31', '2023-03-31 10:41:31', '127');
INSERT INTO `vehicle_info` VALUES ('1082', '21', 'LGK3FCD7N1235127', '1', '0', '粤B81D5试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230331/f4bb8a7103d34571965f36a891c6fdc8.jpg', null, '39', '2023-03-31 10:42:23', '2023-03-31 10:42:23', '127');
INSERT INTO `vehicle_info` VALUES ('1083', '21', 'LGK4FC142N0999012', '2', '0', '陕A9450试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230331/28273153809445688d6e8b394592c780.jpg', null, '39', '2023-03-31 10:44:29', '2023-03-31 10:44:29', '127');
INSERT INTO `vehicle_info` VALUES ('1084', '21', 'LC0CE6CD4N1200631', '1', '0', '粤BDU5081', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230331/e00b62b2803a4d65a7836379be5c3d82.jpg', null, '39', '2023-03-31 14:37:33', '2023-03-31 14:37:33', '127');
INSERT INTO `vehicle_info` VALUES ('1085', '21', 'LGXDF4CD3N29992U3', '1', '0', '粤B13E7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230401/e24e14d79ff14d30b61d7ea7443ffbd5.jpg', null, '39', '2023-04-01 09:12:53', '2023-04-01 09:12:53', '127');
INSERT INTO `vehicle_info` VALUES ('1086', '21', 'LC0C76C41N1990125', '2', '0', '粤B23F0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230401/454ddd77f46e4204ad162623065130fd.jpg', null, '39', '2023-04-01 09:14:11', '2023-04-01 09:14:11', '127');
INSERT INTO `vehicle_info` VALUES ('1087', '21', '陕A9450试', '2', '0', 'LGXCD1C42N0999012', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/120d28316b1e447bab0470813328ad5f.jpg', null, '39', '2023-04-06 09:38:37', '2023-04-06 09:38:37', '127');
INSERT INTO `vehicle_info` VALUES ('1088', '21', 'LNBSC1LK2NZ001207', '1', '0', '粤B612ZY', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/91f3237bcb6c42cfbfc249ffee523959.jpg', null, '39', '2023-04-06 09:39:45', '2023-04-06 09:39:45', '127');
INSERT INTO `vehicle_info` VALUES ('1089', '21', 'LGXCH6CBXN2138553', '1', '0', '粤B43F3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/2cc96e84e21248a69ab69714e9b1c7ed.jpg', null, '39', '2023-05-16 15:37:45', '2023-04-06 09:40:32', '127');
INSERT INTO `vehicle_info` VALUES ('1090', '21', 'LGXEK1C46N0999044', '2', '0', '陕A9330试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/8435fd51c0d94234b1044959b2a83125.jpg', null, '39', '2023-04-06 10:15:54', '2023-04-06 10:15:54', '127');
INSERT INTO `vehicle_info` VALUES ('1091', '21', 'LGXDF4CDIN2999149', '2', '0', '陕A9441试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/bc68899f8fe04cfe835008362a6bdc2f.jpg', null, '39', '2023-04-06 14:15:02', '2023-04-06 14:15:02', '127');
INSERT INTO `vehicle_info` VALUES ('1099', '60', 'LHTAC2A25NY9SA010', '6', '1', '粤BDSA010', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:28', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1100', '60', 'LHTAG2A2XNY9PA003', '6', '1', '粤BDPA003', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:46', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1101', '60', 'LHTAC2A28NYBMA005', '6', '1', '粤BDMA005', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:42', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1102', '60', 'LHTAC2A2XNYBMA006', '6', '1', '粤BDMA006', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:38', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1103', '60', 'LHTAC2A29NY9SA009', '6', '1', '粤BDSA009', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:33', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1104', '60', 'LHTAG2A28NY9PA002', '6', '1', '粤BDPA002', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:58', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1105', '60', 'LHTAG2A29NYAWA006', '6', '1', '粤BDWA006', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:02', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1106', '60', 'LHTAE2A29NY91A171', '6', '1', '粤BD1A171', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:19', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1107', '60', 'LHTAE2A20NY91A172', '6', '1', '粤BD1A172', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:15', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1108', '60', 'LHTAE2A22NY91A173', '6', '1', '粤BD1A173', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:11', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1109', '60', 'LHTAG2A29NYAFA006', '6', '1', '粤BDFA006', '31', '43', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230406/f2444fead910440899c9fa7a221cd1a5.png', '0', '36', '2023-08-08 10:21:07', '2023-04-06 14:33:23', '134');
INSERT INTO `vehicle_info` VALUES ('1111', '21', 'LC0C76C40N0444499', '1', '0', '粤B23E0试', '9', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230407/f5105beb58b04f4c9568f258d69483b7.jpg', null, '39', '2023-04-07 10:24:38', '2023-04-07 10:24:38', '127');
INSERT INTO `vehicle_info` VALUES ('1112', '21', 'LC0C76C44N0497335', '1', '0', '粤B86D6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230407/ba8f526c56944ce098c7c398ca3765e3.jpg', null, '39', '2023-04-07 13:42:43', '2023-04-07 13:42:43', '127');
INSERT INTO `vehicle_info` VALUES ('1113', '21', 'LC0CE4CB8P0087732', '2', '0', '粤B07F8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230410/97e3e16000af4e21915895505ac5345d.jpg', null, '39', '2023-04-10 10:45:41', '2023-04-10 10:45:41', '127');
INSERT INTO `vehicle_info` VALUES ('1114', '61', 'LL3ABCJ22MA010781', '1', '0', '沪CK981V', '33', '45', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230526/404c7bd26e4e403f9dde7875c15ca685.jpg', null, '39', '2023-05-26 10:04:35', '2023-04-10 11:14:39', '125');
INSERT INTO `vehicle_info` VALUES ('1115', '21', 'LC0CE4CB1P0087734', '2', '0', '粤B62E2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230411/2caf30c8402948f4bc6aa474adcc4e00.jpg', null, '39', '2023-04-11 16:14:05', '2023-04-11 16:14:05', '127');
INSERT INTO `vehicle_info` VALUES ('1116', '21', 'LGXC74C42N0042582', '2', '0', '陕A9276试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230411/684ce1c9aa444950962f5da5d19a431e.jpg', null, '39', '2023-04-11 16:14:42', '2023-04-11 16:14:42', '127');
INSERT INTO `vehicle_info` VALUES ('1118', '21', 'LGXCE4CBON0669110', '2', '0', '苏E7738试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230413/1404575b6f274d44a46f7f3af2771e6e.jpg', null, '39', '2023-04-13 14:03:17', '2023-04-13 14:03:17', '127');
INSERT INTO `vehicle_info` VALUES ('1119', '21', 'LC0CF6CD5N1991250', '1', '0', '粤B58E4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230413/8fdda5eb8cdc4d758196b7f40ea1d12d.jpg', null, '39', '2023-04-13 14:04:27', '2023-04-13 14:04:27', '127');
INSERT INTO `vehicle_info` VALUES ('1120', '21', 'LC0CF6CD9N1991249', '2', '0', '粤B59E2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230413/f8bb9321107e420090a4fda922cf9f4c.jpg', null, '39', '2023-04-13 14:05:07', '2023-04-13 14:05:07', '127');
INSERT INTO `vehicle_info` VALUES ('1121', '21', 'LC0CE6CD5N1129651', '1', '0', '粤B17F3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230414/4af2365a9c5f431e90583e0c3f8a066f.jpg', null, '39', '2023-04-14 17:30:18', '2023-04-14 17:30:18', '127');
INSERT INTO `vehicle_info` VALUES ('1123', '21', 'LC0CF6CDON1231016', '1', '0', '粤B71D9试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230417/29d1a19c837d434fa7502f9803ae59f6.jpg', null, '39', '2023-04-17 12:10:49', '2023-04-17 12:10:49', '127');
INSERT INTO `vehicle_info` VALUES ('1125', '21', 'LC0C4D1G497999010', '2', '0', '苏E9908试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230418/f502a6c9ccb94df494bacdaa29964f64.jpg', null, '39', '2023-04-18 15:16:28', '2023-04-18 15:16:28', '127');
INSERT INTO `vehicle_info` VALUES ('1126', '21', 'LGXCD1C40N0999011', '2', '0', '陕A9449试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230418/9b52bd14159d4675a79b5f6bd81fd330.jpg', null, '39', '2023-04-18 15:17:35', '2023-04-18 15:17:35', '127');
INSERT INTO `vehicle_info` VALUES ('1127', '61', 'LL3ABCJ23NA010581', '3', '0', '粤BD10581', '33', '45', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230419/d14b87b86e5c4862888a005a5f3e8c3f.jpg', null, '39', '2023-04-19 10:26:34', '2023-04-19 10:26:34', '61');
INSERT INTO `vehicle_info` VALUES ('1128', '21', 'LGXDF4CD0N2999207', '2', '0', '粤BI1E8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230419/ff15c51d73a04a2790c185e01469fcaa.jpg', null, '39', '2023-04-19 10:50:56', '2023-04-19 10:50:56', '127');
INSERT INTO `vehicle_info` VALUES ('1129', '21', 'LGXBK1C43N0999048', '2', '0', '陕A9327试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230419/cc78107485cf4f109349c0f0b8212584.jpg', null, '39', '2023-04-19 10:55:21', '2023-04-19 10:55:21', '127');
INSERT INTO `vehicle_info` VALUES ('1130', '21', 'LGXDF4CDXN299920', '2', '0', '粤B17F9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230421/4f514a1c94c945129ecffde1e0526a02.jpg', null, '39', '2023-04-21 14:53:41', '2023-04-21 14:53:41', '127');
INSERT INTO `vehicle_info` VALUES ('1131', '21', 'LCOC76C40N1207151', '1', '0', '粤B42F8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230421/ef531236b9c04bfdb5ebbc015477b5b7.jpg', null, '39', '2023-04-21 14:54:38', '2023-04-21 14:54:38', '127');
INSERT INTO `vehicle_info` VALUES ('1132', '21', 'LGXC74C47N0528367', '1', '0', '粤B5Y73试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230423/b9ad7c9d87e840e2be4854b7aa5891a4.jpg', null, '39', '2023-04-23 14:17:15', '2023-04-23 14:17:15', '127');
INSERT INTO `vehicle_info` VALUES ('1134', '21', 'LGXC74C42N0542368', '2', '0', '粤B65D9试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230424/d04febf351054104aa9e7729b19a0a47.jpg', null, '36', '2023-04-25 10:39:00', '2023-04-24 17:19:28', '127');
INSERT INTO `vehicle_info` VALUES ('1135', '21', 'LCOCD4C40P0119285', '1', '0', '粤B43F6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230424/3055c66a23d5427990925e252d0883a4.jpg', null, '39', '2023-04-24 17:20:02', '2023-04-24 17:20:02', '127');
INSERT INTO `vehicle_info` VALUES ('1137', '21', 'LC0DD4C4XP0020963', '2', '0', '陕A9451试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230425/1fdc5fb56a1f4279b94f4fecf8c5b6e2.jpg', null, '39', '2023-04-25 10:40:43', '2023-04-25 10:40:43', '127');
INSERT INTO `vehicle_info` VALUES ('1138', '21', 'LGXCD4C4XP0084560', '2', '0', '粤B16F0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230425/59940e5c323f449bb3583420b06c45b4.jpg', null, '39', '2023-04-25 10:41:32', '2023-04-25 10:41:32', '127');
INSERT INTO `vehicle_info` VALUES ('1139', '21', 'LC0CE6CBOP1002940', '1', '0', '粤B07F4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230426/a39f7877e7f14ba9adc9da2b9a8f4b9a.jpg', null, '39', '2023-04-26 10:29:38', '2023-04-26 10:29:38', '127');
INSERT INTO `vehicle_info` VALUES ('1140', '21', 'LGXDF4CDXN2999201', '2', '0', '粤B21E3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230426/aba58466d15e482dbfda8fc702ac874a.jpg', null, '39', '2023-04-26 10:30:45', '2023-04-26 10:30:45', '127');
INSERT INTO `vehicle_info` VALUES ('1142', '21', 'LGXC74C40P0107786', '1', '0', '粤B09F8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230427/8c9454a31e714a998c98858ddf114574.jpg', null, '39', '2023-04-27 14:36:17', '2023-04-27 14:36:17', '127');
INSERT INTO `vehicle_info` VALUES ('1143', '21', 'LC0CF6CD6N1022332', '1', '0', '粤B39F5试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230427/1a36cc5cf54f409f92ccddd44457a414.jpg', null, '39', '2023-04-27 14:37:32', '2023-04-27 14:37:32', '127');
INSERT INTO `vehicle_info` VALUES ('1144', '21', 'LC0C74C47N0528367', '2', '0', '粤B35F4试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230427/62d1b0f792af4166b5bc412da41e7e00.jpg', null, '39', '2023-04-27 14:38:44', '2023-04-27 14:38:44', '127');
INSERT INTO `vehicle_info` VALUES ('1146', '21', 'LC0DM4CD2P1014787', '1', '0', '粤B37F2试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230505/2111e2e992df4917a409d22fc62c63b9.jpg', null, '39', '2023-05-05 10:11:41', '2023-05-05 10:11:41', '127');
INSERT INTO `vehicle_info` VALUES ('1148', '21', 'LGXEK1C49N0999006', '2', '0', '陕A9248试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230505/5cfbed27d6d441408aaeeba74b06e83a.jpg', null, '39', '2023-05-05 12:02:52', '2023-05-05 12:02:52', '127');
INSERT INTO `vehicle_info` VALUES ('1151', '21', 'LGXCH6C34N2006579', '1', '0', '粤B97D0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230508/ab8429971cec43dcb13059f3890d5684.jpg', null, '39', '2023-05-08 10:29:25', '2023-05-08 10:29:25', '127');
INSERT INTO `vehicle_info` VALUES ('1152', '21', 'LC0DF4CD9P1073360', '1', '0', '粤B62E4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230508/48e4fb619e504f79ad37144fa71040a1.jpg', null, '39', '2023-05-08 10:30:03', '2023-05-08 10:30:03', '127');
INSERT INTO `vehicle_info` VALUES ('1153', '21', 'LC0CE6CD1N1131879', '1', '0', '粤BDC1804', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230508/5fc0071dc05e473880d35570d66f376c.jpg', null, '39', '2023-05-08 14:38:38', '2023-05-08 14:38:38', '127');
INSERT INTO `vehicle_info` VALUES ('1154', '21', 'LGXCH6CD1N2040576', '1', '0', '粤B55F8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230508/b0834a5a0e054a2297baef268da57012.jpg', null, '39', '2023-05-08 14:52:49', '2023-05-08 14:52:49', '127');
INSERT INTO `vehicle_info` VALUES ('1155', '21', 'LC0CF6CD6N1030334', '1', '0', '粤BDT0651', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230508/4369812fabef46818b0f596ee6eb5b23.jpg', null, '39', '2023-05-08 16:52:55', '2023-05-08 16:52:55', '127');
INSERT INTO `vehicle_info` VALUES ('1156', '21', 'LC0CE6CDXN1070371', '1', '0', '粤B60D0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230508/7ce453da0a1048839f998ed37129980b.jpg', null, '39', '2023-05-08 16:53:28', '2023-05-08 16:53:28', '127');
INSERT INTO `vehicle_info` VALUES ('1157', '21', 'LGXC74C40P0105763', '2', '0', '粤B09F7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230509/fc741ad5a4d6406391d8279fc3ac52c7.jpg', null, '39', '2023-05-09 10:40:43', '2023-05-09 10:40:43', '127');
INSERT INTO `vehicle_info` VALUES ('1159', '21', 'LGXC74C46N0106333', '2', '0', '粤BG72590', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230510/13d969af5bb64b2285a239de0bb65219.jpg', null, '39', '2023-05-10 10:15:47', '2023-05-10 10:15:47', '127');
INSERT INTO `vehicle_info` VALUES ('1161', '21', 'LGXCD4C45P0084546', '2', '0', '粤B30F6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230510/b669daf575b1452f81e9bf253e8c4a5f.jpg', null, '39', '2023-05-10 14:56:41', '2023-05-10 14:56:41', '127');
INSERT INTO `vehicle_info` VALUES ('1163', '21', 'LS4ASE2EXNB353105', '2', '0', '粤B87B2M', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230511/fc7d1c07d1ba4680a7164ff937862113.jpg', null, '39', '2023-05-11 13:45:50', '2023-05-11 13:45:50', '127');
INSERT INTO `vehicle_info` VALUES ('1164', '21', 'L6T7622Z3NF063846', '2', '0', '粤BZ6007', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230512/eb62d01611d743d699dff434add57038.jpg', null, '39', '2023-05-12 10:01:47', '2023-05-12 10:01:47', '127');
INSERT INTO `vehicle_info` VALUES ('1165', '21', 'LGXCH6CB4N2171063', '1', '0', '粤B53F3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230516/9f14a8525eaa40ac940cd115d56def0c.jpg', null, '39', '2023-05-16 15:32:35', '2023-05-16 15:32:35', '127');
INSERT INTO `vehicle_info` VALUES ('1166', '21', 'LGXCE4CB1N0669133', '2', '0', '陕A9494试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230516/c9d312e0c6b84c9093da8711ccc650da.jpg', null, '39', '2023-05-16 16:42:39', '2023-05-16 16:42:39', '127');
INSERT INTO `vehicle_info` VALUES ('1168', '21', 'LC0CF6CD1N199T245', '2', '0', '粤B44F3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230516/925b50d83a4b447bb65e7bc367e16d7b.jpg', null, '39', '2023-05-16 16:46:01', '2023-05-16 16:46:01', '127');
INSERT INTO `vehicle_info` VALUES ('1169', '21', 'LC0C76044N0492524', '1', '0', '粤B86D9试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230517/34f82ae3b8cb41d3b4a28b38fb1e1956.jpg', null, '39', '2023-05-17 11:37:59', '2023-05-17 11:37:59', '127');
INSERT INTO `vehicle_info` VALUES ('1170', '21', 'LC0C74C4XM0005474', '2', '0', '粤B20F0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230517/e7256efc736d4b16af86c5df7ab6b6a4.jpg', null, '39', '2023-05-17 11:38:38', '2023-05-17 11:38:38', '127');
INSERT INTO `vehicle_info` VALUES ('1171', '21', 'LC0C74C41N1078440', '2', '0', '粤BF23257', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230517/a9f38cebc2d14ef18129f32d706793b4.jpg', null, '39', '2023-05-17 11:39:45', '2023-05-17 11:39:45', '127');
INSERT INTO `vehicle_info` VALUES ('1172', '21', 'LGXCH6CB4N2101711', '1', '0', '粤B43F2试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230517/502c8df60a7f4ff390c49609b9a4b842.jpg', null, '39', '2023-05-17 12:00:39', '2023-05-17 12:00:39', '127');
INSERT INTO `vehicle_info` VALUES ('1173', '21', 'LGADF4CD6N2999101', '2', '0', '粤B70E6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230523/7d40130e400c42d98ac4b10d27085373.jpg', null, '39', '2023-05-23 16:42:38', '2023-05-23 16:42:38', '127');
INSERT INTO `vehicle_info` VALUES ('1174', '21', 'LGXEK1C48P0165999', '2', '0', '陕A9825试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230523/49e9e97c5bba4f93b8bffacad6cc1cdd.jpg', null, '39', '2023-05-23 16:43:43', '2023-05-23 16:43:43', '127');
INSERT INTO `vehicle_info` VALUES ('1177', '21', 'LC0CH4CD1P6999009', '2', '0', '粤B04F9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230524/ebbb1b29116f453c98d971917150fd8c.jpg', null, '39', '2023-05-24 17:17:24', '2023-05-24 17:17:24', '127');
INSERT INTO `vehicle_info` VALUES ('1178', '21', 'LC0CD6C40N1990075', '2', '0', '粤B90E1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230524/c1e2db785e964e0f8fecc83f88c475ec.jpg', null, '39', '2023-05-24 17:18:41', '2023-05-24 17:18:41', '127');
INSERT INTO `vehicle_info` VALUES ('1179', '21', 'LGXDF4CD6N2999101', '2', '0', '粤B70E6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230524/eb47a1a7dd4d453593df7ac72a1fda31.jpg', null, '39', '2023-05-24 17:19:41', '2023-05-24 17:19:41', '127');
INSERT INTO `vehicle_info` VALUES ('1180', '21', 'LC0C76C47N0497331', '1', '0', '粤B86D5试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230524/d6c47f678f2a4cddaac001ccc923b3bf.jpg', null, '39', '2023-05-24 17:21:08', '2023-05-24 17:21:08', '127');
INSERT INTO `vehicle_info` VALUES ('1181', '21', 'LGXD4CD9N2999206', '1', '0', '粤B98D7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230525/99751953cb2048daa85dc953ca2e5bfd.jpg', null, '39', '2023-05-25 13:58:41', '2023-05-25 13:58:41', '127');
INSERT INTO `vehicle_info` VALUES ('1182', '21', 'LC0C76C49N1108540', '1', '0', '粤B68E9试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230525/8e76eb5349674b96b347c6c340250f8c.jpg', null, '39', '2023-05-25 14:00:10', '2023-05-25 14:00:10', '127');
INSERT INTO `vehicle_info` VALUES ('1183', '21', 'LGXC74C4XN0545325', '2', '0', '粤B00G8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230525/1c687ae5029947e3a61979e2705b1ff0.jpg', null, '39', '2023-05-25 14:01:44', '2023-05-25 14:01:44', '127');
INSERT INTO `vehicle_info` VALUES ('1185', '21', 'LCOC76C42N0492490', '1', '0', '粤B84D6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230525/b9e5e97a061d4e6481d4d543c341b1b9.jpg', null, '39', '2023-05-25 14:15:37', '2023-05-25 14:15:37', '127');
INSERT INTO `vehicle_info` VALUES ('1186', '21', 'LGXCBCB4N0587316', '2', '0', '陕A9386试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230525/8147c3e4afb44410a9a446693e6130ca.jpg', null, '39', '2023-05-25 14:16:54', '2023-05-25 14:16:54', '127');
INSERT INTO `vehicle_info` VALUES ('1187', '21', 'LGXEK1C45N0999018', '2', '0', '粤B44F2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230526/8bfb9781d8f548b49e671eac72bbcd5c.jpg', null, '39', '2023-05-26 13:55:52', '2023-05-26 13:55:52', '127');
INSERT INTO `vehicle_info` VALUES ('1188', '21', 'LC0CF6CD8N1232902', '1', '0', '粤B05F4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230526/12858d19332743da8fc2a12a2bd864e9.jpg', null, '39', '2023-05-26 13:57:25', '2023-05-26 13:57:25', '127');
INSERT INTO `vehicle_info` VALUES ('1189', '21', 'LGXDF4CD1N2999149', '2', '0', '粤B93E7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230527/e5301ef5469b49d88790dcd6804fb73c.jpg', null, '39', '2023-05-27 22:21:27', '2023-05-27 22:21:27', '127');
INSERT INTO `vehicle_info` VALUES ('1190', '21', 'LGXCD4C4XN0042578', '2', '0', '陕A9828试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230528/5c12869e8f5548e782922a07fe960cad.jpg', null, '39', '2023-05-28 10:20:48', '2023-05-28 10:20:48', '127');
INSERT INTO `vehicle_info` VALUES ('1191', '21', 'LC0CD6C47N1990025', '1', '0', '粤B68E7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230530/c7ad048a14f14581bb3e8faac6688291.jpg', null, '39', '2023-05-30 09:51:22', '2023-05-30 09:51:22', '127');
INSERT INTO `vehicle_info` VALUES ('1193', '21', 'LC0CF6CDON1292009', '1', '0', '粤B50F7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230531/e3ad5e48fb34491980a23b8731d7924c.jpg', null, '39', '2023-05-31 17:06:34', '2023-05-31 17:06:34', '127');
INSERT INTO `vehicle_info` VALUES ('1194', '21', 'LGXC74C40N0545323', '2', '0', '粤B01G3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230605/be78d828902d458dba6cde221e5f4ef8.jpg', null, '39', '2023-06-05 09:27:43', '2023-06-05 09:27:43', '127');
INSERT INTO `vehicle_info` VALUES ('1195', '21', 'LC0C76C47N1990128', '2', '0', '粤B22F9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230605/c12d4bedaef6496ca5f4ffd7c54cfd26.jpg', null, '39', '2023-06-05 09:29:12', '2023-06-05 09:29:12', '127');
INSERT INTO `vehicle_info` VALUES ('1196', '21', 'LGXC74C46N0545323', '2', '0', '粤B01G3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230605/200b17a4b3e04e7989d1de9474450ab4.jpg', null, '39', '2023-06-05 09:31:28', '2023-06-05 09:31:28', '127');
INSERT INTO `vehicle_info` VALUES ('1197', '21', 'LGXCE4CB8N2172701', '1', '0', '粤B03G5试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230605/8c5fcf37d865468590baa0b0a081711c.jpg', null, '39', '2023-06-05 09:32:10', '2023-06-05 09:32:10', '127');
INSERT INTO `vehicle_info` VALUES ('1198', '21', 'LGXCE4CB6N2140765', '1', '0', '粤B00G3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230605/ebdf08e290364b81a19b1cf84542434b.jpg', null, '39', '2023-06-05 09:33:29', '2023-06-05 09:33:29', '127');
INSERT INTO `vehicle_info` VALUES ('1199', '21', 'LC0CF6CD3N9099111', '1', '0', '粤B52F2试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230605/2ced87bf84a544a9b6b31ebe5a1660ac.jpg', null, '39', '2023-06-05 11:53:09', '2023-06-05 11:53:09', '127');
INSERT INTO `vehicle_info` VALUES ('1202', '15', '2C4RC2J77LR233504', '5', '0', '粤BD33504', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230606/a3a673be5c644c11bfae1f2ec3bba93f.jpg', null, '39', '2023-06-06 11:28:59', '2023-06-06 11:28:59', '134');
INSERT INTO `vehicle_info` VALUES ('1203', '15', '2C4RC2J76LR233526', '5', '0', '粤BD33526', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230606/a49678441c96410abe98816cd1744aa5.jpg', null, '39', '2023-06-06 12:17:57', '2023-06-06 12:17:57', '134');
INSERT INTO `vehicle_info` VALUES ('1204', '15', '2C4RC2J71LR233482', '5', '0', '粤BD33482', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230606/7b7102ca79194be4a6c344c8b09d8369.jpg', null, '39', '2023-06-06 12:18:33', '2023-06-06 12:18:33', '134');
INSERT INTO `vehicle_info` VALUES ('1205', '15', '2C4RC2J77LR233406', '5', '0', '粤BD33406', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230606/6b2f6324157940e98e8c037c36b2d03f.jpg', null, '39', '2023-06-06 12:19:02', '2023-06-06 12:19:02', '134');
INSERT INTO `vehicle_info` VALUES ('1206', '15', '2C4RC2J70LR233389', '5', '0', '粤BD33389', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230606/5d0ebe507f61482695c6d29a470a64f5.jpg', null, '39', '2023-06-06 12:19:31', '2023-06-06 12:19:31', '134');
INSERT INTO `vehicle_info` VALUES ('1207', '15', '2C4RC2J78LR233589', '5', '0', '粤BD33589', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230606/4018cf9fb78949d8900050ba3450a9e7.jpg', null, '39', '2023-06-06 12:20:01', '2023-06-06 12:20:01', '134');
INSERT INTO `vehicle_info` VALUES ('1208', '15', '2C4RC2J76LR233400', '5', '0', '粤BD33400', '10', '8', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230606/05b58d8b902d4808a15cadb498a0425b.jpg', null, '39', '2023-06-06 12:20:32', '2023-06-06 12:20:32', '134');
INSERT INTO `vehicle_info` VALUES ('1210', '21', 'LGXCB48B1N0669133', '2', '0', '陕A9790试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230607/34688a27e3894c60af91c574dd0fa764.jpg', null, '39', '2023-06-07 14:43:26', '2023-06-07 14:43:26', '127');
INSERT INTO `vehicle_info` VALUES ('1211', '21', 'LGXCD4C45N0604189', '2', '0', '陕A9384试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230607/4132191496924fa6aba397294bf6a435.jpg', null, '39', '2023-06-07 14:44:03', '2023-06-07 14:44:03', '127');
INSERT INTO `vehicle_info` VALUES ('1212', '21', 'LSJW54768JG266175', '1', '0', '粤BFA6187', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230607/620e8891b0c7471e953ebae01c2aa492.jpg', null, '39', '2023-06-07 14:44:36', '2023-06-07 14:44:36', '127');
INSERT INTO `vehicle_info` VALUES ('1213', '21', 'LC0DH4CD8P0041928', '2', '0', '粤B39F9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230608/0e19fbd7be324328a8392f3a75e69456.jpg', null, '39', '2023-06-08 13:33:04', '2023-06-08 13:33:04', '127');
INSERT INTO `vehicle_info` VALUES ('1216', '21', 'LC0CF6CD1N1030323', '2', '0', '粤B99D8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230609/0a59ddc013c442329f4b2f495289426e.jpg', null, '39', '2023-06-09 12:22:49', '2023-06-09 12:22:49', '127');
INSERT INTO `vehicle_info` VALUES ('1217', '21', 'LC0CE6CD3M1060005', '1', '0', '粤BAL6886', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230612/8d3122e54d4047cbb292b1f9b6d8ffc2.jpg', null, '39', '2023-06-12 10:29:17', '2023-06-12 10:29:17', '127');
INSERT INTO `vehicle_info` VALUES ('1219', '21', 'LGXDF4CD3N2999203', '2', '0', '粤B13E7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230613/2a77c1aafbaa4e6a95a7fb191e7f0772.jpg', null, '39', '2023-06-13 14:45:25', '2023-06-13 14:45:25', '127');
INSERT INTO `vehicle_info` VALUES ('1220', '21', 'LC0CD6C49N1990026', '2', '0', '粤B69E2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230613/b417bfd697634464b5fce0d4146d8622.jpg', null, '39', '2023-06-13 14:46:08', '2023-06-13 14:46:08', '127');
INSERT INTO `vehicle_info` VALUES ('1221', '21', 'LGXC74C44N0528407', '2', '0', '粤B41F8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230613/4ee754c0d26d4db1be2ee7c6f929f635.jpg', null, '39', '2023-06-13 14:47:42', '2023-06-13 14:47:42', '127');
INSERT INTO `vehicle_info` VALUES ('1222', '21', 'LC0FD1C42P1992025', '2', '0', '粤B02F6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230613/70d4f1e981ea41c3b84d45192fd6ce5d.jpg', null, '39', '2023-06-13 14:48:29', '2023-06-13 14:48:29', '127');
INSERT INTO `vehicle_info` VALUES ('1223', '21', 'LGXCD4C48N0604199', '2', '0', '陕A9791试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230614/e88f140ccdda483c8dd5ee6445211562.jpg', null, '39', '2023-06-14 16:05:30', '2023-06-14 16:05:30', '127');
INSERT INTO `vehicle_info` VALUES ('1224', '21', 'LC0DF4CD6P1205841', '1', '0', '粤B51G6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230615/58dc14282f7346ac915ceb12711950fe.jpg', null, '39', '2023-06-15 13:43:57', '2023-06-15 13:43:46', '127');
INSERT INTO `vehicle_info` VALUES ('1225', '21', 'LC0C76C40N1176550', '1', '0', '粤B49G8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230615/e7703ae75ede403aa085a85aef84557d.jpg', null, '39', '2023-06-15 13:45:38', '2023-06-15 13:45:38', '127');
INSERT INTO `vehicle_info` VALUES ('1226', '21', 'LGXCH6CD5N2040614', '1', '0', '粤B47F4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230615/9973eca62a50487f9ddaa31d62f68483.jpg', null, '39', '2023-06-15 13:46:35', '2023-06-15 13:46:35', '127');
INSERT INTO `vehicle_info` VALUES ('1227', '21', 'LGXCH6CD8N2006599', '1', '0', '粤B53F5试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230617/1960da46fb804c1caa5776f8564c34a5.jpg', null, '39', '2023-06-17 10:58:49', '2023-06-17 10:58:49', '127');
INSERT INTO `vehicle_info` VALUES ('1228', '21', 'LC0CD6C40N1250543', '1', '0', '粤B15E7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230617/47cce56d0dcd4f55a351ba4f8fd16a24.jpg', null, '39', '2023-06-17 11:01:16', '2023-06-17 11:01:16', '127');
INSERT INTO `vehicle_info` VALUES ('1229', '21', 'LC0CF6CD6P1048416', '1', '0', '粤B91E0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230617/fa123defe8754b6aa3034f8d3b933f38.jpg', null, '39', '2023-06-17 11:02:09', '2023-06-17 11:02:09', '127');
INSERT INTO `vehicle_info` VALUES ('1230', '21', 'LC0DH4CD6P1077854', '1', '0', '陕A9753试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230621/e00908d2f76644799b519e6d583b1bae.jpg', null, '39', '2023-06-21 09:42:51', '2023-06-21 09:42:51', '127');
INSERT INTO `vehicle_info` VALUES ('1231', '21', 'LSDA3DEE4KA403724', '2', '0', '京N663M1', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230621/6b478bb4d7f345f6b3ac5e7c17070345.jpg', null, '39', '2023-06-21 09:43:52', '2023-06-21 09:43:52', '127');
INSERT INTO `vehicle_info` VALUES ('1232', '21', 'LC0CE4CB7N0102993', '1', '0', '粤B17F4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230621/533ef0a35f694e579973f5610ccae82b.jpg', null, '39', '2023-06-21 09:47:07', '2023-06-21 09:47:07', '127');
INSERT INTO `vehicle_info` VALUES ('1233', '21', 'LC0DF4CD8P1180392', '1', '0', '粤B51G2试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230621/2b157a6b11e841fda5d90b12e9504fb2.jpg', null, '39', '2023-06-21 09:47:40', '2023-06-21 09:47:40', '127');
INSERT INTO `vehicle_info` VALUES ('1234', '21', 'LC0CF6CD5F1992109', '2', '0', '粤B94E1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230621/14f95244ef6e4bc9bf5cfcd92b24dd2b.jpg', null, '39', '2023-06-21 09:48:25', '2023-06-21 09:48:25', '127');
INSERT INTO `vehicle_info` VALUES ('1238', '21', 'LC0DD4C48P0020962', '2', '0', '粤B73E1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230621/ac0bdc26813547e3a7e123f5bfcf93ee.jpg', null, '39', '2023-06-21 16:28:57', '2023-06-21 16:28:57', '127');
INSERT INTO `vehicle_info` VALUES ('1239', '21', 'LC0DF4CD7P1180402', '2', '0', '粤B51G3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230621/4e05ea9b879b4b43aab0222ac3cf6931.jpg', null, '39', '2023-06-21 16:29:31', '2023-06-21 16:29:31', '127');
INSERT INTO `vehicle_info` VALUES ('1240', '21', 'LC0CF6CD7P1022388', '1', '1', '粤B22388', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230625/3b8960d889c94089992e1b9d897d917c.jpg', null, '39', '2023-06-25 14:22:30', '2023-06-25 14:21:47', '125');
INSERT INTO `vehicle_info` VALUES ('1241', '21', 'LGBH53E06HY002890', '1', '0', '粤B1F60F', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230627/5e3a54e4fe4941b98bcd7110de857d5c.jpg', null, '39', '2023-06-27 14:29:55', '2023-06-27 14:29:55', '127');
INSERT INTO `vehicle_info` VALUES ('1243', '21', 'LGXCE4CB7N2148115', '2', '0', '粤B00G4试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230627/793fd754b04e4854966d9ef252ef98b9.jpg', null, '39', '2023-06-27 14:32:51', '2023-06-27 14:32:51', '127');
INSERT INTO `vehicle_info` VALUES ('1244', '21', 'LGXEK1C49P0196179', '2', '0', '陕A9941试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230627/82864ed72a554281a0ffa9e7e0c4e77d.jpg', null, '39', '2023-06-27 14:33:31', '2023-06-27 14:33:31', '127');
INSERT INTO `vehicle_info` VALUES ('1245', '21', 'LC0C74C40P0105763', '1', '0', '粤B09F7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230628/3b5dcfd94150457882fd6f053e696b74.jpg', null, '39', '2023-06-28 14:48:04', '2023-06-28 14:48:04', '127');
INSERT INTO `vehicle_info` VALUES ('1246', '21', 'LJIEFA001NG101470', '2', '0', '粤BBA1897', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230628/79032b8d45a54bb2850a62526e4717ea.jpg', null, '39', '2023-06-28 14:49:04', '2023-06-28 14:49:04', '127');
INSERT INTO `vehicle_info` VALUES ('1248', '48', 'JTJBGMCAXL2066058', '2', '0', '粤B0H04试', '34', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230629/402d0228cad449d692eb5f4b2b7e2cae.jpg', null, '39', '2023-06-30 09:26:04', '2023-06-29 14:59:24', '134');
INSERT INTO `vehicle_info` VALUES ('1249', '21', 'LC0CE4CD6N0486685', '1', '0', '粤B47G0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230629/1f024c76a5ca4ac5a457439487f6e1f7.jpg', null, '39', '2023-06-29 17:19:42', '2023-06-29 17:19:42', '127');
INSERT INTO `vehicle_info` VALUES ('1250', '21', 'LGXEK1C48N0999059', '2', '0', '陕A9441试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230629/f7e538dada6544ecb7d8ee1fcbfe3526.jpg', null, '39', '2023-06-29 17:20:45', '2023-06-29 17:20:45', '127');
INSERT INTO `vehicle_info` VALUES ('1251', '21', 'LC0CF4CDXN0147733', '1', '0', '粤B43G2试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230629/5f63277652aa40eaaf0b4ac78bfb0d61.jpg', null, '39', '2023-06-29 17:22:07', '2023-06-29 17:22:07', '127');
INSERT INTO `vehicle_info` VALUES ('1252', '21', 'LC0DFACD01873932', '1', '0', '粤B3865试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230629/c595a6a51f76447ebde4d0fcdccafaf6.jpg', null, '39', '2023-06-29 17:22:50', '2023-06-29 17:22:50', '127');
INSERT INTO `vehicle_info` VALUES ('1253', '21', 'LC0CF6CD1P1992110', '2', '0', '粤B94E2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230630/4e10fc3aa14f419081276d15ca0e9b0b.jpg', null, '39', '2023-06-30 11:07:18', '2023-06-30 11:07:18', '127');
INSERT INTO `vehicle_info` VALUES ('1254', '21', 'LC0C76C48N0497368', '1', '0', '粤B54G0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230630/97560bba7cd54589a470e0bda27743b8.jpg', null, '39', '2023-06-30 11:08:23', '2023-06-30 11:08:23', '127');
INSERT INTO `vehicle_info` VALUES ('1256', '49', 'LNBMC52K2PZ001826', '2', '0', '粤BD01826', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230630/25b62caeece74d0bba3ff4e8415dea61.jpg', null, '39', '2023-06-30 14:17:52', '2023-06-30 14:17:52', '134');
INSERT INTO `vehicle_info` VALUES ('1257', '49', 'LNBMC52K8PZ002205', '2', '0', '粤BD02205', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230630/a85ce475217a4f15a06ef39f2528156b.jpg', null, '39', '2023-06-30 15:30:48', '2023-06-30 15:30:48', '134');
INSERT INTO `vehicle_info` VALUES ('1258', '49', 'LNBMC52KXPZ002190', '2', '0', '粤BD02190', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230630/66cc7138fa334f849abb7d5815a79978.jpg', null, '39', '2023-06-30 16:23:07', '2023-06-30 16:23:07', '134');
INSERT INTO `vehicle_info` VALUES ('1259', '21', 'LC0C76C40N0455891', '1', '0', '粤B23G3试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230703/25fa2cba25df41dab07e067be61da238.jpg', null, '39', '2023-07-03 10:21:49', '2023-07-03 10:21:49', '127');
INSERT INTO `vehicle_info` VALUES ('1260', '21', 'LC0CD4C47N0394486', '2', '0', '粤B44G0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230703/dd755dded3ef4907b6a885457ad1e54d.jpg', null, '39', '2023-07-03 10:22:45', '2023-07-03 10:22:45', '127');
INSERT INTO `vehicle_info` VALUES ('1261', '48', 'JTJBGMCA5L2061897', '2', '0', '粤A1U18试', '34', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230704/b3e0d47631664ac9ab97f4e02a4bec9c.jpg', null, '39', '2023-07-04 15:51:32', '2023-07-04 15:51:32', '134');
INSERT INTO `vehicle_info` VALUES ('1262', '21', 'LC0DF4CDXP1281904', '2', '0', '粤B38G5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230705/8272dff1861c48f191f732a0a3112fc5.jpg', null, '39', '2023-07-05 12:32:39', '2023-07-05 12:32:39', '127');
INSERT INTO `vehicle_info` VALUES ('1263', '21', 'LC0CD4C44P0119287', '2', '0', '粤E7658试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230705/eb195a4a61fa4ebd8c1734fb2af91030.jpg', null, '39', '2023-07-05 12:33:57', '2023-07-05 12:33:57', '127');
INSERT INTO `vehicle_info` VALUES ('1264', '21', 'LGXBK1C46N0999044', '2', '0', '陕A9960试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230705/b0a849ed465e4a588e532ff06233315b.jpg', null, '39', '2023-07-05 12:34:35', '2023-07-05 12:34:35', '127');
INSERT INTO `vehicle_info` VALUES ('1265', '21', 'LC0C76C44N1038493', '1', '0', '粤BFW3771', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230705/292721aec0a44a32b19efe07533e6cfb.jpg', null, '39', '2023-07-05 12:36:56', '2023-07-05 12:36:56', '127');
INSERT INTO `vehicle_info` VALUES ('1266', '21', 'LC0CD4C40N0121339', '2', '0', '粤B49F9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230705/573066fda93d45518577afa260c00b1d.jpg', null, '39', '2023-07-05 12:37:47', '2023-07-05 12:37:47', '127');
INSERT INTO `vehicle_info` VALUES ('1267', '21', 'LC0DFACD8P1281903', '2', '0', '粤B3864试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230705/269dfd9099174dbf810791b54a963eaf.jpg', null, '39', '2023-07-05 12:38:56', '2023-07-05 12:38:56', '127');
INSERT INTO `vehicle_info` VALUES ('1269', '21', 'LC0C74C4XN0161774', '2', '0', '粤B87F5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230707/c99e8f5ff81d45db8a0b5c916d1e9fed.jpg', null, '39', '2023-07-07 09:55:39', '2023-07-07 09:55:39', '127');
INSERT INTO `vehicle_info` VALUES ('1270', '21', 'LC0CE6CD9N1022330', '1', '0', '粤B24G7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230708/c1c2b39f34bc410b96494d920c8bf621.jpg', null, '39', '2023-07-08 16:37:55', '2023-07-08 16:37:55', '127');
INSERT INTO `vehicle_info` VALUES ('1271', '21', 'LC0C74C45N0314206', '2', '0', '粤B87F9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230708/e18b4606aa794569ae8df0f2f2c0abef.jpg', null, '39', '2023-07-08 16:38:50', '2023-07-08 16:38:50', '127');
INSERT INTO `vehicle_info` VALUES ('1272', '21', 'LC0DF4CD5P1077852', '2', '0', '粤B95F7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230708/187a44f085244fe6accb7dc0cdb46089.jpg', null, '39', '2023-07-08 16:39:45', '2023-07-08 16:39:45', '127');
INSERT INTO `vehicle_info` VALUES ('1273', '21', 'LC0DD4C40N0503360', '2', '0', '粤B34E8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230711/463b294ac58445bd8b976a1544e7a504.jpg', null, '39', '2023-07-11 17:23:52', '2023-07-11 17:23:52', '127');
INSERT INTO `vehicle_info` VALUES ('1274', '21', 'LGXEK1C44N09999091', '2', '0', '粤B72E4试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230711/6a2fa3ef6b004cc7a1ffab27f37e052b.jpg', null, '39', '2023-07-11 17:25:11', '2023-07-11 17:25:11', '127');
INSERT INTO `vehicle_info` VALUES ('1275', '21', 'LC0DF4CD6P1281902', '2', '0', '粤B38G3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230713/762107bbf3a542bea4dcb78aea611111.jpg', null, '39', '2023-07-13 14:05:57', '2023-07-13 14:05:57', '127');
INSERT INTO `vehicle_info` VALUES ('1276', '21', 'LC0CD6C48N1265081', '2', '0', '粤B73F3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230715/b29a9834d969408aa82dca7201f4ff12.jpg', null, '39', '2023-07-15 17:37:00', '2023-07-15 17:37:00', '127');
INSERT INTO `vehicle_info` VALUES ('1277', '21', 'LC0CF6CD0N1231016', '2', '0', '粤B99F0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230715/d0d34ff75019436ca51687074570c735.jpg', null, '39', '2023-07-15 17:37:48', '2023-07-15 17:37:48', '127');
INSERT INTO `vehicle_info` VALUES ('1278', '21', 'LC0CE4CB1M0056348', '2', '0', '粤B50G0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230715/180a8cb542334f7fb9058477b624d6a5.jpg', null, '39', '2023-07-15 17:39:19', '2023-07-15 17:39:19', '127');
INSERT INTO `vehicle_info` VALUES ('1279', '21', 'LC0DF4CD9P1281909', '2', '0', '粤B36G5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230715/9c381b95cfea49e5aa240447d532b64b.jpg', null, '39', '2023-07-15 17:40:52', '2023-07-15 17:40:52', '127');
INSERT INTO `vehicle_info` VALUES ('1280', '21', 'LC0FD1C43P1992101', '2', '0', '粤B24G6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230715/2563bb0e49c4463386aa8923428a129c.jpg', null, '39', '2023-07-15 17:41:59', '2023-07-15 17:41:59', '127');
INSERT INTO `vehicle_info` VALUES ('1281', '21', 'LGXEK1C42P0254925', '2', '0', '陕A1019试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230717/29825e491d8d497086f2bf21d34bb2c7.jpg', null, '39', '2023-07-17 14:07:05', '2023-07-17 14:07:05', '127');
INSERT INTO `vehicle_info` VALUES ('1282', '21', 'LC0D74C45N0441672', '2', '0', '粤B99F2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230717/47404cda8f7c4740827dac62a01f5578.jpg', null, '39', '2023-07-17 14:09:04', '2023-07-17 14:09:04', '127');
INSERT INTO `vehicle_info` VALUES ('1283', '21', 'LC0DD4C43N0532576', '2', '0', '粤B42F7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230717/58ab83cd2d5a448aa4fe6728451938c7.jpg', null, '39', '2023-07-17 14:10:47', '2023-07-17 14:10:47', '127');
INSERT INTO `vehicle_info` VALUES ('1284', '21', 'LGXC74C43P0204951', '2', '0', '陕A9975试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230717/dccbff0aefa74af3bdfaa569869226bd.jpg', null, '39', '2023-07-17 14:11:16', '2023-07-17 14:11:16', '127');
INSERT INTO `vehicle_info` VALUES ('1285', '21', 'LC0DD4C40N0276574', '5', '0', '粤B48G8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230718/0ee6e4b0c85f4eb4ae3a4df2505c2788.jpg', null, '39', '2023-07-18 09:33:22', '2023-07-18 09:33:22', '127');
INSERT INTO `vehicle_info` VALUES ('1286', '21', 'LGXC74C49N0583273', '2', '0', '粤B96E5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230719/2322a73567ed4f93961d1ea839ca6246.jpg', null, '39', '2023-07-19 11:00:56', '2023-07-19 11:00:56', '127');
INSERT INTO `vehicle_info` VALUES ('1288', '21', 'LC0C76C48N1990073', '2', '0', '粤B05F3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230719/7639d43fdc6a45a886706ad994abcf75.jpg', null, '39', '2023-07-19 11:32:33', '2023-07-19 11:32:33', '127');
INSERT INTO `vehicle_info` VALUES ('1289', '21', 'LGXCD4C46P0084555', '2', '0', '粤B30F7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230719/5db10223f7d24497a8a5c49b94f01b4c.jpg', null, '39', '2023-07-19 11:33:48', '2023-07-19 11:33:48', '127');
INSERT INTO `vehicle_info` VALUES ('1290', '21', 'LC0DF4CD4P1281901', '2', '0', '粤B3802试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230719/bc15911710f94099a0746e07dd2f7474.jpg', null, '39', '2023-07-19 11:34:19', '2023-07-19 11:34:19', '127');
INSERT INTO `vehicle_info` VALUES ('1291', '21', 'LC0C74C47M0038626', '1', '0', '粤B3Y66试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230724/3b7c98d8c28b4adfa885922ea7a3d32d.jpg', null, '39', '2023-07-24 09:49:25', '2023-07-24 09:49:25', '127');
INSERT INTO `vehicle_info` VALUES ('1292', '21', 'LC0C76C42N1265861', '1', '0', '粤BG95767', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230724/c78fa3d71b8a4d2187ad9dfadbf3badd.jpg', null, '39', '2023-07-24 09:50:12', '2023-07-24 09:50:12', '127');
INSERT INTO `vehicle_info` VALUES ('1293', '21', 'LC0CE6CB1P1002915', '2', '0', '粤B07F3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230724/2566ad976000463aacd7bb6c98556f01.jpg', null, '39', '2023-07-24 09:51:46', '2023-07-24 09:51:46', '127');
INSERT INTO `vehicle_info` VALUES ('1294', '21', 'LC0DF4CD9P1180403', '2', '0', '粤B51G5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230724/779b23b6274f48e7a178544fbc7ee3ee.jpg', null, '39', '2023-07-24 09:55:41', '2023-07-24 09:55:41', '127');
INSERT INTO `vehicle_info` VALUES ('1295', '21', 'LC0DD4C46N0281004', '2', '0', '粤B00G7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230725/ad9e566043e14673a0c7e8b8bfc7208b.jpg', null, '39', '2023-07-25 10:44:41', '2023-07-25 10:44:41', '127');
INSERT INTO `vehicle_info` VALUES ('1296', '21', 'LGXCB4CB2N0777292', '2', '0', '陕A9597试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230726/7e922226b8b948ac852a5bcf2df30af1.jpg', null, '39', '2023-07-26 15:35:12', '2023-07-26 15:35:12', '127');
INSERT INTO `vehicle_info` VALUES ('1297', '21', 'LC02EEST200306207', '1', '1', '粤B306207', '16', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230728/af44bfa65c0e4751aff30147e5f13230.jpg', null, '39', '2023-07-28 09:53:30', '2023-07-28 09:52:58', '125');
INSERT INTO `vehicle_info` VALUES ('1298', '21', 'LC0DF4CD5P1180396', '2', '0', '粤B51G0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230729/c1210ceeac214f5caaa345f606a86c4d.jpg', null, '39', '2023-07-29 09:54:10', '2023-07-29 09:54:10', '127');
INSERT INTO `vehicle_info` VALUES ('1299', '21', 'LGXGB4C48N0194245', '2', '0', '粤B29F4试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230731/1301e56d97b44ad78c6f26537adf2f2b.jpg', null, '39', '2023-07-31 14:35:23', '2023-07-31 14:35:23', '127');
INSERT INTO `vehicle_info` VALUES ('1300', '21', 'LGXEK1C48P0165599', '2', '0', '牌A9825试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230731/4bdb4d7216a74076b69ef38ac681fcf3.jpg', null, '39', '2023-07-31 14:35:52', '2023-07-31 14:35:52', '127');
INSERT INTO `vehicle_info` VALUES ('1301', '21', 'LGXCH6CD3N2109221', '2', '0', '粤B97E7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230731/309e22db8f504495a8e75f82a51ccf98.jpg', null, '39', '2023-07-31 14:36:27', '2023-07-31 14:36:27', '127');
INSERT INTO `vehicle_info` VALUES ('1302', '21', 'LC0CF6CD9P1992128', '2', '0', '粤B03G7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230801/16723d45b4374eacbf663ec81936fdc3.jpg', null, '39', '2023-08-01 15:42:06', '2023-08-01 15:42:06', '127');
INSERT INTO `vehicle_info` VALUES ('1303', '21', 'LC0FD1C40P1992105', '2', '0', '粤B45G8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230801/cd686bbcc34248adbf80d267081b7f97.jpg', null, '39', '2023-08-01 15:42:48', '2023-08-01 15:42:48', '127');
INSERT INTO `vehicle_info` VALUES ('1304', '21', 'LC0D74C40441670', '5', '0', '粤B98F9试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230801/6106d60ac2594c34a8dab8b8e6db362a.jpg', null, '39', '2023-08-01 15:43:33', '2023-08-01 15:43:33', '127');
INSERT INTO `vehicle_info` VALUES ('1305', '21', 'LGXCH6CB0N2144880', '1', '0', '粤B43F4试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230801/6a5ba85fee16445bbf632814fb125c13.jpg', null, '39', '2023-08-01 15:44:10', '2023-08-01 15:44:10', '127');
INSERT INTO `vehicle_info` VALUES ('1306', '21', 'LGXCE4CB1N2149468', '1', '0', '粤B81E8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230803/68f2112a483b4a1088ffacc98096acaf.jpg', null, '39', '2023-08-03 14:42:01', '2023-08-03 14:42:01', '127');
INSERT INTO `vehicle_info` VALUES ('1307', '21', 'LGXEK1C46P0254927', '2', '0', '陕A1020试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230803/ae139fa34c8b4944ab88c4128daaba6f.jpg', null, '39', '2023-08-03 14:42:50', '2023-08-03 14:42:50', '127');
INSERT INTO `vehicle_info` VALUES ('1308', '21', 'LC0CF4CD9P6999037', '2', '0', '粤B48G3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230803/b752048148fa4b398dc8ba6c2876d21f.jpg', null, '39', '2023-08-03 16:17:23', '2023-08-03 16:17:23', '127');
INSERT INTO `vehicle_info` VALUES ('1309', '21', 'LGXEK1C48P0165585', '2', '0', '陕A9748试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230804/c755c4ef6bd24e7fba28df3cb67bb450.jpg', null, '39', '2023-08-04 14:58:19', '2023-08-04 14:58:19', '127');
INSERT INTO `vehicle_info` VALUES ('1310', '21', 'LC0CF6CD3P1001375', '1', '0', '粤B28G8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230804/a89d9809182f42169da42a0ef6ffd130.jpg', null, '39', '2023-08-04 14:58:57', '2023-08-04 14:58:57', '127');
INSERT INTO `vehicle_info` VALUES ('1311', '21', 'LC0C74C4XN0388723', '1', '0', '粤B34F8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230804/8bca7e755f964cfabe9077d66512b5d1.jpg', null, '39', '2023-08-04 14:59:41', '2023-08-04 14:59:41', '127');
INSERT INTO `vehicle_info` VALUES ('1312', '21', 'LC0C74C47N0404957', '1', '0', '粤B35F0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230804/0c3e37be471447bd98cab0c8a6082166.jpg', null, '39', '2023-08-04 15:00:51', '2023-08-04 15:00:51', '127');
INSERT INTO `vehicle_info` VALUES ('1313', '21', 'LC0C76C43N1143493', '1', '0', '粤BFK0497', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230804/7db0540b84364bdd94dc66ae8eaf008a.jpg', null, '39', '2023-08-04 15:01:58', '2023-08-04 15:01:58', '127');
INSERT INTO `vehicle_info` VALUES ('1314', '21', 'LC0C76C42P1993005', '2', '0', '粤B95F0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230804/5f7a80b7e49d4ee3a9831281ca3fc1d2.jpg', null, '39', '2023-08-04 16:36:10', '2023-08-04 16:36:10', '127');
INSERT INTO `vehicle_info` VALUES ('1315', '21', 'LC0C76C48P1993011', '2', '0', '粤B38G0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230804/40c435d6d9da450d9772328a109fa9ad.jpg', null, '39', '2023-08-04 16:36:35', '2023-08-04 16:36:35', '127');
INSERT INTO `vehicle_info` VALUES ('1316', '21', 'LGXDF4CD1N2999152', '2', '0', '陕A9795试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230805/b40dd25e93b041719188fdd5485cf53d.jpg', null, '39', '2023-08-05 11:27:10', '2023-08-05 11:27:10', '127');
INSERT INTO `vehicle_info` VALUES ('1317', '21', 'LGXEK1C3KP0165586', '2', '0', '粤B93E7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230807/c52b5c89c60549bfa52ecbce23de600b.jpg', null, '39', '2023-08-07 14:29:17', '2023-08-07 14:29:17', '127');
INSERT INTO `vehicle_info` VALUES ('1318', '21', 'LGXEK1C3KP0165587', '2', '0', '陕A9740试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230807/51b718321fe64af89bf62e68e944446e.jpg', null, '39', '2023-08-07 14:29:56', '2023-08-07 14:29:56', '127');
INSERT INTO `vehicle_info` VALUES ('1319', '21', 'LGYEK1C5P000050', '2', '0', '陕A1106试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230807/a0d4627d02d5474eb23503069029a9dd.jpg', null, '39', '2023-08-07 15:18:48', '2023-08-07 15:18:48', '127');
INSERT INTO `vehicle_info` VALUES ('1320', '21', 'LC0FD1C44P1999302', '2', '0', '粤B12G4试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230807/2acf7b54ed9f472d987bb114b950a019.jpg', null, '39', '2023-08-07 16:33:59', '2023-08-07 16:33:59', '127');
INSERT INTO `vehicle_info` VALUES ('1321', '21', 'LC0CF6CD3N1293249', '2', '0', '粤B78H0试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230807/97c3ff96256d431fa6124a998906e822.jpg', null, '39', '2023-08-07 17:28:57', '2023-08-07 17:28:57', '127');
INSERT INTO `vehicle_info` VALUES ('1322', '21', 'LGXEK1C47P0254922', '2', '0', '陕A1045试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230808/15e5d294703c42019e073d6b7badc88f.jpg', null, '39', '2023-08-08 11:00:07', '2023-08-08 11:00:07', '127');
INSERT INTO `vehicle_info` VALUES ('1323', '21', 'LC0CF4CD6N1013604', '2', '0', '苏E7993试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230808/aabed6bb9afe4db7a0d9527c8b5c1ad7.jpg', null, '39', '2023-08-08 11:06:11', '2023-08-08 11:06:11', '127');
INSERT INTO `vehicle_info` VALUES ('1324', '21', 'LGXCD1C45N0999036', '2', '0', '粤B71E4试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230811/b14156c21201481b872c5311408b2a23.jpg', null, '39', '2023-08-11 12:16:31', '2023-08-11 12:16:31', '127');
INSERT INTO `vehicle_info` VALUES ('1325', '21', 'LS6D3E137PA501236', '2', '0', '粤AB86318', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230814/2b2e1db5be7344318907b6e56a5183b3.jpg', null, '39', '2023-08-14 10:47:49', '2023-08-14 10:47:49', '127');
INSERT INTO `vehicle_info` VALUES ('1326', '21', 'LC0CF6CD5P1013687', '1', '0', '粤B95F8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230814/6f055b68a9fe4800a940d81c38e9ee6d.jpg', null, '39', '2023-08-14 10:48:29', '2023-08-14 10:48:29', '127');
INSERT INTO `vehicle_info` VALUES ('1327', '21', 'LC0CF6CD8P1022349', '1', '0', '粤B57F8试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230815/718d5faeb8284b8f99847d35e7dddefa.jpg', null, '39', '2023-08-15 15:21:02', '2023-08-15 15:21:02', '127');
INSERT INTO `vehicle_info` VALUES ('1328', '21', 'LC0CF6CD4N1991255', '1', '0', '粤B7IE1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230815/c1419240872941efa16a513fdca745f1.jpg', null, '39', '2023-08-15 15:21:55', '2023-08-15 15:21:55', '127');
INSERT INTO `vehicle_info` VALUES ('1329', '21', 'LC0EJ6CDXP1992209', '2', '0', '粤B46G3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230815/be6fc91664e94f97b2265aafea376020.jpg', null, '39', '2023-08-15 15:22:29', '2023-08-15 15:22:29', '127');
INSERT INTO `vehicle_info` VALUES ('1330', '21', '粤B91E5试', '2', '0', 'LGXEK1C47N0999005', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230815/c059816cb29a46b387ead3062145ea09.jpg', null, '39', '2023-08-15 15:23:58', '2023-08-15 15:23:58', '127');
INSERT INTO `vehicle_info` VALUES ('1346', '49', 'LNBMC52K5PZ001853', '1', '0', '粤B911853', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1347', '49', 'LNBMC52K6PZ001876', '1', '0', '粤B581876', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1348', '49', 'LNBMC52K9PZ001886', '1', '0', '粤B391886', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1349', '49', 'LNBMC52K7PZ001899', '1', '0', '粤B121899', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1350', '49', 'LNBMC52K6PZ001912', '1', '0', '粤B671912', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1351', '49', 'LNBMC52K4PZ002041', '1', '0', '粤B352041', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1352', '49', 'LNBMC52K7PZ002051', '1', '0', '粤B612051', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1353', '49', 'LNBMC52KXPZ002058', '1', '0', '粤B812058', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1354', '49', 'LNBMC52K4PZ002072', '1', '0', '粤B842072', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1355', '49', 'LNBMC52K6PZ002090', '1', '0', '粤B752090', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1356', '49', 'LNBMC52K1PZ002093', '1', '0', '粤B822093', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1357', '49', 'LNBMC52K0PZ002103', '1', '0', '粤B212103', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1358', '49', 'LNBMC52K8PZ002107', '1', '0', '粤B792107', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1359', '49', 'LNBMC52K1PZ002109', '1', '0', '粤B272109', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1360', '49', 'LNBMC52K2PZ002121', '1', '0', '粤B102121', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1361', '49', 'LNBMC52K4PZ002122', '1', '0', '粤B932122', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1362', '49', 'LNBMC52K1PZ002126', '1', '0', '粤B382126', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1363', '49', 'LNBMC52K3PZ002158', '1', '0', '粤B372158', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1364', '49', 'LNBMC52K9PZ002164', '1', '0', '粤B302164', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1365', '49', 'LNBMC52K0PZ002165', '1', '0', '粤B112165', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1366', '49', 'LNBMC52K1PZ002174', '1', '0', '粤B622174', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1367', '49', 'LNBMC52K0PZ002182', '1', '0', '粤B842182', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1368', '49', 'LNBMC52K8PZ002186', '1', '0', '粤B772186', '30', '41', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20220712/1d2e22bcdf9f4b8bb947adf820c1bfd7.jpg', '0', '36', '2023-08-15 16:03:52', '2023-08-15 16:03:52', '125');
INSERT INTO `vehicle_info` VALUES ('1369', '21', 'LB37622ZXKX649325', '2', '0', '沪DXE110', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230816/377bf34a97cf4668b4366dc6ce969240.jpg', null, '39', '2023-08-16 13:57:05', '2023-08-16 13:57:05', '127');
INSERT INTO `vehicle_info` VALUES ('1370', '21', 'LGXEK1C47N0999005', '2', '0', '粤B9IE5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230816/50f0cf29c5134778bdcd1e8eafc5ec53.jpg', null, '39', '2023-08-16 16:57:00', '2023-08-16 16:57:00', '127');
INSERT INTO `vehicle_info` VALUES ('1371', '48', 'JTJBGMCA8L2061747', '1', '1', '粤B61747', '16', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230818/f777cd5043f44aed856f945d654072c3.jpg', null, '39', '2023-08-18 11:28:54', '2023-08-18 11:28:54', '125');
INSERT INTO `vehicle_info` VALUES ('1372', '48', 'JTJBGMCA8L2061862', '1', '1', '粤B61862', '16', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230818/c52be619d5dc406baf09933c8e982ac3.jpg', null, '39', '2023-08-18 11:29:35', '2023-08-18 11:29:35', '125');
INSERT INTO `vehicle_info` VALUES ('1373', '48', 'JTJBGMCA9L2062115', '1', '1', '粤B2062', '16', '11', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230818/38875b23775a4864a334e8c3617c9a7d.jpg', null, '39', '2023-08-18 14:04:17', '2023-08-18 14:04:17', '125');
INSERT INTO `vehicle_info` VALUES ('1374', '21', 'LC0C76C49N1990129', '2', '0', '粤B22F8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230821/256527e4d4f148ec81f17608d1df7df4.jpg', null, '39', '2023-08-21 13:33:06', '2023-08-21 13:33:06', '127');
INSERT INTO `vehicle_info` VALUES ('1375', '21', 'LC0C76C49P1992031', '2', '0', '粤B89F6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230821/9fa3c9429dc04f22bf8fb548eb2e292e.jpg', null, '39', '2023-08-21 13:34:29', '2023-08-21 13:34:29', '127');
INSERT INTO `vehicle_info` VALUES ('1376', '21', 'LC0C76C45P1327739', '2', '0', '粤B75H5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230821/91dbd4a71dc74b9484134d8768d92b96.jpg', null, '39', '2023-08-21 13:35:19', '2023-08-21 13:35:19', '127');
INSERT INTO `vehicle_info` VALUES ('1377', '21', 'LC0EJ6CD6P1992210', '2', '0', '粤B25G5试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230824/5b6c9b8c795946b0b53b26131e37d685.jpg', null, '39', '2023-08-24 09:04:02', '2023-08-24 09:04:02', '127');
INSERT INTO `vehicle_info` VALUES ('1378', '21', 'LC0CF0CD9N1991249', '2', '0', '粤B59E2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230824/c3a3c7688b3147a6b37785cca29b16a0.jpg', null, '39', '2023-08-24 09:05:54', '2023-08-24 09:05:54', '127');
INSERT INTO `vehicle_info` VALUES ('1379', '21', 'LGXCF6CD4N2037760', '2', '0', '粤B73F6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230824/1006aba8a079439e884618480d16c06d.jpg', null, '39', '2023-08-24 09:07:24', '2023-08-24 09:07:24', '127');
INSERT INTO `vehicle_info` VALUES ('1380', '21', 'LGXCD4C49P0196959', '2', '0', '陕A9999试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230824/7b74c400dac34cf8a6a607f72bb6cc4a.jpg', null, '39', '2023-08-24 09:07:50', '2023-08-24 09:07:50', '127');
INSERT INTO `vehicle_info` VALUES ('1381', '21', 'LC0C76C49N1143465', '1', '0', '粤BFK4261', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230824/f5f1e870f51c460cb5842b1e42c61a78.jpg', null, '39', '2023-08-24 14:11:58', '2023-08-24 14:11:58', '127');
INSERT INTO `vehicle_info` VALUES ('1382', '21', 'LGXCH6CD5N2006611', '2', '0', '粤B74F1试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230824/14fdb6bd256e49d39b38d9e7e4f29b8e.jpg', null, '39', '2023-08-24 14:12:37', '2023-08-24 14:12:37', '127');
INSERT INTO `vehicle_info` VALUES ('1383', '63', 'LFNA4LDA9NAX12983', '4', '0', '粤B12983', '17', '19', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230824/7a30851e0cb045fd8379dad1b4216031.jpg', null, '39', '2023-08-24 14:19:21', '2023-08-24 14:19:21', '127');
INSERT INTO `vehicle_info` VALUES ('1384', '21', 'LC0EJ4CDXP1991114', '2', '0', '粤B58F8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230826/c73b94106f964a24be82989fc6bc8a53.jpg', null, '39', '2023-08-26 18:25:38', '2023-08-26 18:25:38', '127');
INSERT INTO `vehicle_info` VALUES ('1385', '21', 'LC0EJ4CD5P1991117', '2', '0', '粤B60F2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230826/583c4a511bdf414f8c18a0ce07761607.jpg', null, '39', '2023-08-26 18:26:18', '2023-08-26 18:26:18', '127');
INSERT INTO `vehicle_info` VALUES ('1386', '21', 'LGXCH6CB4N2006579', '1', '0', '粤B53G6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230826/6a25f235aa064f8d935007d51e57a266.jpg', null, '39', '2023-08-26 18:27:02', '2023-08-26 18:27:02', '127');
INSERT INTO `vehicle_info` VALUES ('1387', '21', 'LC0EJ6CD6P1992207', '2', '0', '陕A9950试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230826/75f25332c66f438d93577726ad6aabaf.jpg', null, '39', '2023-08-26 18:27:45', '2023-08-26 18:27:45', '127');
INSERT INTO `vehicle_info` VALUES ('1388', '21', 'LC0CH4CDXP6999042', '2', '0', '粤B05G6试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230826/b3bb002e43ac42818afd2eeb07fc8e0a.jpg', null, '39', '2023-08-26 18:30:07', '2023-08-26 18:30:07', '127');
INSERT INTO `vehicle_info` VALUES ('1389', '21', 'LC0C76C42P1993022', '1', '0', '粤B22G6试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230826/0a2054b63544486a87152419f0fb84e3.jpg', null, '39', '2023-08-26 18:32:08', '2023-08-26 18:32:08', '127');
INSERT INTO `vehicle_info` VALUES ('1390', '54', 'LMTZSV029NC034603', '6', '0', '粤B824603', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1391', '54', 'LMTZSV020NC049846', '6', '0', '粤B519846', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1392', '54', 'LMTZSV029NC065527', '6', '0', '粤B285527', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1393', '54', 'LMTZSV023NC065457', '6', '0', '粤B265457', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1394', '54', 'LMTZSV029MC059399', '6', '0', '粤B029399', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1395', '54', 'LMTZSV027NC058589', '6', '0', '粤B428589', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1396', '54', 'LMTZSV023MC034272', '6', '0', '粤B014272', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1397', '54', 'LMTZSV023MC045062', '6', '0', '粤B975062', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1398', '54', 'LMTZSV025MC033317', '6', '0', '粤B423317', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:26:13', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1399', '54', 'LMTZSV021MC086564', '6', '0', '粤B706564', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1400', '54', 'LMTZSV026MC058873', '6', '0', '粤B518873', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1401', '54', 'LMTZSV024MC008845', '6', '0', '粤B498845', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1402', '54', 'LMTZSV028MC070541', '6', '0', '粤B150541', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1403', '54', 'LMTZSV029MC046443', '6', '0', '粤B076443', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1404', '54', 'LMTZSV024NC040325', '6', '0', '粤B190325', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1405', '54', 'LMTZSV022NC048617', '6', '0', '粤B078617', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1406', '54', 'LMTZSV024NC074300', '6', '0', '粤B514300', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1407', '54', 'LMTZSV020NC067473', '6', '0', '粤B907473', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1408', '54', 'LMTZSV021NC072181', '6', '0', '粤B512181', '32', '44', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230829/d2ff0082d43f4348b631c3aa28500267.png', '0', '36', '2023-08-29 14:13:22', '2023-08-29 14:13:22', '125');
INSERT INTO `vehicle_info` VALUES ('1409', '21', 'LC0CF6CDXP1240437', '2', '0', '粤B80F3试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230830/69b5b6a0fb5f463693a657d8b1544eae.jpg', null, '39', '2023-08-30 16:05:02', '2023-08-30 16:05:02', '127');
INSERT INTO `vehicle_info` VALUES ('1410', '21', 'LC0CF6CD0P1037721', '2', '0', '粤B96FI试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230830/9459f6e46e8c4f51abd8d2e159513859.jpg', null, '39', '2023-08-30 16:05:49', '2023-08-30 16:05:49', '127');
INSERT INTO `vehicle_info` VALUES ('1411', '21', 'LC0FD1C47P1992098', '2', '0', '粤B53G2试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230901/9088193e10904f279d79f2dd8d65737c.jpg', null, '39', '2023-09-01 09:49:23', '2023-09-01 09:49:23', '127');
INSERT INTO `vehicle_info` VALUES ('1412', '21', 'LC0DF4CD5P1205832', '2', '0', '粤B51G7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230901/d6ae14f068754608aa16e70a3bb67b82.jpg', null, '39', '2023-09-01 09:51:49', '2023-09-01 09:51:49', '127');
INSERT INTO `vehicle_info` VALUES ('1413', '21', 'LC0CE4CB6N0279678', '1', '0', '粤B34F0试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230901/a703c28584c143eea37a9135771e7f84.jpg', null, '39', '2023-09-01 09:53:16', '2023-09-01 09:53:16', '127');
INSERT INTO `vehicle_info` VALUES ('1414', '21', 'LGXEKIC49P0196179', '2', '0', '陕A9941试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230901/03fc3ae46c654a62848672eab49c1501.jpg', null, '39', '2023-09-01 11:38:12', '2023-09-01 11:38:12', '127');
INSERT INTO `vehicle_info` VALUES ('1415', '21', 'LGXCF4C43P0109886', '1', '0', '粤B65H7试', '7', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230901/cee71e1ed0c84db285bc0f7c8a649ff6.jpg', null, '39', '2023-09-01 11:38:47', '2023-09-01 11:38:47', '127');
INSERT INTO `vehicle_info` VALUES ('1416', '21', 'LC0DF4CDXP1205826', '2', '0', '试B51G8试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230904/6166ded664a645ad8e4c3de29d6dbb39.jpg', null, '39', '2023-09-04 10:55:09', '2023-09-04 10:55:09', '127');
INSERT INTO `vehicle_info` VALUES ('1417', '21', 'LC0CH4CB6P1999342', '2', '0', '粤B53D7试', '8', '5', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/vehicle_image/20230904/0820dc70b9d0405c90bbf56ffa7addf8.jpg', null, '39', '2023-09-04 10:55:51', '2023-09-04 10:55:51', '127');

-- ----------------------------
-- Table structure for vehicle_safety_info
-- ----------------------------
DROP TABLE IF EXISTS `vehicle_safety_info`;
CREATE TABLE `vehicle_safety_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '安全员ID',
  `customer_id` int(11) DEFAULT NULL COMMENT '客户id',
  `real_name` varchar(100) DEFAULT NULL COMMENT '真实姓名',
  `head_icon` varchar(255) DEFAULT NULL COMMENT '头像图标',
  `gender` int(1) DEFAULT NULL COMMENT '性别（1：男 2：女 对应数据字典gender）',
  `age` int(11) DEFAULT NULL COMMENT '年龄',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `operator` int(10) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='安全员基础信息';

-- ----------------------------
-- Records of vehicle_safety_info
-- ----------------------------
INSERT INTO `vehicle_safety_info` VALUES ('17', '35', '刘玉梅', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/4565196203968570.png', '2', '25', '18899876572', null, null, null);
INSERT INTO `vehicle_safety_info` VALUES ('36', '35', '梁师傅', 'https://garage-1256697786.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/12709949384473177.png', '1', '40', '18742370204', null, null, null);
INSERT INTO `vehicle_safety_info` VALUES ('39', '35', '钟师傅', 'https://szl-1300429178.cos.ap-guangzhou.myqcloud.com/autopilot-test/history/driver_image/20211223/115f2dafffc64c49ab0ff70099370c28.png', '1', '21', '18312492626', '2021-12-23 10:49:34', '2021-07-12 15:33:46', '123');

-- ----------------------------
-- Table structure for vehicle_test_record
-- ----------------------------
DROP TABLE IF EXISTS `vehicle_test_record`;
CREATE TABLE `vehicle_test_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) DEFAULT NULL COMMENT '客户名称',
  `vin` varchar(255) DEFAULT NULL COMMENT '车辆vin码',
  `time_stamp` bigint(20) DEFAULT NULL,
  `ignition_status` int(11) DEFAULT '0' COMMENT '0：熄火,1：点火',
  `driving_mode` int(11) DEFAULT NULL COMMENT '0：手动,1：自动',
  `total_mileage` decimal(18,2) DEFAULT NULL COMMENT '总里程km',
  `record_range` decimal(18,2) DEFAULT NULL COMMENT '续航里程km',
  `speed` decimal(18,2) DEFAULT NULL COMMENT '车速km/h',
  `steering_wheel_angle` decimal(18,2) DEFAULT NULL COMMENT '方向盘角度',
  `steering_wheel_torque` varchar(255) DEFAULT NULL COMMENT '方向盘扭矩',
  `gear` varchar(255) DEFAULT NULL COMMENT '挡位0：N/P,1：D,2：R',
  `accelerator_pedal_opening` decimal(18,2) DEFAULT NULL COMMENT '油门踏板开度',
  `brake_pedal_opening` decimal(18,2) DEFAULT NULL COMMENT '制动踏板开度',
  `cornering_lamp` decimal(18,2) DEFAULT NULL COMMENT '转向灯,0：无转向灯,1：左转向灯开,2：右转向灯开',
  `acceleration` decimal(18,2) DEFAULT NULL COMMENT '加速度,m/s2',
  `stoplight` varchar(255) DEFAULT NULL COMMENT '刹车灯',
  `gps_validity` int(11) DEFAULT NULL COMMENT 'GPS有效性,0：有效,1：无效',
  `gps_longitude` decimal(18,8) DEFAULT NULL COMMENT 'GPS经度',
  `gps_latitude` decimal(18,8) DEFAULT NULL COMMENT 'GPS纬度',
  `gps_heading_angle` decimal(18,8) DEFAULT NULL,
  `gps_acceleration` decimal(18,8) DEFAULT NULL COMMENT 'GPS加速度',
  `recod_time` datetime DEFAULT NULL COMMENT '时间',
  `break_light` int(11) DEFAULT '0' COMMENT '制动灯',
  `takeover_type` int(11) DEFAULT '0' COMMENT '提示接管类型，0：无提示  1：交通阻塞',
  PRIMARY KEY (`id`),
  KEY `index_vin_recod_time` (`recod_time`,`vin`),
  KEY `index_time_stamp` (`time_stamp`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of vehicle_test_record
-- ----------------------------
