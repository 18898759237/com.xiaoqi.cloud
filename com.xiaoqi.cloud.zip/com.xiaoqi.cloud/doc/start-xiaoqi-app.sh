#!/bin/bash
cd /home/app/xiaoqi-gateway
ps_pid=`ps -ef | grep xiaoqi-gateway | grep -v grep | awk '{print $2}'`
sudo kill -9 ${ps_pid}
sudo nohup /home/tools/jdk/jdk1.8.0_281/bin/java -jar xiaoqi-gateway.jar &
echo "Starting xiaoqi-gateway server success"
sleep 30
cd /home/app/xiaoqi-auth
ps_pid=`ps -ef | grep xiaoqi-auth | grep -v grep | awk '{print $2}'`
sudo kill -9 ${ps_pid}
sudo nohup /home/tools/jdk/jdk1.8.0_281/bin/java -jar xiaoqi-auth.jar &
echo "Starting xiaoqi-auth server success"
cd /home/app/xiaoqi-system
ps_pid=`ps -ef | grep xiaoqi-system | grep -v grep | awk '{print $2}'`
sudo kill -9 ${ps_pid}
sudo nohup /home/tools/jdk/jdk1.8.0_281/bin/java -jar xiaoqi-system.jar &
echo "Starting xiaoqi-system server success"
cd /home/app/xiaoqi-job
ps_pid=`ps -ef | grep xiaoqi-job | grep -v grep | awk '{print $2}'`
sudo kill -9 ${ps_pid}
sudo nohup /home/tools/jdk/jdk1.8.0_281/bin/java -jar xiaoqi-job.jar &
echo "Starting xiaoqi-job server success"
cd /home/app/xiaoqi-gen
ps_pid=`ps -ef | grep xiaoqi-gen | grep -v grep | awk '{print $2}'`
sudo kill -9 ${ps_pid}
sudo nohup /home/tools/jdk/jdk1.8.0_281/bin/java -jar xiaoqi-gen.jar &
echo "Starting xiaoqi-gen server success"
cd /home/app/xiaoqi-file
ps_pid=`ps -ef | grep xiaoqi-file | grep -v grep | awk '{print $2}'`
sudo kill -9 ${ps_pid}
sudo nohup /home/tools/jdk/jdk1.8.0_281/bin/java -jar xiaoqi-file.jar &
echo "Starting xiaoqi-file server success"
cd /home/app/xiaoqi-vehilce
ps_pid=`ps -ef | grep xiaoqi-vehilce | grep -v grep | awk '{print $2}'`
sudo kill -9 ${ps_pid}
sudo nohup /home/tools/jdk/jdk1.8.0_281/bin/java -jar xiaoqi-vehilce.jar &
echo "Starting xiaoqi-vehilce server success"