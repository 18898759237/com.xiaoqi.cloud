package com.xiaoqi.common.mqtt.handler;

import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.core.utils.StringUtils;
import com.xiaoqi.common.mqtt.service.MessageSubService;
import com.xiaoqi.common.mqtt.utils.TopicUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Component;


/**
 * mqtt消费分发中心
 */
@Component("mqttMessageReceiveHandler")
@Slf4j
public class MqttMessageReceiveHandler implements MessageHandler {


    @Override
    public void handleMessage(Message message) throws MessagingException {

        // 消息内容
        byte[] msgPayload = (byte[]) message.getPayload();

        // 消息主题
        String topic = message.getHeaders().get("mqtt_receivedTopic").toString();

        log.info("message分发, 消息topic:{}", topic);

        log.info("message分发, 消息内容:{}", new String(msgPayload));

        String serviceName = TopicUtil.queryServiceNameByTopic(topic);
        if (StringUtils.isEmpty(serviceName)) {
            log.error("无服务订阅, 主题名称:{}", topic);
            return;
        }

        try {
            MessageSubService messageSubService = SpringUtils.getBean(serviceName);
            messageSubService.handleMessage(topic, new String(msgPayload));
        }catch (Exception e){
            log.error("订阅服务处理消息异常:{}", e);
        }
    }

}
