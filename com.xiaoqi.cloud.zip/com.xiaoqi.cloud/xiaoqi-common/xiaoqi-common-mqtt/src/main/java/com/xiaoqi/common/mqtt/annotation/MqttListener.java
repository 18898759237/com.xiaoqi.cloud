package com.xiaoqi.common.mqtt.annotation;

import com.xiaoqi.common.mqtt.enums.QosType;
import org.bouncycastle.jcajce.provider.drbg.DRBG;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * mqtt主题订阅
 *
 * @author xiaoqi
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface MqttListener {

    /**
     * 订阅主题
     */
    String[] topics() default {};

    /**
     * Qos
     */
    QosType Qos()  default QosType.QoS_0;

    /**
     * 订阅主题正则
     */
    String topicPattern() default "";

    /**
     * 服务名称
     */
    String serviceName() default "";

    /**
     * 服务描述
     */
    String des() default "";

}
