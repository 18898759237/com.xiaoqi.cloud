package com.xiaoqi.common.mqtt.service;


/**
 * 消息订阅接口类
 */
public interface MessageSubService {


    /**
     * 处理消息
     *
     * @param topic 主题
     * @param message  内容
     */
    void handleMessage(String topic, String message);

    /**
     * 回复消息
     *
     * @param topic 主题
     * @param data  内容
     */
    void reponseMessage(String topic, String data);

}
