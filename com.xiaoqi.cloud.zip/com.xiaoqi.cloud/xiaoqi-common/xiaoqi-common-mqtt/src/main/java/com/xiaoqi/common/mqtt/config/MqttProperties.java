package com.xiaoqi.common.mqtt.config;


import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Mqtt客户端配置参数
 */

@Component
@Data
public  class MqttProperties {

    @Value("${mqtt.ismaste}")
    private Boolean ismaste;

    @Value("${mqtt.ip}")
    private String ip;

    @Value("${mqtt.port}")
    private Integer port;

    @Value("${mqtt.username}")
    private String username;

    @Value("${mqtt.password}")
    private String password;

    @Value("${mqtt.clientId}")
    private String clientId;

    @Value("${mqtt.cleanSession}")
    private Boolean cleanSession;

    public String toBrokerUrl() {
        return "tcp://" + ip + ":" + port;
    }
}
