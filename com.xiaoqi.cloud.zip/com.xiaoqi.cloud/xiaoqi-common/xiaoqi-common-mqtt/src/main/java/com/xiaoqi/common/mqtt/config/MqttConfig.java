package com.xiaoqi.common.mqtt.config;

import com.xiaoqi.common.mqtt.annotation.MqttListener;
import com.xiaoqi.common.mqtt.handler.MqttMessageReceiveHandler;
import com.xiaoqi.common.mqtt.utils.TopicUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

import java.util.List;

/**
 * MQTT订阅消息配置类
 */
@Configuration
@IntegrationComponentScan(basePackages = {"com.xiaoqi.common.mqtt"})
@EnableIntegration
@Slf4j
public class MqttConfig {

    @Autowired
    private MqttProperties properties;

    /**
     * 消息处理器 消费者
     */
    @Autowired
    private MqttMessageReceiveHandler messageHandler;

    /*------------------------------------------订阅消息配置开始----------------------------------------------------*/

    /**
     * 初始化订阅消息连接工厂
     */
    @Bean(name = "mqttSubFactory")
    public MqttPahoClientFactory initSubClientFactory() {
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();
        options.setPassword(properties.getPassword().toCharArray());
        options.setUserName(properties.getUsername());
        String url = "tcp://" + properties.getIp() + ":" + properties.getPort();
        options.setServerURIs(new String[]{url});
        options.setConnectionTimeout(10);
        options.setKeepAliveInterval(60);
        factory.setConnectionOptions(options);
        return factory;
    }

    /**
     * 消息订阅绑定 消费者
     *
     * @return
     */
    @Bean
    public MessageProducer inbound() {
        if (properties.getIsmaste() == false) {
            return null;
        }
        // 可以同时消费（订阅）多个Topic,MqttPahoMessageDrivenChannelAdapter内部根据参数的不同重载了多个构造方法，因此可以灵活运用，可以订阅多个主题，经过实验往后面加就行了。
        MqttPahoMessageDrivenChannelAdapter adapter = new MqttPahoMessageDrivenChannelAdapter(
                properties.getClientId() + "-consumer", initSubClientFactory());


        adapter.setCompletionTimeout(5000);

        DefaultPahoMessageConverter converter = new DefaultPahoMessageConverter();
        converter.setPayloadAsBytes(true);
        adapter.setConverter(converter);

        // 搜索订阅的主题
        log.info("消息订阅配置开始...");
        List<MqttListener> mqttListenerList = TopicUtil.queryAllTopic();
        mqttListenerList.forEach(vo -> {
            String[] topsics = vo.topics();
            String topicPattern = vo.topicPattern();
            int qos = vo.Qos().getValue();
            // 订阅一类主题
            if (!StringUtils.isEmpty(topicPattern)) {
                adapter.addTopic(topicPattern, qos);
            }
            // 订阅多个主题
            if (null != topsics && topsics.length > 0) {
                for (String topic : topsics)
                    adapter.addTopic(topic, qos);
            }

        });
        // 设置订阅通道
        adapter.setOutputChannel(mqttInboundChannel());
        return adapter;
    }

    /**
     * MQTT信息通道（消费者）
     */

    @Bean(name = "mqttInChannel")
    public MessageChannel mqttInboundChannel() {
        return new DirectChannel();

    }

    @Bean
    //ServiceActivator注解表明当前方法用于处理MQTT消息，inputChannel参数指定了用于接收消息信息的channel。
    @ServiceActivator(inputChannel = "mqttInChannel")
    public MessageHandler handler() {
        return messageHandler;
    }
    /*------------------------------------------订阅消息配置结束----------------------------------------------------*/

    /*------------------------------------------发布消息配置开始----------------------------------------------------*/

    /**
     * 初始化发布消息连接工厂
     */
    @Bean(name = "mqttPubFactory")
    public MqttPahoClientFactory initPubClientFactory() {
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();
        options.setPassword(properties.getPassword().toCharArray());
        options.setUserName(properties.getUsername());
        String url = "tcp://" + properties.getIp() + ":" + properties.getPort();
        options.setServerURIs(new String[]{url});
        options.setConnectionTimeout(10);
        options.setKeepAliveInterval(60);
        // 解决正在进行过多的发布问题
        options.setMaxInflight(1000);
        factory.setConnectionOptions(options);
        return factory;
    }

    /**
     * MQTT信息通道（生产者）
     */

    @Bean(name = "mqttOutChannel")
    public MessageChannel mqttOutboundChannel() {
        return new DirectChannel();
    }

    /**
     * MQTT消息处理器（生产者）
     *
     * @return {@link MessageHandler}
     */
    @Bean
    @ServiceActivator(inputChannel = "mqttOutChannel")
    public MessageHandler mqttOutbound() {
        MqttPahoMessageHandler messageHandler = new MqttPahoMessageHandler(
                properties.getClientId() + "-producer",
                initPubClientFactory());
        messageHandler.setAsync(true);
        messageHandler.setDefaultQos(1);
        return messageHandler;
    }
    /*------------------------------------------发布消息配置结束----------------------------------------------------*/
}
