package com.xiaoqi.common.mqtt.utils;

import cn.hutool.core.util.ReUtil;
import com.google.common.collect.Lists;
import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.core.utils.StringUtils;
import com.xiaoqi.common.mqtt.annotation.MqttListener;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 消息主题订阅工具类
 */
@Slf4j
public class TopicUtil {


    /**
     * topic列表
     */
    private final static List<MqttListener> mqttListenerList = Lists.newArrayList();

    /**
     * 扫描所有添加MqttListener注解类的订阅信息
     *
     * @return
     */
    public static List<MqttListener> queryAllTopic() {

        // 缓存中有消息, 则不扫描主题
        if (mqttListenerList.size() > 0) {
            return mqttListenerList;
        }
        SpringUtils.getBeanNamesForAnnotation(MqttListener.class).stream().forEach(vo -> {

            Class clazz = SpringUtils.getBean(vo).getClass();
            MqttListener annotation = (MqttListener) clazz.getAnnotation(MqttListener.class);
            log.info("mqtt订阅信息, 主题:{}, {}, Qos:{}, 处理消息的实现类名称:{}", annotation.topics(),
                    annotation.topicPattern(), annotation.Qos().getValue(), annotation.serviceName());
            mqttListenerList.add(annotation);
        });
        return mqttListenerList;
    }

    /**
     * 根据主题找服务名称
     *
     * @param topic 消息主题
     * @return
     */
    public static String queryServiceNameByTopic(String topic) {

        // 扫描所有添加MqttListener注解类的订阅信息
        queryAllTopic();

        // 精准匹配topic
        List<MqttListener> topicList = mqttListenerList.stream().filter(vo -> vo.topics() != null && vo.topics().length > 0)
                .collect(Collectors.toList());
        for (MqttListener listener : topicList) {
            String[] topics = listener.topics();
            for (String subTopic : topics) {
                if (subTopic.equals(topic)) {
                    return listener.serviceName();
                }
            }
        }
        // 正则查找topic
        // /vehicle-monitoring/LTIC08871524F1092/login
        List<MqttListener> patternTopicList = mqttListenerList.stream().filter(vo -> StringUtils.isNotEmpty(vo.topicPattern()))
                .collect(Collectors.toList());
        for (MqttListener listener : patternTopicList) {
            if (isMatch(topic, listener.topicPattern())) {
                return listener.serviceName();
            }
        }
        return "";
    }

    /**
     * 判断两个主题是否匹配
     *
     * @param topic        消息的主题
     * @param topicPattern 订阅的主题
     * @return
     */
    private static boolean isMatch(String topic, String topicPattern) {

        String[] topics = topic.split("/");
        String[] topicPatterns = topicPattern.split("/");
        // 长度一致,不匹配
        if (topics.length != topicPatterns.length) {
            return false;
        }
        for (int i = 0; i < topics.length; i++) {
            if (!topics[i].equals(topicPatterns[i]) && !"+".equals(topicPatterns[i])) {
                return false;
            }
        }
        return true;
    }
}
