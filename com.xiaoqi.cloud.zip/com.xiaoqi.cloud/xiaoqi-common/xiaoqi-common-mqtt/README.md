## 安装配置
1.见安装部署文档中mqtt或者emqx部分;

## 配置文件
````
#mqtt配置信息
mqtt:
  # mqtt服务IP
  ip: 192.168.136.130
  # 端口
  port: 1883
  # 用户名
  username: admin
  # 密码(默认密码:public)
  password: public
  # cleanSession为true时，Mqtt服务端在客户端断开连接后，不保留客户端的session，订阅信息会丢失
  cleanSession: true
  #true 开启接收模式   false 只有发送 没有接收
  ismaste: true
  # 多个微服务clientId相同时, 后启动会连接失败
  clientId: mqtt_sys_id_test
  # 连接超时时间
  completionTimeout: 5000
  # 默认topic
  defaultTopic: /xiaoqi/
````
## 订阅(订阅策略, 默认:random随机, 不支持广播)
````
1.ps:所有实现MessageSubService接口, 并添加@MqttListener注解的类, 项目启动的时候自动扫描并订阅
/**
 * 登录订阅
 */

// 匹配订阅, 建议以 /xx/+/xx或者 /xx/xx/+/xx模式匹配
@MqttListener(topicPattern = "/vehicle-monitoring/+/login", Qos = QosType.QoS_2, serviceName = "loginMessageServiceImpl", des = "设备登录订阅")

// 精确订阅模式
@MqttListener(topics = {"/vehicle-monitoring/LTIC08871524F1092/login"}, Qos = QosType.QoS_2, serviceName = "loginMessageServiceImpl", des = "设备登录订阅")
@Service("loginMessageServiceImpl")
@Slf4j
public class LoginMessageServiceImpl implements MessageSubService {

    /**
     * 处理消息
     *
     * @param message
     */
    @Override
    public void handleMessage(String message) {

        log.info("设备登录:{}", message);
    }

    /**
     * 回复消息
     *
     * @param topic 主题
     * @param data  内容
     */
    @Override
    public void reponseMessage(String topic, String data) {

    }
}
````
## 发布
````
1.直接调用MqttPubClient里面的静态方法;
/**
 * 消息发布客户端
 */
public class MqttPubClient {

    /**
     * mqttService由IntegrationComponentScan动态代理生成实现类
     */
    private static MqttService mqttService = SpringUtils.getBean(MqttService.class);

    /**
     * 发送信息到MQTT服务器
     *
     * @param
     */
    public static void sendToMqttObject(@Header(MqttHeaders.TOPIC) String topic, byte[] payload) {
        mqttService.sendToMqttObject(topic, payload);
    }

    /**
     * 发送信息到MQTT服务器
     *
     * @param topic   主题
     * @param payload 消息主体
     */
    public static void sendToMqtt(@Header(MqttHeaders.TOPIC) String topic, String payload) {
        mqttService.sendToMqtt(topic, payload);
    }

    /**
     * 发送信息到MQTT服务器
     *
     * @param topic   主题
     * @param qos     对消息处理的几种机制。
     *                0 表示的是订阅者没收到消息不会再次发送，消息会丢失。
     *                1 表示的是会尝试重试，一直到接收到消息，但这种情况可能导致订阅者收到多次重复消息。
     *                2 多了一次去重的动作，确保订阅者收到的消息有一次。
     * @param payload 消息主体
     */
    public static void sendToMqtt(@Header(MqttHeaders.TOPIC) String topic, @Header(MqttHeaders.QOS) int qos, String payload) {
        mqttService.sendToMqtt(topic, qos, payload);
    }

    /**
     * 发送信息到MQTT服务器
     *
     * @param topic   主题
     * @param payload 消息主体
     */
    public static void sendToMqtt(@Header(MqttHeaders.TOPIC) String topic, Object payload) {
        mqttService.sendToMqtt(topic, payload);
    }

    /**
     * 发送信息到MQTT服务器
     *
     * @param topic   主题
     * @param payload 消息主体
     */
    public static void sendToMqtt(@Header(MqttHeaders.TOPIC) String topic, byte[] payload) {
        mqttService.sendToMqtt(topic, payload);
    }
}
````
