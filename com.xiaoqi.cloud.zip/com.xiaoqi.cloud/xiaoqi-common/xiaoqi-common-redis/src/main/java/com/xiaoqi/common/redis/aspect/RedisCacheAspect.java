package com.xiaoqi.common.redis.aspect;

import com.xiaoqi.common.redis.annotation.RedisCacheEnabled;
import com.xiaoqi.common.redis.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * mq消费失败(可用于保存失败消息)
 *
 * @author xiaoqi
 */
@Slf4j
@Aspect
@Component
public class RedisCacheAspect {

    @Autowired
    private RedisService redisService;

    /**
     * 环绕切入
     *
     * @param joinPoint         切点
     * @param redisCacheEnabled 注解
     * @param <T>
     * @return
     * @throws Exception
     */
    @Around(value = "@annotation(redisCacheEnabled)")
    public <T> T doAround(ProceedingJoinPoint joinPoint, RedisCacheEnabled redisCacheEnabled) throws Throwable {

        // key前缀
        String prefix = redisCacheEnabled.prefix();

        // key
        String key = redisCacheEnabled.key();

        // 超时时间
        long timeout = redisCacheEnabled.timeout();

        // 时间单位
        TimeUnit timeUnit = redisCacheEnabled.timeUnit();

        if(StringUtils.isEmpty(prefix.concat(key))){
            return (T) joinPoint.proceed(joinPoint.getArgs());
        }

        T cache = redisService.getCacheObject(prefix.concat(key));
        if (null != cache) {
            return cache;
        }

        // 调用目标对方方法
        Object resultObject = joinPoint.proceed(joinPoint.getArgs());

        // 返回值为null, redis不缓存
        if (null == resultObject) {
            return null;
        }
        if (timeout > 0) {
            redisService.setCacheObject(prefix.concat(key), resultObject, timeout, timeUnit);
        } else {
            redisService.setCacheObject(prefix.concat(key), resultObject);
        }
        return (T) resultObject;
    }
}
