package com.xiaoqi.common.redis.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.TimeUnit;

/**
 * Redis缓存处理
 * <p>
 * 1.添加此注解会根据prefix + key从redis中查找,存在则直接返回
 * <p>
 * 2.不存在, 则将方法返回值,同步到redis
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface RedisCacheEnabled {

    /**
     * key前缀
     */
    String prefix() default "";

    /**
     * key
     */
    String key() default "";

    /**
     * 超时时间, 默认0, 不超时
     */
    long timeout() default 0L;

    /**
     * 超时单位
     */
    TimeUnit timeUnit() default TimeUnit.MINUTES;
}
