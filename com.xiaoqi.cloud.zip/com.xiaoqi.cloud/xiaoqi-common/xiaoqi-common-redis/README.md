## 安装配置
1.见安装部署文档中redis部分;

## 修改配置文件
````
# spring配置
spring:
  redis:
    host: 192.168.136.128
    port: 6379
    password: 123456
````
## 调用

1.  根据需要引入以下bean
````
#原生RedisTemplate
@Autowired
private RedisTemplate redisTemplate;

#原生RedisTemplate可用于分布式锁
@Autowired
private RedissonClient redissonClient;

#对RedisTemplate封装,简便了很多操作
@Autowired
private RedisService redisService;
````
