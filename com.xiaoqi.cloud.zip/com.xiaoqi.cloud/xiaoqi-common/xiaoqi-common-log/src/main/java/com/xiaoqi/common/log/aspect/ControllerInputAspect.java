package com.xiaoqi.common.log.aspect;

import com.google.gson.Gson;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * 出参，入参日志打印
 */
@Aspect
@Component
public class ControllerInputAspect {
    private static final Logger log = LoggerFactory.getLogger(ControllerInputAspect.class);

    public ControllerInputAspect() {
    }

    @Pointcut("execution(* com.xiaoqi..*.*Controller.*(..))")
    public void point() {
    }

    @Around("point()")
    public Object dealInput(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        if (method.getName().equalsIgnoreCase("initBinder")) {
            return joinPoint.proceed();
        }
        try {
            Class<?>[] parameterTypes = method.getParameterTypes();
            List<String> paramsType = new ArrayList();

            for (int i = 0; i < parameterTypes.length; ++i) {
                Class<?> clazz = parameterTypes[i];
                paramsType.add(clazz.getSimpleName());
            }
            List<Object> paramsValue = new ArrayList();
            Object[] args = joinPoint.getArgs();
            Gson gson = new Gson();
            for (int i = 0; i < args.length; ++i) {
                Object object = args[i];
                if (!(object instanceof HttpServletRequest) && !(object instanceof HttpServletResponse)) {
                    try {
                        paramsValue.add(gson.toJson(object));
                    } catch (Exception e) {
                        paramsValue.add("");
                    }
                }
            }

            String methodName = method.getName();
            String controllerName = joinPoint.getTarget().getClass().getName();
            log.info("方法:{}.{}(), 请求入参:({})", controllerName, methodName, paramsValue);
            Object resultObject = joinPoint.proceed();
            log.info("方法:{}.{}(), 相应出参:({})", controllerName, methodName, paramsValue);
            log.info("方法:{}.{}(), 执行时间 {}ms", controllerName, methodName, System.currentTimeMillis() - start);
            return resultObject;
        } catch (Exception e) {
            log.error("AOP Exception:", e);
            throw e;
        }

    }
}
