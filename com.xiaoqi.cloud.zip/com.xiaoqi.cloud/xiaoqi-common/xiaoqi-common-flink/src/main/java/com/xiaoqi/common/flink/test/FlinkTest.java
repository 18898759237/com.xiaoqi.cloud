package com.xiaoqi.common.flink.test;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.RandomUtil;
import com.alibaba.fastjson2.JSON;
import com.google.common.collect.Lists;
import com.xiaoqi.common.flink.domain.VehicleTestRecord;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.util.Date;
import java.util.List;

public class FlinkTest {
    public static List<String> vinList = Lists.newArrayList(new String[]{"LFPHC7PEXM1B14885", "LFPHC7PE0M1B15110", "LFPHC7PE1M1B14712", "LFPHC7PE2M1B14668"});

    public static void main(String[] args) throws Exception {
        Configuration configuration = new Configuration();

        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment(configuration);

        DataStream<VehicleTestRecord> stream = env.addSource(new SourceFunction<VehicleTestRecord>() {

            @Override
            public void run(SourceContext<VehicleTestRecord> sourceContext) throws Exception {
                while (true) {
                    VehicleTestRecord record = new VehicleTestRecord();

                    record.setVin(vinList.get(RandomUtil.randomInt(0, 4)));
                    record.setDrivingMode(RandomUtil.randomLong(0, 2));
                    record.setSpeed(RandomUtil.randomLong(20, 60));
                    record.setTotalMileage(RandomUtil.randomLong(20, 60));
                    record.setRecodTime(DateUtil.offsetDay(new Date(), RandomUtil.randomInt(0, 4)));
                    sourceContext.collect(record);
                    Thread.sleep(3000);
                }
            }

            @Override
            public void cancel() {
            }
        });

        // 将输入数据 映射转成其他格式数据, 演示映射方法, 此处原样返回
        DataStream<VehicleTestRecord> dataStream1 = stream.map(new MapFunction<VehicleTestRecord, VehicleTestRecord>() {

            @Override
            public VehicleTestRecord map(VehicleTestRecord value) throws Exception {
                return value;
            }
        });
        // 按vin码分组
        KeyedStream<VehicleTestRecord, String> keyedStream1 = dataStream1.keyBy((KeySelector<VehicleTestRecord, String>) value -> value.getVin());

        // 开窗
        WindowedStream<VehicleTestRecord, String, TimeWindow> timeWindowWindowedStream = keyedStream1.window(TumblingProcessingTimeWindows.of(Time.seconds(10)));

        timeWindowWindowedStream.process(new ProcessWindowFunction<VehicleTestRecord, Object, String, TimeWindow>() {

            @Override
            public void process(String s, Context context, Iterable<VehicleTestRecord> elements, Collector<Object> out) throws Exception {

            }
        });
        // 按时间分组
        KeyedStream<VehicleTestRecord, Date> keyedStream2 = keyedStream1.keyBy((KeySelector<VehicleTestRecord, Date>) value -> value.getRecodTime());
        // 聚合函数
        /* keyedStream1.reduce(new ReduceFunction<VehicleTestRecord>() {
         *//**
         *
         * @param value1 之前计算结果
         * @param value2 当前元素
         * @return
         * @throws Exception
         *//*
            @Override
            public VehicleTestRecord reduce(VehicleTestRecord value1, VehicleTestRecord value2) throws Exception {
                // 计算速度最大值
                value1.setSpeed(value1.getSpeed() < value2.getSpeed() ? value2.getSpeed() : value1.getSpeed());
                return value1;
            }

        });*/
        // 每天, 每个vin码的最大速度
        DataStream dataStream2 = keyedStream1.max("speed");


        DataStream dataStream3 = keyedStream2.max("totalMileage");


        dataStream3.print();
        env.execute("spring flink demo");
    }
}
