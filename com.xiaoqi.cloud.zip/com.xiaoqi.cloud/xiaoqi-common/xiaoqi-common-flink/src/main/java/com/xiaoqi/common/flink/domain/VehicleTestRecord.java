package com.xiaoqi.common.flink.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.xiaoqi.common.core.annotation.Excel;
import com.xiaoqi.common.core.web.domain.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 车辆行驶记录对象 vehicle_test_record
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@ApiModel(value = "车辆行驶记录")
@Data
public class VehicleTestRecord extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * $column.columnComment
     */
    @ApiModelProperty(value = "${comment}")
    private Long id;


    /**
     * 车辆vin码
     */
    @Excel(name = "车辆vin码")
    @ApiModelProperty(value = "车辆vin码")
    private String vin;


    /**
     * 0：手动,1：自动
     */
    @Excel(name = "0：手动,1：自动")
    @ApiModelProperty(value = "0：手动,1：自动")
    private Long drivingMode;

    /**
     * 总里程km
     */
    @Excel(name = "总里程km")
    @ApiModelProperty(value = "总里程km")
    private Long totalMileage;


    /**
     * 车速km/h
     */
    @Excel(name = "车速km/h")
    @ApiModelProperty(value = "车速km/h")
    private Long speed;


    /**
     * 时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "时间", width = 30, dateFormat = "yyyy-MM-dd")
    @ApiModelProperty(value = "时间")
    private Date recodTime;


}
