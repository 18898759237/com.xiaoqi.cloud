package com.xiaoqi.common.core.utils;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.xiaoqi.common.core.utils.sql.SqlUtil;
import com.xiaoqi.common.core.web.page.PageDomain;
import com.xiaoqi.common.core.web.page.TableSupport;
import org.springframework.beans.BeanUtils;

/**
 * 分页工具类
 *
 * @author xiaoqi
 */
public class PageUtils extends PageHelper {
    /**
     * 设置请求分页数据
     */
    public static void startPage() {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Integer pageNum = pageDomain.getPageNum();
        Integer pageSize = pageDomain.getPageSize();
        String orderBy = SqlUtil.escapeOrderBySql(pageDomain.getOrderBy());
        Boolean reasonable = pageDomain.getReasonable();
        PageHelper.startPage(pageNum, pageSize, orderBy).setReasonable(reasonable);
    }

    /**
     * 设置请求分页数据
     *
     * @param pageNum  当前记录起始索引
     * @param pageSize 每页显示记录数
     */
    public static void startPage(Integer pageNum, Integer pageSize) {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        String orderBy = SqlUtil.escapeOrderBySql(pageDomain.getOrderBy());
        Boolean reasonable = pageDomain.getReasonable();
        PageHelper.startPage(pageNum, pageSize, orderBy).setReasonable(reasonable);
    }

    /**
     * 获取分页参数page
     * -此方法真实page,只能获取一次,获取后自行存储
     *
     * @return
     */
    public static Page getPage() {

        Page page = PageHelper.getLocalPage();
        if (null != page) {
            clearPage();
            return page;
        }
        return new Page(1, 10);
    }

    /**
     * 清理分页的线程变量
     */
    public static void clearPage() {
        PageHelper.clearPage();
    }
}
