package com.xiaoqi.common.core.aspect;

import com.xiaoqi.common.core.annotation.TimeConsume;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * 统计方法耗时
 *
 * @author xiaoqi
 */
@Aspect
@Component
public class TimeConsumeAspect {

    private static final Logger log = LoggerFactory.getLogger(TimeConsumeAspect.class);

    public TimeConsumeAspect() {
    }

    @Around("@annotation(timeConsume)")
    public Object dealInput(ProceedingJoinPoint joinPoint, TimeConsume timeConsume) throws Throwable {
        long start = System.currentTimeMillis();
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        String methodName = method.getName();
        String className = joinPoint.getTarget().getClass().getName();

        // 放行
        Object resultObject = joinPoint.proceed();

        log.info("方法:{}.{}(), 执行时间: {}ms", className, methodName, System.currentTimeMillis() - start);
        return resultObject;


    }
}
