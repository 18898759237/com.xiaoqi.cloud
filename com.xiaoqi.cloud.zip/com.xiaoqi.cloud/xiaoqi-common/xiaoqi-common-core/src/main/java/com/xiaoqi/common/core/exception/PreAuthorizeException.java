package com.xiaoqi.common.core.exception;

/**
 * 权限异常
 *
 * @author xiaoqi
 */
public class PreAuthorizeException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public PreAuthorizeException() {
    }
}
