## 安装配置
`1.见安装部署文档中seata部分;`

## 修改配置文件
````
注意:
    1.所有需要分布式的微服务均要在nacos配置文件中添加以下配置;
    2.需要数据回滚的微服务的数据库,需创建以下表(建议所有参与分布式事务,都添加此表):
    CREATE TABLE `undo_log` (
      `branch_id` bigint(20) NOT NULL COMMENT 'branch transaction id',
      `xid` varchar(100) NOT NULL COMMENT 'global transaction id',
      `context` varchar(128) NOT NULL COMMENT 'undo_log context,such as serialization',
      `rollback_info` longblob NOT NULL COMMENT 'rollback info',
      `log_status` int(11) NOT NULL COMMENT '0:normal status,1:defense status',
      `log_created` datetime(6) NOT NULL COMMENT 'create datetime',
      `log_modified` datetime(6) NOT NULL COMMENT 'modify datetime',
      UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AT transaction mode undo table';


# seata配置
seata:
  registry: # seata tc服务注册中心的配置，微服务根据这些信息去注册中心获取tc服务地址
    # 下面参考seata服务的registry.conf中的配置
    type: nacos
    nacos:
      server-addr: 192.168.136.128:8848
      namespace: ""
      group: DEFAULT_GROUP
      application: seata-server # tc服务在nacos中的服务名称
  tx-service-group: seata-sz # 事务组，根据这个获取tc服务的cluster名称
  service:
    vgroup-mapping: # 事务组与tc服务cluster的映射关系
      seata-sz: ""
  data-source-proxy-mode: AT

````
## Seata分布式事务解决方案
````
1.XA模式：强一致性分阶段事务模式，牺牲了一定的可用性，无业务入侵（CP模式）;
2.TCC模式：最终一致的分阶段事务模式，有业务侵入（AP模式）;
3.AT模式：最终一致的分阶段事务模式，无业务侵入，也是Seata的默认模式（AP模式）,参与分布式事务的微服务,应该全部交给seata代理数据库操作,否则有几率产生脏数据;
4.SAGA模式：长事务模式，有业务侵入（AP模式）;
````
## TCC代码调用说明
1.接口
````
package com.xiaoqi.vehilce.service;

import io.seata.rm.tcc.api.BusinessActionContext;
import io.seata.rm.tcc.api.BusinessActionContextParameter;
import io.seata.rm.tcc.api.LocalTCC;
import io.seata.rm.tcc.api.TwoPhaseBusinessAction;

@LocalTCC
public interface ITccService {

    /**
     * TCC中try预留资源
     *
     * @param userId 用户id
     * @param money  扣减金额
     */
    @TwoPhaseBusinessAction(name = "decuct", commitMethod = "confirm", rollbackMethod = "cancel")
    void decuct(@BusinessActionContextParameter(paramName = "userId") String userId, @BusinessActionContextParameter(paramName = "money") int money);

    /**
     * 扣减资源
     *
     * @param context try方法参数在context, 也许用的到
     * @return
     */
    boolean confirm(BusinessActionContext context);

    /**
     * 恢复资源
     *
     * @param context try方法参数在context, 也许用的到
     * @return
     */
    boolean cancel(BusinessActionContext context);
}
2.实现类
package com.xiaoqi.vehilce.service.impl;

import com.xiaoqi.vehilce.service.ITccService;
import io.seata.core.context.RootContext;
import io.seata.rm.tcc.api.BusinessActionContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TCCServiceImpl implements ITccService {
    /**
     * TCC中try预留资源
     *
     * @param userId 用户id
     * @param money  扣减金额
     */
    @Override
    @Transactional
    public void decuct(String userId, int money) {

        // 获取全局事务ID
        String xid = RootContext.getXID();
    }

    /**
     * 扣减资源
     *
     * @param context try方法参数在context, 也许用的到
     * @return
     */
    @Override
    public boolean confirm(BusinessActionContext context) {

        // 获取全局事务ID
        String xid = RootContext.getXID();

        return false;
    }

    /**
     * 恢复资源
     *
     * @param context try方法参数在context, 也许用的到
     * @return
     */
    @Override
    public boolean cancel(BusinessActionContext context) {

        // 获取全局事务ID
        String xid = RootContext.getXID();
        return false;
    }
}

````
## AT调用说明
1.发起全局事务的方法需要添加@GlobalTransactional
````
    /**
     * 新增安全员基础信息
     *
     * @param vehilceSafetyInfo 安全员基础信息
     * @return 结果
     */
    @Override
    @GlobalTransactional
    public int insertVehilceSafetyInfo(VehilceSafetyInfo vehilceSafetyInfo)
    {
        SysDictType dictType = new SysDictType();
        dictType.setDictName("手机品牌");
        dictType.setDictType("phone_type");
        dictType.setStatus("0");
        dictType.setCreateBy(SecurityUtils.getUsername());
        remoteDictService.add(dictType);
        int m = 1/0;
        vehilceSafetyInfo.setCreateTime(DateUtils.getNowDate());
        return vehilceSafetyInfoMapper.insertVehilceSafetyInfo(vehilceSafetyInfo);
    }
````
