package com.xiaoqi.common.netty.utils;

/**
 * Created by yxj on 16-9-10.
 * 基本数据类型转换为16进试制输出
 */
public class HexUtil {
    /**
     * 把int类型数据转换为16进度字符串车位，如：0x0E0406A1转换后为0E0406A1
     * 始传入的是0x0B(10进制为11)，转换后为0000000B
     *
     * @param data
     * @return
     */
    public static String int2Hex(int data) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 4; i++) {
            int moveBits = (4 - 1 - i) * 8;
            byte temp = (byte) (data >> moveBits);
            String hex = Integer.toHexString(temp & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex);
        }
        return sb.toString().toUpperCase();
    }

    /**
     * 把short类型数据转换为16进度字符串车位，如：0x06A1转换后为06A1
     * 始传入的是0x0B(10进制为11)，转换后为000B
     *
     * @param data
     * @return
     */
    public static String short2Hex(short data) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 2; i++) {
            int moveBits = (2 - 1 - i) * 8;
            byte temp = (byte) (data >> moveBits);
            String hex = Integer.toHexString(temp & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex);
        }
        return sb.toString().toUpperCase();
    }

    /**
     * 把byte类型数据转换为16进度字符串车位，如：0xA1转换后为A1
     *
     * @param data
     * @return
     */
    public static String byte2Hex(byte data) {
        String hex = Integer.toHexString(data & 0xFF);
        StringBuffer sb = new StringBuffer();
        if (hex.length() == 1) {
            hex = '0' + hex;
        }
        sb.append(hex);
        return sb.toString().toUpperCase();
    }

    /**
     * 将指定byte数组转换为16进制的形式的字符串
     *
     * @param b
     * @return
     */
    public static String byteArray2Hex(byte[] b) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < b.length; i++) {
            String hex = Integer.toHexString(b[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex);
        }
        return sb.toString().toUpperCase();
    }
}
