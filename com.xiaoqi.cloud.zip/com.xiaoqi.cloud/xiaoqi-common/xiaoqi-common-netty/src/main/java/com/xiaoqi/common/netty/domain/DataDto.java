package com.xiaoqi.common.netty.domain;

import com.xiaoqi.common.netty.enums.DataType;

public class DataDto {

    /**
     * 数据类型
     */
    private DataType type;

    /**
     * 数据
     */
    private String data;

    public DataDto(DataType type, String data) {
        this.type = type;
        this.data = data;
    }

}
