package com.xiaoqi.common.netty.executor;

import com.xiaoqi.common.netty.client.ClientApplication;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "netty.client.enabled", matchIfMissing = true)
public class ClientApplicationRunner implements ApplicationRunner {


    @Override
    public void run(ApplicationArguments args) throws Exception {
        // 启动netty服务端
        ClientApplication.connect("127.0.0.1", 3233);
    }
}
