package com.xiaoqi.common.netty.client.service.impl;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.xiaoqi.common.netty.annotation.NettyListener;
import com.xiaoqi.common.netty.domain.BasicDto;
import com.xiaoqi.common.netty.service.IBaseDecoderService;
import io.netty.channel.ChannelHandlerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("loginReturnDecoderServiceImpl")
@NettyListener(optCmd = 102, serviceName = "loginReturnDecoderServiceImpl", des = "设备登录返回")
public class LoginReturnDecoderServiceImpl implements IBaseDecoderService {

    private static final Logger log = LoggerFactory.getLogger(LoginReturnDecoderServiceImpl.class);

    @Override
    public BasicDto opration(ChannelHandlerContext ctx, BasicDto dto) {

        this.decoder(dto);
        return null;
    }

    /**
     * 解码
     *
     * @param dto
     * @return
     */
    @Override
    public BasicDto decoder(BasicDto dto) {

        log.info("设备登录返回:{}", dto.toString());

        String data = new String(dto.getData());
        log.info("data:{}", new String(dto.getData()));
        JSONObject json = (JSONObject) JSON.parse(data);
        return null;
    }


}
