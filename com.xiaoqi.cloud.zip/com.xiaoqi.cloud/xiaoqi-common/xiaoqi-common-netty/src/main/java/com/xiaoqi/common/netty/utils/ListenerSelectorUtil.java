package com.xiaoqi.common.netty.utils;

import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.netty.annotation.NettyListener;
import com.xiaoqi.common.netty.service.IBaseDecoderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 处理业务监听器
 */
@Slf4j
public class ListenerSelectorUtil {

    /**
     * 监听器缓存
     */
    private final static Map<Integer, NettyListener> listenerCache = new ConcurrentHashMap<>();


    /**
     * 初始化所有添加OptHandler的服务
     *
     * @return
     */
    static {
        init();
    }

    /**
     * 初始化监听器缓存
     */
    private static void init() {
        SpringUtils.getBeanNamesForAnnotation(NettyListener.class).stream().forEach(vo -> {

            Class clazz = SpringUtils.getBean(vo).getClass();
            NettyListener annotation = (NettyListener) clazz.getAnnotation(NettyListener.class);
            if (annotation != null) {
                // 打印注解中的内容
                Assert.isTrue(!(annotation.des().equals("") || annotation.optCmd() == 0 ||
                                annotation.serviceName().equals("")),
                        clazz.getSimpleName() + "类的操作码,服务名称,服务描述不能为空");
                log.info("类名:{}, optCmd:{}, serviceName:{}, desc:{}", clazz.getSimpleName(), annotation.optCmd(), annotation.serviceName(), annotation.des());
                listenerCache.put(annotation.optCmd(), annotation);
            }
        });
    }

    /**
     * 选择监听器
     *
     * @param optCmd 操作码
     * @return
     */
    public static IBaseDecoderService selectServiceByOpCode(int optCmd) {

        NettyListener nettyListener = listenerCache.get(optCmd);
        return SpringUtils.getBean(nettyListener.serviceName());
    }
}
