package com.xiaoqi.common.netty.service;

import com.xiaoqi.common.netty.domain.BasicDto;
import io.netty.channel.ChannelHandlerContext;

/**
 * 业务解码接口
 */
public interface IBaseDecoderService<T> {

    /**
     * 处理业务逻辑
     *
     * @param ctx
     * @param dto
     * @return
     */
    BasicDto opration(ChannelHandlerContext ctx, BasicDto dto);


    /**
     * 解码
     *
     * @param dto
     * @return
     */
    T decoder(BasicDto dto);
}
