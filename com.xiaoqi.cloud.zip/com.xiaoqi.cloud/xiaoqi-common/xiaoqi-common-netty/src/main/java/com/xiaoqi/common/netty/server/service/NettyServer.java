package com.xiaoqi.common.netty.server.service;

import com.xiaoqi.common.netty.domain.BasicDto;
import com.xiaoqi.common.netty.domain.ChannelSession;
import org.springframework.stereotype.Component;

/**
 * netty服务端
 */
@Component
public class NettyServer {

    /**
     * 向指定设备编号的通道发送数据
     *
     * @param deviceId 设备编号,设备登录时上报
     * @param basicDto 数据
     */
    public void send(String deviceId, BasicDto basicDto) {
        ChannelSession.queryChannelByDevNo(deviceId).getSocketChannel().writeAndFlush(basicDto);
    }
}
