package com.xiaoqi.common.netty.domain;


/**
 * BasicDto中data默认信息体
 */

public class ResultDto {

    /**
     * 状态码
     */
    private short code;

    /**
     * 错误描述
     */
    private String msg;

    public short getCode() {
        return code;
    }

    public void setCode(short code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
