package com.xiaoqi.common.netty.server.service.impl;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.xiaoqi.common.netty.annotation.NettyListener;
import com.xiaoqi.common.netty.domain.BasicDto;
import com.xiaoqi.common.netty.domain.ChannelDto;
import com.xiaoqi.common.netty.domain.ChannelSession;
import com.xiaoqi.common.netty.service.IBaseDecoderService;
import com.xiaoqi.common.netty.utils.CoderUtil;
import com.xiaoqi.common.netty.utils.ResultDtoUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.SocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service("loginDecoderServiceImpl")
@NettyListener(optCmd = 101, serviceName = "loginDecoderServiceImpl", des = "设备登录")
public class LoginDecoderServiceImpl implements IBaseDecoderService {

    private static final Logger log = LoggerFactory.getLogger(LoginDecoderServiceImpl.class);

    @Override
    public BasicDto opration(ChannelHandlerContext ctx, BasicDto dto) {

        String deviceId = this.decoder(dto);
        // 设备向session中注册
        ChannelDto channel = new ChannelDto();
        channel.setChannelId(ctx.channel().id().asShortText());
        channel.setCreateDate(new Date());
        channel.setSocketChannel((SocketChannel) ctx.channel());
        channel.setCtx(ctx);
        channel.setDeviceId(deviceId);
        ChannelSession.registerDevice(deviceId, channel);

        return CoderUtil.createBasicDto(102, 1111, JSON.toJSONString(ResultDtoUtil.success()));
    }

    /**
     * 解码
     *
     * @param dto
     * @return
     */
    @Override
    public String decoder(BasicDto dto) {

        log.info("设备登录:{}", dto.toString());

        String data = new String(dto.getData());
        log.info("data:{}", new String(dto.getData()));
        JSONObject json = (JSONObject) JSON.parse(data);

        return json.getString("deviceId");
    }


}
