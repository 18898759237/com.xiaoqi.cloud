package com.xiaoqi.common.netty.server.handler;


import com.xiaoqi.common.core.utils.SpringUtils;

import com.xiaoqi.common.netty.domain.BasicDto;
import com.xiaoqi.common.netty.domain.ChannelSession;
import com.xiaoqi.common.netty.service.IBaseDecoderService;
import com.xiaoqi.common.netty.utils.ListenerSelectorUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 处理终端上报的数据
 *
 * @author Administrator
 */

public class ServerChannelHandler extends SimpleChannelInboundHandler<BasicDto> {

    private static final Logger log = LoggerFactory.getLogger(ServerChannelHandler.class);

    /**
     * 当客户端连上服务器的时候会触发此函数
     *
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        log.info("channel id =={}", ctx.channel().id());
    }

    /**
     * 当客户端断开连接的时候触发函数
     *
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        log.info("clinet:{} leave server", ctx.channel().id());
        String channelId = ctx.channel().id().asShortText();
        ctx.close();
        ChannelSession.delChannelByChannelId(channelId);
        log.error("失去连接时=========》删除管道!channelId:{}", channelId);
    }

    /**
     * 连接出错调用此方法
     *
     * @param ctx
     * @param cause
     * @throws Exception
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        String channelId = ctx.channel().id().asShortText();
        ChannelSession.delChannelByChannelId(channelId);
        ctx.close();
        cause.printStackTrace();
        log.error("连接出错调用此方法=========》删除管道!channelId:{},错误消息：{}", channelId, cause.getMessage());
    }

    /**
     * 在2分钟内没有从管道读取到数据触发的事件
     *
     * @param ctx
     * @param evt
     * @throws Exception
     */
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {

        // 非状态事件，不处理
        if (!(evt instanceof IdleStateEvent)) {
            return;
        }
        IdleStateEvent e = (IdleStateEvent) evt;
        switch (e.state()) {
            case READER_IDLE:
                //断开连接
                String channelId = ctx.channel().id().asShortText();
                ChannelSession.delChannelByChannelId(channelId);
                ctx.close();
                log.error("在2分钟内没有从管道读取到数据触发的事件=========》删除管道!channelId:{}", channelId);
                break;
            default:
                break;
        }
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, BasicDto basicDto) throws Exception {
        // 返回客户端数据
        BasicDto returnClientDto = null;
        // 根据操作码，找到对应业务处理的handler
        IBaseDecoderService listener = ListenerSelectorUtil.selectServiceByOpCode(basicDto.getOpCode());
        if (listener != null) {
            returnClientDto = listener.opration(ctx, basicDto);
        }

        if (returnClientDto != null) {
            ctx.writeAndFlush(returnClientDto);
        }
    }
}
