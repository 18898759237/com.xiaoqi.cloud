package com.xiaoqi.common.netty.utils;

import com.xiaoqi.common.netty.constant.NettyConstant;
import com.xiaoqi.common.netty.server.coder.BasicServerDecoder;
import com.xiaoqi.common.netty.domain.BasicDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 编码/解码
 */
public class CoderUtil {

    private static final Logger log = LoggerFactory.getLogger(BasicServerDecoder.class);


    /**
     * 创建基本数据流
     *
     * @param opCode 操作码
     * @param msgId  消息ID
     * @param data   数据
     * @return
     */
    public static BasicDto createBasicDto(Integer opCode, int msgId, String data) {
        BasicDto basicDto = new BasicDto();
        basicDto.setFlag(NettyConstant.PACKAGE_FLAG);
        basicDto.setVer(NettyConstant.VERSION);
        basicDto.setOpCode(opCode.shortValue());
        basicDto.setParam((byte) 1);
        basicDto.setMsgId(msgId);
        basicDto.setDataLen((short) data.getBytes().length);
        basicDto.setData(data.getBytes());
        return basicDto;
    }

}
