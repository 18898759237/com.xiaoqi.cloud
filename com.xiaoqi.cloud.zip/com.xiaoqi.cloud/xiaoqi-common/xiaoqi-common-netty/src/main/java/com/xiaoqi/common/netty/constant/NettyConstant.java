package com.xiaoqi.common.netty.constant;

/**
 * 信控灯常量配置
 */
public class NettyConstant {

    /**
     * 服务端发送消息头标志 0xA0
     */
    public static short PACKAGE_FLAG = -96;
    /**
     * 协议版本
     */
    public static byte VERSION = 1;

    /**
     * 成功 0x00
     */
    public static short SUCCESS = (byte) 0;

    /**
     * 失败 0x01
     */
    public static short FAIL = 1;

    /**
     * 长度为0的数据域
     */
    public static short DATA_0_LENGTH = (short) 0;

    public static short getPackageFlag() {
        return PACKAGE_FLAG;
    }

    public static void setPackageFlag(byte packageFlag) {
        PACKAGE_FLAG = packageFlag;
    }

    public static byte getVERSION() {
        return VERSION;
    }

    public static void setVERSION(byte VERSION) {
        NettyConstant.VERSION = VERSION;
    }

    public static short getSUCCESS() {
        return SUCCESS;
    }

    public static void setSUCCESS(byte SUCCESS) {
        NettyConstant.SUCCESS = SUCCESS;
    }

    public static short getFAIL() {
        return FAIL;
    }

    public static void setFAIL(short FAIL) {
        NettyConstant.FAIL = FAIL;
    }

    public static short getData0Length() {
        return DATA_0_LENGTH;
    }

    public static void setData0Length(short data0Length) {
        DATA_0_LENGTH = data0Length;
    }
}
