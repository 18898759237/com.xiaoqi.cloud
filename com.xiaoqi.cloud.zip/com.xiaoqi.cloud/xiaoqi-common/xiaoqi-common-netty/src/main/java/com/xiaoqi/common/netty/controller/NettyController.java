package com.xiaoqi.common.netty.controller;

import com.xiaoqi.common.core.web.controller.BaseController;
import com.xiaoqi.common.core.web.domain.AjaxResult;
import com.xiaoqi.common.netty.client.service.NettyClient;
import com.xiaoqi.common.netty.utils.CoderUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 测试车辆基础信息Controller
 *
 * @author xiaoqi
 * @date 2023-12-22
 */
@RestController
@RequestMapping("/netty")
@Api(tags = "netty测试")
public class NettyController extends BaseController {

    @Autowired
    private NettyClient nettyClient;

    /**
     * 终端信息发送
     */
    @ApiOperation(value = "终端信息发送")
    @GetMapping("/clientSend")
    public AjaxResult clientSend(@RequestParam Integer opCode, @RequestParam int msgId, @RequestParam String data) {
        nettyClient.send(CoderUtil.createBasicDto(opCode, msgId, data));
        return success();
    }

    /**
     * 服务端信息发送
     */
    @ApiOperation(value = "服务端信息发送")
    @GetMapping("/serverSend")
    public AjaxResult ServerSend(@RequestParam String deviceId, @RequestParam Integer opCode, @RequestParam int msgId, @RequestParam String data) {
        nettyClient.send(CoderUtil.createBasicDto(opCode, msgId, data));
        return success();
    }
}
