package com.xiaoqi.common.netty.client.service;

import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.netty.client.ClientApplication;
import com.xiaoqi.common.netty.domain.BasicDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * netty客户端
 */
@Service
@Slf4j
public class NettyClient {

    /**
     * 向netty服务端发送数据
     *
     * @param basicDto 数据内容
     */
    public void send(BasicDto basicDto) {
        log.info("发送BasicDto:{}", JSON.toJSON(basicDto));
        ClientApplication.future.channel().writeAndFlush(basicDto);
    }
}
