package com.xiaoqi.common.netty.server;


import com.xiaoqi.common.netty.server.coder.BasicServerDecoder;
import com.xiaoqi.common.netty.server.coder.BasicServerEncoder;
import com.xiaoqi.common.netty.server.handler.ServerChannelHandler;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * netty服务端
 */
public class ServerApplication {

    private static final Logger log = LoggerFactory.getLogger(ServerApplication.class);

    public static EventLoopGroup bossGroup = new NioEventLoopGroup(200);//mainReactor 处理链接
    public static EventLoopGroup workGroup = new NioEventLoopGroup(200);//负责处理已建立的客户端通道上的数据读写；


    /**
     * netty服务端启动
     *
     * @param port 端口号
     */
    public static void run(int port) throws InterruptedException {


        // 首先，netty通过ServerBootstrap启动服务端
        ServerBootstrap server = new ServerBootstrap();
        //第1步定义两个线程组，用来处理客户端通道的accept和读写事件
        //parentGroup用来处理accept事件，childgroup用来处理通道的读写事件
        //parentGroup获取客户端连接，连接接收到之后再将连接转发给childgroup去处理
        server.group(bossGroup, workGroup);

        //第2步绑定服务端通道
        server.channel(NioServerSocketChannel.class);
        server.handler(new LoggingHandler(LogLevel.INFO));
        //用于构造服务端套接字ServerSocket对象，标识当服务器请求处理线程全满时，用于临时存放已完成三次握手的请求的队列的最大长度。
        //用来初始化服务端可连接队列
        //服务端处理客户端连接请求是按顺序处理的，所以同一时间只能处理一个客户端连接，多个客户端来的时候，服务端将不能处理的客户端连接请求放在队列中等待处理，backlog参数指定了队列的大小。
        server.option(ChannelOption.SO_BACKLOG, 1024);

        server.childOption(ChannelOption.SO_KEEPALIVE, true);

        //第3步绑定handler，处理读写事件，ChannelInitializer是给通道初始化
        server.childHandler(new ChannelInitializer<SocketChannel>() {
            @Override
            protected void initChannel(SocketChannel ch) throws Exception {
                // 超时处理：参数分别为读超时时间、写超时时间、读和写都超时时间、时间单位(秒)
                ch.pipeline().addLast(new IdleStateHandler(60 * 2, 0, 0));
                ch.pipeline().addLast(new BasicServerDecoder());
                ch.pipeline().addLast(new BasicServerEncoder());
                //把传过来的数据 转换成byteBuf
                ch.pipeline().addLast(new ServerChannelHandler());
            }
        });
        //第4步绑定端口
        ChannelFuture future = server.bind(port).sync();
        //当通道关闭了，就继续往下走
        future.channel().closeFuture().sync();
    }
}
