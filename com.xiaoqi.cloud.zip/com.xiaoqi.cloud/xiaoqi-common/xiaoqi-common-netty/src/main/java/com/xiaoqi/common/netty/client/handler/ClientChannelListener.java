package com.xiaoqi.common.netty.client.handler;

import com.xiaoqi.common.netty.client.ClientApplication;
import com.xiaoqi.common.netty.constant.NettyConfig;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

public class ClientChannelListener implements ChannelFutureListener {

    private static final Logger log = LoggerFactory.getLogger(ClientChannelListener.class);

    @Override
    public void operationComplete(ChannelFuture channelFuture) throws Exception {
        if (!channelFuture.isSuccess()) {
            log.info("连接失败，尝试重新连接！");

            // 在连接失败后，5秒后尝试重新连接
            channelFuture.channel().eventLoop().schedule(() -> {
                try {
                    ClientApplication.connect(NettyConfig.host, NettyConfig.port);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }, 5, TimeUnit.SECONDS);
        } else {
            log.info("客户端连接服务器成功！");
        }
    }
}
