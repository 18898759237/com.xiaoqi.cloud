package com.xiaoqi.common.netty.client.coder;


import com.xiaoqi.common.netty.constant.NettyConstant;
import com.xiaoqi.common.netty.domain.BasicDto;
import com.xiaoqi.common.netty.utils.HexUtil;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * 终端端解码器
 */

public class BasicClientDecoder extends ByteToMessageDecoder {

    private static final Logger log = LoggerFactory.getLogger(BasicClientDecoder.class);

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws
            Exception {

        /**  数据包的帧格式如下：
         *   起始标记  协议版本  操作码   参数   MsgID   数据长度    数据    数据校验
         *   2B       2B        2B      1B     4B       2B       （N）B     1B
         */

        // 数据总长度
        int dataSize = in.readableBytes();
        // 数据包格式不符合协议
        if (dataSize <= 12) {
            log.error("服务端解码失败，数据长度：{} <= 12", dataSize);
            return;
        }
        in.markReaderIndex();
        // 读取包头
        short flag = in.readShort();
        // 数据包，不含包头
        if (flag != NettyConstant.PACKAGE_FLAG) {
            byte[] bodyBytes = new byte[dataSize - 2];
            in.readBytes(bodyBytes);
            log.error("非法数据, flag:{}, 报文体:{}", flag, HexUtil.byteArray2Hex(bodyBytes));
            return;
        }
        // 协议版本
        short ver = in.readShort();
        // 操作码
        short opCode = in.readShort();
        // 参数
        byte param = in.readByte();
        // 消息id,MsgID
        int msgId = in.readInt();
        // 消息正文长度
        short dataLen = in.readShort();

        // 封装消息体
        BasicDto dto = new BasicDto();
        dto.setFlag(flag);
        dto.setVer(ver);
        dto.setOpCode(opCode);
        dto.setParam(param);
        dto.setMsgId(msgId);
        dto.setDataLen(dataLen);

        //防止粘包
        if (in.readableBytes() < (dataLen + 1)) {
            in.resetReaderIndex(); // ByteBuf回到标记位置
            return;
        }
        //从二进制转换成对象
        if (dataLen > 0) {
            byte[] bodyBytes = new byte[dataLen];
            in.readBytes(bodyBytes);
            dto.setData(bodyBytes);
        }
        //crc 校验
        dto.setCrcValue(in.readByte());
        out.add(dto);
    }
}
