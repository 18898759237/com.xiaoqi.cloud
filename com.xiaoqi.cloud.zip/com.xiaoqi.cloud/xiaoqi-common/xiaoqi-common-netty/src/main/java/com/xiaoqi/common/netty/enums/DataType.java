package com.xiaoqi.common.netty.enums;

/**
 * 数据类型
 */
public enum DataType {

    /**
     * byte一个字节
     */
    BYTE(),
    /**
     * short两个字节
     */
    SHORT(),
    /**
     * int 四个字节
     */
    INT(),
    /**
     * long 8个字节
     */
    LONG(),
    /**
     * 字符串 N个字节
     */
    STRING();


}
