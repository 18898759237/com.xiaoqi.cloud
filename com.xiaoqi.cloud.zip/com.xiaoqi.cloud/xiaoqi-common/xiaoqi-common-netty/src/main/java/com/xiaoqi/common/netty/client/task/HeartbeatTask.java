package com.xiaoqi.common.netty.client.task;

import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.netty.client.ClientApplication;
import com.xiaoqi.common.netty.client.service.NettyClient;
import com.xiaoqi.common.netty.server.service.impl.LoginDecoderServiceImpl;
import com.xiaoqi.common.netty.utils.CoderUtil;
import com.xiaoqi.common.netty.utils.ResultDtoUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


/**
 * 心跳监测
 */
@Component
public class HeartbeatTask {

    private static final Logger log = LoggerFactory.getLogger(HeartbeatTask.class);
    @Autowired
    private NettyClient nettyClient;

    // 1 分钟执行一次
    @Scheduled(fixedRate = 1 * 30 * 1000)
    public void heartbeat() {
        if (ClientApplication.future == null) {
            return;
        }
        log.info("NettyClient > HeartbeatTask:{}", "心跳定时任务开始执行...");
        nettyClient.send(CoderUtil.createBasicDto(-1000, 00000, "heartbeat"));
    }
}
