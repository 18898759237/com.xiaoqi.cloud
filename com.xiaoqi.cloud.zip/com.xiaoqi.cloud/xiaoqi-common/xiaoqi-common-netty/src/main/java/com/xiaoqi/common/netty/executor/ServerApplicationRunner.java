package com.xiaoqi.common.netty.executor;

import com.xiaoqi.common.netty.server.ServerApplication;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "netty.server.enabled", matchIfMissing = true)
public class ServerApplicationRunner implements ApplicationRunner {


    @Override
    public void run(ApplicationArguments args) throws Exception {
        // 启动netty服务端
        ServerApplication.run(3233);
    }
}
