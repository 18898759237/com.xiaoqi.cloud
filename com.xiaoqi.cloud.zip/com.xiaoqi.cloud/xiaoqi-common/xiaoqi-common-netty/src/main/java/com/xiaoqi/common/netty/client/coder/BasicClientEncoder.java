package com.xiaoqi.common.netty.client.coder;


import com.xiaoqi.common.netty.constant.NettyConstant;
import com.xiaoqi.common.netty.domain.BasicDto;
import com.xiaoqi.common.netty.utils.HexUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 终端编码器
 */

public class BasicClientEncoder extends MessageToByteEncoder<BasicDto> {

    private static final Logger log = LoggerFactory.getLogger(BasicClientEncoder.class);

    @Override
    protected void encode(ChannelHandlerContext ctx, BasicDto basicDto, ByteBuf byteBuf) {
        /*  *  数据包的帧格式如下：
         *   起始标记  协议版本  操作码   参数   MsgID   数据长度     数据    数据校验
         *   2B       2B        2B      1B     4B       2B       （N）B      1B
         */

        if (basicDto.getDataLen() == 0 || null == basicDto.getData()) {
            log.error("发送数据校验失败；消息正文data:{}为空!");
            return;
        }
        // 消息正文长度
        short len = basicDto.getData() == null ? 0 : (short) basicDto.getData().length;
        //11个字节的包头+数据内容+ 校验和
        int bufLen = 13 + len + 1;
        ByteBuf buf = Unpooled.buffer(bufLen);
        buf.writeShort(NettyConstant.PACKAGE_FLAG);
        buf.writeShort(basicDto.getVer());
        buf.writeShort(basicDto.getOpCode());
        buf.writeByte(basicDto.getParam());
        buf.writeInt(basicDto.getMsgId());
        buf.writeShort(len);
        // 消息正文
        buf.writeBytes(basicDto.getData());
        //计算crc 校验和
        buf.writeByte(basicDto.culCrcValue());
        // 生成byte[]
        byte[] bytes = new byte[buf.readableBytes()];
        buf.readBytes(bytes);
        byteBuf.writeBytes(bytes);
    }
}
