package com.xiaoqi.common.netty.client.handler;


import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.netty.client.ClientApplication;
import com.xiaoqi.common.netty.constant.NettyConfig;
import com.xiaoqi.common.netty.domain.BasicDto;
import com.xiaoqi.common.netty.service.IBaseDecoderService;
import com.xiaoqi.common.netty.utils.ListenerSelectorUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 处理终端上报的数据
 *
 * @author Administrator
 */

public class ClientChannelHandler extends SimpleChannelInboundHandler<BasicDto> {

    private static final Logger log = LoggerFactory.getLogger(ClientChannelHandler.class);

    /**
     * 当客户端连上服务器的时候会触发此函数
     *
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        log.info("channel id =={}", ctx.channel().id());
    }

    /**
     * 当客户端断开连接的时候触发函数
     *
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        ClientApplication.connect(NettyConfig.host, NettyConfig.port);
    }

    /**
     * 连接出错调用此方法
     *
     * @param ctx
     * @param cause
     * @throws Exception
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        ClientApplication.connect(NettyConfig.host, NettyConfig.port);
    }

    /**
     * 在2分钟内没有从管道读取到数据触发的事件
     *
     * @param ctx
     * @param evt
     * @throws Exception
     */
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {

    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, BasicDto basicDto) throws Exception {
        // 返回客户端数据
        BasicDto returnClientDto = null;
        // 根据操作码，找到对应业务处理的handler

        IBaseDecoderService listener = ListenerSelectorUtil.selectServiceByOpCode(basicDto.getOpCode());
        if (listener != null) {
            returnClientDto = listener.opration(ctx, basicDto);
        }

        if (returnClientDto != null) {
            ctx.writeAndFlush(returnClientDto);
        }
    }
}
