package com.xiaoqi.common.netty.constant;

/**
 * netty服务端配置
 */
public class NettyConfig {

    /**
     * ip地址
     */
    public static String host;

    /**
     * 端口
     */
    public static int port;
}
