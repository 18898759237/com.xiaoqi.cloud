package com.xiaoqi.common.netty.domain;


import com.xiaoqi.common.netty.utils.HexUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * 消息体Dto
 */
@Data
public class BasicDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 包头标记
     */
    private short flag;
    /**
     * 版本号
     */
    private short ver;
    /**
     * 操作码
     */
    private short opCode;
    /**
     * 参数
     */
    private byte param;
    /**
     * 通讯帧编号
     */
    private int msgId;
    /**
     * 数据长度
     */
    private short dataLen;
    /**
     * 数据实体
     */
    private byte[] data;

    private byte crcValue;


    public byte culCrcValue() {

        if (data == null || data.length < 2) {
            return 0;//  throw new BccDataLengthNotEnoughException("BCC校验时数据长度不足");
        }
        byte bcc = data[0];
        for (int index = 1; index < data.length; index++) {
            bcc = (byte) (bcc ^ data[index]);
        }
        return bcc;
    }

    @Override
    public String toString() {
        String d = data == null ? "null" : HexUtil.byteArray2Hex(data);
        return "BasicDto{" +
                "flag=" + HexUtil.short2Hex(flag) +
                ", ver=" + HexUtil.short2Hex(ver) +
                ", opCode=" + HexUtil.short2Hex(opCode) +
                ", param=" + HexUtil.byte2Hex(param) +
                ", msgId=" + HexUtil.int2Hex(msgId) +
                ", crcValue=" + HexUtil.byte2Hex((byte) crcValue) +
                ", dataLen=" + HexUtil.short2Hex(dataLen) +

                ", data=" + d +
                '}';
    }
}
