package com.xiaoqi.common.netty.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标记解码服务
 *
 * @author xiaoqi
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface NettyListener {

    /**
     * 操作码
     */
    int optCmd() default 0;

    /**
     * 服务名称
     */
    String serviceName() default "";


    /**
     * 服务描述
     */
    String des() default "";

}
