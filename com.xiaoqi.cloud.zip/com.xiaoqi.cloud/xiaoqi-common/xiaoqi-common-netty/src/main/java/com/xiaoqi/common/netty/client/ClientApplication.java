package com.xiaoqi.common.netty.client;

import com.xiaoqi.common.netty.client.coder.BasicClientDecoder;
import com.xiaoqi.common.netty.client.coder.BasicClientEncoder;
import com.xiaoqi.common.netty.client.handler.ClientChannelHandler;
import com.xiaoqi.common.netty.client.handler.ClientChannelListener;
import com.xiaoqi.common.netty.constant.NettyConfig;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.timeout.IdleStateHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//客户端启动器
public class ClientApplication {

    private static final Logger log = LoggerFactory.getLogger(BasicClientDecoder.class);

    public static EventLoopGroup workGroup = new NioEventLoopGroup(200);//负责处理已建立的客户端通道上的数据读写；

    public static Bootstrap bootstrap;

    public static ChannelFuture future;

    /**
     * 初始化客户端配置
     */
    public static void init() {

        bootstrap = new Bootstrap();
        bootstrap.group(workGroup);
        bootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10);
        bootstrap.option(ChannelOption.SO_KEEPALIVE, true); // 避免意外断开
        bootstrap.channel(NioSocketChannel.class); // 指定通道

        bootstrap.handler(new ChannelInitializer<SocketChannel>() {
            @Override
            protected void initChannel(SocketChannel ch) throws Exception {
                // 超时处理：参数分别为读超时时间、写超时时间、读和写都超时时间、时间单位(秒)
                ch.pipeline().addLast(new IdleStateHandler(60 * 2, 0, 0));
                ch.pipeline().addLast(new BasicClientDecoder());
                ch.pipeline().addLast(new BasicClientEncoder());
                //把传过来的数据 转换成byteBuf
                ch.pipeline().addLast(new ClientChannelHandler());
            }
        });

    }

    /**
     * 连接netty服务端
     *
     * @param host ip地址
     * @param port 端口
     * @throws InterruptedException
     */
    public static void connect(String host, int port) throws InterruptedException {

        NettyConfig.host = host;
        NettyConfig.port = port;

        if (bootstrap == null) {
            ClientApplication.init();
        }
        // 连接 netty
        future = bootstrap.connect(host, port);

        //连接失败无限重连,直到连接成功为止,重连时间为5秒/次
        future.addListener(new ClientChannelListener());

        //给关闭通道进行监听
        Channel channel = future.channel();
        channel.closeFuture().sync();
    }
}
