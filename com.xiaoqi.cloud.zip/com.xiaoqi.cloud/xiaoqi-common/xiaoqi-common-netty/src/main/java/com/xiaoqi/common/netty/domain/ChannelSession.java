package com.xiaoqi.common.netty.domain;

import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.netty.server.ServerApplication;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 维护管道Session
 */
public class ChannelSession {

    private static final Logger log = LoggerFactory.getLogger(ServerApplication.class);

    /**
     * 在线设备，key:设备ID；value:管道对象
     */
    private static Map<String, ChannelDto> clientSession = new ConcurrentHashMap<String, ChannelDto>();

    /**
     * 在线设备，key:管道ID；value:管道对象
     */
    private static Map<String, ChannelDto> channelSession = new ConcurrentHashMap<>();


    /**
     * 设备登录，Session中写入设备信息
     *
     * @param deviceId:设备号
     * @param dto:管道对象
     */
    public static void registerDevice(String deviceId, ChannelDto dto) {
        if (StringUtils.isEmpty(deviceId)) {
            log.debug("调用添加方法，添加channelSession维护对象失败:设备号为空,deviceId:{}!", deviceId);
        }
        clientSession.put(deviceId, dto);
        channelSession.put(dto.getCtx().channel().id().asShortText(), dto);
        // 设备上线
        log.debug("clientSession,channelSession:" + JSON.toJSONString(clientSession));
    }


    /**
     * 根据设备id查询设备信息
     *
     * @param deviceId 设备id
     * @return
     */
    public static ChannelDto queryChannelByDevNo(String deviceId) {

        if (StringUtils.isEmpty(deviceId)) {
            log.debug("获取管道维护对象失败:设备号为空,deviceId:{}!", deviceId);
            return null;
        }
        return clientSession.get(deviceId);

    }

    /**
     * 根据管道id查询设备信息
     *
     * @param channelId 管道id
     * @return
     */
    public static ChannelDto queryChannelByChannelId(String channelId) {
        if (StringUtils.isEmpty(channelId)) {
            log.debug("根据管道号获取管道维护对象:管道号为空,channelId:{}!", channelId);
            return null;
        }
        log.debug("根据管道号获取管道维护对象channelId{}", channelId);
        return channelSession.get(channelId);
    }

    /**
     * 设备离线，删除Session中设备信息
     *
     * @param channelId 管道id
     */
    public static void delChannelByChannelId(String channelId) {
        if (StringUtils.isEmpty(channelId)) {
            log.error("根据管道号获取管道维护对象:管道号为空,channelId:{}!", channelId);
            return;
        }
        ChannelDto channelDto = channelSession.get(channelId);
        if (channelDto == null) {
            return;
        }
        String deviceId = channelDto.getDeviceId();
        clientSession.remove(deviceId);
        channelSession.remove(channelId);
    }
}
