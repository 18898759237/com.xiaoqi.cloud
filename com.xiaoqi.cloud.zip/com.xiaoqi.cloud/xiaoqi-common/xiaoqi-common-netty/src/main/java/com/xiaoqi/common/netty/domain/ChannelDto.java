package com.xiaoqi.common.netty.domain;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.SocketChannel;

import java.io.Serializable;
import java.util.Date;

/**
 * 维护管道对象DTO类
 */
public class ChannelDto implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 管道ID
     */
    private String channelId;
    /**
     * socket管道
     */
    private SocketChannel socketChannel;
    /**
     * 创建时间
     */
    private Date createDate;

    /**
     * 长连接对象
     */
    private ChannelHandlerContext ctx;

    /**
     * 设备终端id
     */
    private String deviceId;


    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public SocketChannel getSocketChannel() {
        return socketChannel;
    }

    public void setSocketChannel(SocketChannel socketChannel) {
        this.socketChannel = socketChannel;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public ChannelHandlerContext getCtx() {
        return ctx;
    }

    public void setCtx(ChannelHandlerContext ctx) {
        this.ctx = ctx;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

}
