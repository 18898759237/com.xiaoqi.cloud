package com.xiaoqi.common.netty.utils;


import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.netty.constant.NettyConstant;
import com.xiaoqi.common.netty.domain.BasicDto;
import com.xiaoqi.common.netty.domain.ResultDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 错误信息工具类
 */

public class ResultDtoUtil {

    private static final Logger log = LoggerFactory.getLogger(ResultDtoUtil.class);

    /**
     * 操作成功
     *
     * @return
     */
    public static ResultDto success() {
        ResultDto resultDto = new ResultDto();
        resultDto.setCode(NettyConstant.SUCCESS);
        resultDto.setMsg("操作成功!");
        return resultDto;
    }

    /**
     * 操作失败
     *
     * @param basicDto basicDto
     * @param msg      错误描述
     * @param parmas   错误描述中参数
     * @return
     */
    public static void fail(BasicDto basicDto, String msg, String... parmas) {
        ResultDto resultDto = new ResultDto();
        resultDto.setCode(NettyConstant.FAIL);
        for (String param : parmas) {
            msg = msg.replaceFirst("\\{\\}", param);
        }
        resultDto.setMsg(msg);
        byte[] data = JSON.toJSONString(resultDto).getBytes();
        basicDto.setParam((byte) NettyConstant.FAIL);
        basicDto.setDataLen((short) data.length);
        basicDto.setData(data);
    }
}
