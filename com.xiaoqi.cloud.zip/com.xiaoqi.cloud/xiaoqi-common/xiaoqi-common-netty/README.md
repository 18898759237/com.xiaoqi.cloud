## 调用

一.服务端
````
1.启动
@Component
public class ServerApplicationRunner implements ApplicationRunner {


    @Override
    public void run(ApplicationArguments args) throws Exception {
        // 启动netty服务端
        ServerApplication.run(3233);
    }
}
2.调用
@Autowired
private NettyServer nettyServer;
nettyServer.send();
````
二.终端
````
1.启动
@Component
public class ClientApplicationRunner implements ApplicationRunner {


    @Override
    public void run(ApplicationArguments args) throws Exception {
        // 启动netty服务端
        ClientApplication.connect("127.0.0.1", 3233);
    }
}
2.调用发送
@Autowired
private NettyClient nettyClient;
nettyClient.send();
````
二.监听(client, Server均如此)
````
// 实现IBaseDecoderService接口, 添加@NettyListener(optCmd = 101, serviceName = "loginDecoderServiceImpl", des = "设备登录")
注解, 数据会分发到此实现类

@Service("loginDecoderServiceImpl")
@NettyListener(optCmd = 101, serviceName = "loginDecoderServiceImpl", des = "设备登录")
public class LoginDecoderServiceImpl implements IBaseDecoderService {

    private static final Logger log = LoggerFactory.getLogger(LoginDecoderServiceImpl.class);

    @Override
    public BasicDto opration(ChannelHandlerContext ctx, BasicDto dto) {

        String deviceId = this.decoder(dto);
        // 设备向session中注册
        ChannelDto channel = new ChannelDto();
        channel.setChannelId(ctx.channel().id().asShortText());
        channel.setCreateDate(new Date());
        channel.setSocketChannel((SocketChannel) ctx.channel());
        channel.setCtx(ctx);
        channel.setDeviceId(deviceId);
        ChannelSession.registerDevice(deviceId, channel);

        return CoderUtil.createBasicDto(102, 1111, JSON.toJSONString(ResultDtoUtil.success()));
    }

    /**
     * 解码
     *
     * @param dto
     * @return
     */
    @Override
    public String decoder(BasicDto dto) {

        log.info("设备登录:{}", dto.toString());

        String data = new String(dto.getData());
        log.info("data:{}", new String(dto.getData()));
        JSONObject json = (JSONObject) JSON.parse(data);

        return json.getString("deviceId");
    }


}
````
