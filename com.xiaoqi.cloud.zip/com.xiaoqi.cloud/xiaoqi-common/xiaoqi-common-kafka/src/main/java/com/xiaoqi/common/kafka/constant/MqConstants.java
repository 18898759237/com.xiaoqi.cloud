package com.xiaoqi.common.kafka.constant;

/**
 * RocketMq常量
 */
public class MqConstants {

    /**
     * rabbit消息id标识, 用于从消息header中,获取消息ID
     */
    public static final String MESSAGE_ID = "messageId";

}
