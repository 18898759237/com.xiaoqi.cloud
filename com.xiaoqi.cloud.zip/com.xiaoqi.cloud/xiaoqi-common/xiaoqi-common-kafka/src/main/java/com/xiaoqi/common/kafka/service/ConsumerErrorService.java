package com.xiaoqi.common.kafka.service;

import com.xiaoqi.common.kafka.domain.MqLocalMessage;

/**
 * 处理消费异常消息
 */
public interface ConsumerErrorService {

    /**
     * 保存/修改失败消息
     *
     * @param mqLocalMessage
     */
    void save(MqLocalMessage mqLocalMessage);

    /**
     * 修改失败消息为成功
     *
     * @param messageId 消息id
     */
    void updateSuccess(Long messageId);

    /**
     * 消息重试
     *
     * @param mqLocalMessage
     */
    void retrySend(MqLocalMessage mqLocalMessage);
}
