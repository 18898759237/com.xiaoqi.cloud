package com.xiaoqi.common.kafka.handler;

import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.kafka.annotation.KafkaErrorHandler;
import com.xiaoqi.common.kafka.domain.TestMessage;
import com.xiaoqi.common.kafka.utils.KafkaUtil;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * 消费者handler
 * - 同一组消费者, offset偏移量是相同; 后加入不同消费组,按下面说明消费,
 * - 该属性指定了消费者在读取一个没有偏移量的分区或者偏移量无效的情况下该作何处理：
 * - earliest：当各分区下有已提交的offset时，从提交的offset开始消费；无提交的offset时，从头开始消费分区的记录
 * - latest：当各分区下有已提交的offset时，从提交的offset开始消费；无提交的offset时，消费新产生的该分区下的数据（在消费者启动之后生成的记录）
 * - none：当各分区都存在已提交的offset时，从提交的offset开始消费；只要有一个分区不存在已提交的offset，则抛出异常
 */
@Component
public class ConsumerHandler {

    private static final Logger log = LoggerFactory.getLogger(ConsumerHandler.class);

    /**
     * 订阅多个topic
     *
     * @param consumerRecord 消息体
     * @param ack            应答
     */
    @KafkaListener(
            topics = {"vehicle.monitoring.vin.login"},  // 主题
            groupId = "listenOneTopic", // 消费组, 消费组内实行负载均衡
            concurrency = "1" // 并发数, 覆盖配置文件中的listener.concurrency配置
    )
    @KafkaErrorHandler
    public void listenOneTopic(ConsumerRecord<Object, Object> consumerRecord, Acknowledgment ack) {

        /*防止重复消费
        1.幂等-将消息id(唯一的),插入数据库,并建立唯一约束索引;
        2.redisson加分布式锁,
                RLock lock = redissonClient.getLock();
                lock.lock(10, TimeUnit.SECONDS);
                lock.unlock();
        */

        log.info("单个订阅...");
        KafkaUtil.printLog(consumerRecord);
        //int mm = 2 / 0;

        TestMessage testMessage = (TestMessage) consumerRecord.value();
        /*
        1. 业务逻辑异常, 不要捕获, 防止异常时, 偏移量被提交, 手动提交偏移量(只针对, 失败后, 后续无成功被消费的消息);
        2. 一旦后续有部分业务,处理成功时,偏移量还是会提交, 意义不大;
        3. 建议该提交还是提交, 业务处理发生错误时, 记录下错误消息, 排除问题后, 按照记录下的消息内容, topic进行二次发布,将消息丢到队尾;
        */
        ack.acknowledge();

    }

    /*
     * 订阅多个topic
     *
     * @param consumerRecord 消息体
     * @param ack            应答
     *//*
    @KafkaListener(
            topics = {"vehicle.monitoring.vin.login", "vehicle.monitoring.vin.logout"},
            groupId = "listenMultipleTopic",
            errorHandler = "ConsumerListenerErrorHandler")
    public void listenMultipleTopic(ConsumerRecord<Object, Objects> consumerRecord, Acknowledgment ack) {

        log.info("多个订阅...");
        log.info("分片位置:{}", consumerRecord.partition());
        log.info("消息主题:{}", consumerRecord.topic());
        log.info("偏移量:{}", consumerRecord.offset());
        log.info("key:{}", consumerRecord.key());
        log.info("消息内容:{}", consumerRecord.value());

        // 业务处理正确后, 业务逻辑异常, 不要捕获, 防止异常时, 偏移量被提交, 手动提交偏移量
        ack.acknowledge();
    }

    *//**
     * 订阅一类topic
     *
     * @param consumerRecord 消息体
     * @param ack            应答
     *//*
    @KafkaListener(
            topicPattern = "vehicle.monitoring.*.login",
            groupId = "listenPatternTopic",
            errorHandler = "ConsumerListenerErrorHandler")
    public void listenPatternTopic(ConsumerRecord<Object, Objects> consumerRecord, Acknowledgment ack) {

        log.info("正则订阅...");
        log.info("分片位置:{}", consumerRecord.partition());
        log.info("消息主题:{}", consumerRecord.topic());
        log.info("偏移量:{}", consumerRecord.offset());
        log.info("key:{}", consumerRecord.key());
        log.info("消息内容:{}", consumerRecord.value());

        // 业务处理正确后, 业务逻辑异常, 不要捕获, 防止异常时, 偏移量被提交, 手动提交偏移量
        ack.acknowledge();
    }*/
}
