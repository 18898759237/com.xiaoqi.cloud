package com.xiaoqi.common.kafka.service;

import cn.hutool.core.util.ReflectUtil;
import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.kafka.domain.MqLocalMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.concurrent.ExecutionException;

/**
 * 生产者发送消息
 */
@Service
@Slf4j
public class KafkaService {


    @Autowired
    private KafkaTemplate<Object, Object> kafkaTemplate;

    /**
     * 发送消息
     * - 调用此方法需要开启事务
     *
     * @param topic 主题
     * @param data  数据
     * @param <T>   数据类型
     * @throws ExecutionException
     * @throws InterruptedException
     */
    @Transactional(rollbackFor = RuntimeException.class)
    public <T> void send(String topic, T data) {
        kafkaTemplate.send(topic, data);
    }

    /**
     * 发送顺序消息
     * <p>
     * 1.生产者,利用key保证同一类消息进入同一个partition
     * <p>
     * 2.只能有一个消费者, 即同一消费组,监听同一个topic只能有一个
     * <p>
     * 3. 消费者并发数@KafkaListener(concurrency = "1")必须配置成1
     *
     * @param topic 主题
     * @param key   区分消息分类的关键字
     * @param data  消息内容
     */
    @Transactional(rollbackFor = RuntimeException.class)
    public <K, V> void sendOrderMessage(String topic, K key, V data) {
        kafkaTemplate.send(topic, key, data);
    }

    /**
     * 消费失败后,消息重发
     *
     * @param mqLocalMessage
     */
    @Transactional(rollbackFor = RuntimeException.class)
    public <T> void retrySend(MqLocalMessage mqLocalMessage) {

        Object obj = JSON.parseObject(mqLocalMessage.getMessage(),
                ReflectUtil.newInstance(mqLocalMessage.getMessageType()).getClass());

        kafkaTemplate.send(mqLocalMessage.getTopic(), obj);
    }

    /**
     * 发送ProducerRecord类型消息
     * - 调用此方法需要开启事务
     *
     * @param producerRecord 数据
     * @param <T>
     * @throws ExecutionException
     * @throws InterruptedException
     */
    // @Transactional(rollbackFor = RuntimeException.class)
    public <T> void sendProducerRecord(ProducerRecord producerRecord) throws ExecutionException, InterruptedException {

        //使用ProducerRecord发送消息
        //ProducerRecord<Object, Object> producerRecord = new ProducerRecord<>(topic, orderId, data);
        kafkaTemplate.send(producerRecord);

    }

    /**
     * 发送GenericMessage类型消息
     * - 调用此方法需要开启事务
     *
     * @param map  消息头
     * @param data 数据
     * @param <T>  数据类型
     * @throws ExecutionException
     * @throws InterruptedException
     */
    // @Transactional(rollbackFor = RuntimeException.class)
    public <T> void sendGenericMessage(Map<String, Object> map, T data) throws ExecutionException, InterruptedException {

        //使用Message发送消息
       /* Map<String, Object> map = new HashMap<>();
        map.put(KafkaHeaders.TOPIC, topic);
        map.put(KafkaHeaders.MESSAGE_KEY, orderId);*/
        GenericMessage<Object> message = new GenericMessage(data, new MessageHeaders(map));
        kafkaTemplate.send(message).get();
    }

}
