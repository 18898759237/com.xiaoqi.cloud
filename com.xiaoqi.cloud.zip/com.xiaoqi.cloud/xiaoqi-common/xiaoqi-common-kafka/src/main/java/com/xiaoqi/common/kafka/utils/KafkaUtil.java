package com.xiaoqi.common.kafka.utils;

import cn.hutool.core.util.ReflectUtil;
import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.kafka.constant.MqConstants;
import com.xiaoqi.common.kafka.domain.MqLocalMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;

import java.util.Date;
import java.util.Objects;

/**
 * 控制消费组监听工具类
 */
@Slf4j
public class KafkaUtil {


    /**
     * 构建本地消息
     *
     * @param consumerRecord 消息内容
     * @return
     */

    public static MqLocalMessage initMessage(ConsumerRecord consumerRecord) {

        MqLocalMessage mqLocalMessage = new MqLocalMessage();
        mqLocalMessage.setMessageId(getMessageId(consumerRecord.value()));
        mqLocalMessage.setMessage(JSON.toJSONString(consumerRecord.value()));
        mqLocalMessage.setStatus(0);
        mqLocalMessage.setRetryCount(0L);
        mqLocalMessage.setExchange("");
        mqLocalMessage.setTopic(consumerRecord.topic());
        mqLocalMessage.setCreateTime(new Date());
        mqLocalMessage.setMessageType(consumerRecord.value().getClass().getName());
        return mqLocalMessage;
    }

    /**
     * 消费者日志打印
     *
     * @param consumerRecord 消息
     */

    public static void printLog(ConsumerRecord consumerRecord) {

        log.info("分片位置:{}", consumerRecord.partition());
        log.info("消息主题:{}", consumerRecord.topic());
        log.info("消息内容:{}", JSON.toJSONString(consumerRecord.value()));
        log.info("偏移量:{}", consumerRecord.offset());
        log.info("key:{}", consumerRecord.key());
    }

    /**
     * 获取messageId
     *
     * @param message 消息
     * @param <T>
     * @return
     */
    private static <T> Long getMessageId(T message) {

        try {
            Object object = ReflectUtil.getFieldValue(message, MqConstants.MESSAGE_ID);
            Long messageId = Long.valueOf(object.toString());
            return messageId;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 暂停监听
     *
     * @param consumerGroupId consumer的group-id
     */
    public void pause(String consumerGroupId) {
        KafkaListenerEndpointRegistry registry = SpringUtils.getBean(KafkaListenerEndpointRegistry.class);
        Objects.requireNonNull(registry.getListenerContainer(consumerGroupId)).pause();
    }

    /**
     * 继续监听
     *
     * @param consumerGroupId consumer的group-id
     */
    public void resume(String consumerGroupId) {
        KafkaListenerEndpointRegistry registry = SpringUtils.getBean(KafkaListenerEndpointRegistry.class);
        Objects.requireNonNull(registry.getListenerContainer(consumerGroupId)).resume();
    }

    /**
     * 启动监听
     *
     * @param consumerGroupId consumer的group-id
     */
    public void start(String consumerGroupId) {
        KafkaListenerEndpointRegistry registry = SpringUtils.getBean(KafkaListenerEndpointRegistry.class);
        Objects.requireNonNull(registry.getListenerContainer(consumerGroupId)).start();
    }
}
