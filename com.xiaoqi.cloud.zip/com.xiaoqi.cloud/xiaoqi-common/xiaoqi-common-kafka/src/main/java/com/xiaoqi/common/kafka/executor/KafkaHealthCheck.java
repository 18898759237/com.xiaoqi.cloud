package com.xiaoqi.common.kafka.executor;

import com.google.common.collect.Maps;
import com.xiaoqi.common.core.utils.SpringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

/**
 * 校验每个队列只能监听一类消息
 * <br>
 * 1.不需要可以配置关闭rabbitmq.queue.check.enabled=false, 默认是开启状态
 * <br>
 * 2.建议一个queue只监听一类消息, 防止消息监听混乱
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "spring.kafka.consumer.check.enabled", matchIfMissing = true)
public class KafkaHealthCheck implements ApplicationRunner {

    /**
     * Callback used to run the bean.
     *
     * @param args incoming application arguments
     * @throws Exception on error
     */
    @Override
    public void run(ApplicationArguments args) throws Exception {
        check();
    }

    /**
     * 检查消费组是否重复
     */
    public void check() throws Exception {

        Map<String, String> groupMap = Maps.newHashMap();
        List<Map<String, Object>> annotationList = SpringUtils.getMethodForAnnotation(KafkaListener.class);
        for (Map map : annotationList) {

            Object obj = map.get("bean");
            Method method = (Method) map.get("method");
            KafkaListener listener = (KafkaListener) map.get("annotation");
            if (StringUtils.isEmpty(listener.groupId())) {
                String error = StringUtils.replaceEach("类名:{0}, 方法:{1}, groupId不能为空...", new String[]{"{0}", "{1}"},
                        new String[]{obj.getClass().getSimpleName(), method.getName()});
                throw new Exception(error);
            }
            String methodName = obj.getClass().getSimpleName().concat(".").concat(method.getName());
            if (groupMap.containsKey(listener.groupId())) {
                String oldObj = groupMap.get(listener.groupId());
                String error = StringUtils.replaceEach("消费组名称:{0}, 方法:{1}, {2}中重复定义...", new String[]{"{0}", "{1}", "{2}"},
                        new String[]{listener.groupId(), methodName, oldObj});
                throw new Exception(error);
            } else {
                groupMap.put(listener.groupId(), methodName);
            }

        }
    }
}
