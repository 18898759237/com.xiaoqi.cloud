package com.xiaoqi.common.kafka.config;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.support.JdbcTransactionManager;

import javax.sql.DataSource;


/**
 * 解决数据库事务与kafka事务冲突
 */
@Configuration
public class TransactionConfig {

    /**
     * 1.解决DataSourceTransactionManagerAutoConfiguration
     * ConditionalOnMissingBean(TransactionManager.class)
     * 导致spring-kafka开启事务后创建了kafkaTransactionManager而不再注册DataSourceTransactionManager
     * 2.自定义创建DataSourceTransactionManager
     * 并将DataSourceTransactionManager设为默认事务管理器
     */
    @Bean
    @Primary
    DataSourceTransactionManager transactionManager(Environment environment, DataSource dataSource,
                                                    ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
        DataSourceTransactionManager transactionManager = createTransactionManager(environment, dataSource);
        transactionManagerCustomizers.ifAvailable((customizers) -> customizers.customize(transactionManager));
        return transactionManager;
    }

    private DataSourceTransactionManager createTransactionManager(Environment environment, DataSource dataSource) {
        return environment.getProperty("spring.dao.exceptiontranslation.enabled", Boolean.class, Boolean.TRUE)
                ? new JdbcTransactionManager(dataSource) : new DataSourceTransactionManager(dataSource);
    }
}
