package com.xiaoqi.common.kafka.aspect;

import com.xiaoqi.common.kafka.annotation.KafkaErrorHandler;
import com.xiaoqi.common.kafka.domain.MqLocalMessage;
import com.xiaoqi.common.kafka.service.ConsumerErrorService;
import com.xiaoqi.common.kafka.utils.KafkaUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * mq消费失败(可用于保存失败消息)
 *
 * @author xiaoqi
 */
@Slf4j
@Aspect
@Component
public class KafkaErrorHandlerAspect {

    @Autowired
    private ConsumerErrorService consumerErrorService;

    /* *
     * 拦截异常操作
     *
     * @param joinPoint 切点
     * @param e         异常
     */
    @AfterThrowing(value = "@annotation(errorHandler)", throwing = "exception")
    public void doAfterThrowing(JoinPoint joinPoint, KafkaErrorHandler errorHandler, Exception exception) throws Exception {

        // 初始化 Message对象
        Object[] args = joinPoint.getArgs();

        ConsumerRecord<Object, Object> consumerRecord = null;
        for (Object obj : args) {
            if (obj instanceof ConsumerRecord) {
                consumerRecord = (ConsumerRecord) obj;
            }
        }
        if (null == consumerRecord) {
            throw exception;
        }

        // 消息ID
        MqLocalMessage mqLocalMessage = KafkaUtil.initMessage(consumerRecord);
        if (null == mqLocalMessage.getMessageId()) {
            log.error("消费异常, topic:{},错误信息:", mqLocalMessage.getTopic(), exception);
            return;
        }
        log.error("消费异常,消息id:{}, exchange:{}, topic:{}, 错误信息:", mqLocalMessage.getMessageId(),
                mqLocalMessage.getExchange(), mqLocalMessage.getTopic(), exception);

        consumerErrorService.save(mqLocalMessage);
    }

    /**
     * 处理完请求后执行
     *
     * @param joinPoint 切点
     */
    @AfterReturning(pointcut = "@annotation(errorHandler)")
    public void doAfterReturning(JoinPoint joinPoint, KafkaErrorHandler errorHandler) {

        // 初始化 Message对象
        Object[] args = joinPoint.getArgs();

        ConsumerRecord<Object, Objects> consumerRecord = null;
        for (Object obj : args) {
            if (obj instanceof ConsumerRecord) {
                consumerRecord = (ConsumerRecord) obj;
            }
        }
        if (null == consumerRecord) {
            return;
        }
        // 消息ID
        MqLocalMessage mqLocalMessage = KafkaUtil.initMessage(consumerRecord);
        if (null == mqLocalMessage.getMessageId()) {
            return;
        }
        consumerErrorService.updateSuccess(mqLocalMessage.getMessageId());
    }
}
