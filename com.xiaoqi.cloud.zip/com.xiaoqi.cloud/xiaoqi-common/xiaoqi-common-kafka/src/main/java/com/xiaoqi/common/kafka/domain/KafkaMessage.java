package com.xiaoqi.common.kafka.domain;

import lombok.Data;

/**
 * 消息父类
 */
@Data
public class KafkaMessage {

    /**
     * 消息id
     */
    private Long messageId;
}
