## 安装配置
1.见安装部署文档中rocketmq部分;

## 修改配置文件
````
#配置
rocketmq:
    consumer:
        # 一次拉取消息最大值，注意是拉取消息的最大值而非消费最大值
        pull-batch-size: 10
    name-server: 192.168.136.130:9876
    producer:
        # 发送同一类消息的设置为同一个group，保证唯一
        group: springboot_producer_group
        # 发送消息超时时间，默认3000
        sendMessageTimeout: 10000
        # 发送消息失败重试次数，默认2
        retryTimesWhenSendFailed: 2
        # 异步消息重试此处，默认2
        retryTimesWhenSendAsyncFailed: 2
        # 消息最大长度，默认1024 * 1024 * 4(默认4M)
        maxMessageSize: 4096
        # 压缩消息阈值，默认4k(1024 * 4)
        compressMessageBodyThreshold: 4096
        # 是否在内部发送失败时重试另一个broker，默认false
        retryNextServer: false
````
## 调用

1.  消息发布
````
#原生RocketMQTemplate
@Autowired
private RocketMQTemplate rocketMQTemplate;

#对RocketMQTemplate封装,有注释及注意事项
@Autowired
private RocketMqService rocketMqService;

````
2. 消息订阅
````
@Component
@RocketMQMessageListener(
        topic = "test_topic", // 必填, 消息主题
        selectorType = SelectorType.TAG, // 消息过滤器配置: TAG, SQL92, 默认TAG
        selectorExpression = "*", // 消息过滤器表达式, TAG模式, "*"表示所有, "test_tag1 || test_tag2"可以指定过滤, 默认"*"
        // SQL92模式, 需要在消息头中设置harder.put("a", String.valueOf(i))属性值, "a BETWEEN 6 AND 9"
        consumeMode = ConsumeMode.CONCURRENTLY, // 消费模式 : 并发消费, 顺序消费, 默认并发消费
        messageModel = MessageModel.CLUSTERING, // 订阅模式 : 负载均衡, 广播模式, 默认负载均衡模式
        consumerGroup = "springboot_consumer_group" // 必填, 以上配置, 都是针对同一消费组生效的,不同消费组,不生效, 建议和配置文件保持一致
)
public class CommonListener implements RocketMQListener<TestMessage> {

    @Override
    public void onMessage(TestMessage message) {
        // 处理消息的逻辑
        System.out.println("Received message: " + message);
    }
}
````
3.事务消息
````
a.调用

rocketMqService.sendMessageInTransaction("test_topic", message, TransactionCallbackImpl.class);

/**
 * 事务消息
 * <br>
 * 1.必须要有事务监听器 @RocketMQTransactionListener, 实现接口RocketMQLocalTransactionListener
 * <br>
 * 2.监听器无法对不同业务逻辑做区分处理, 此处用实现TransactionCallback接口类做不同业务逻辑处理
 *
 * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
 * @param payload 消息体
 * @param clazz   实现TransactionCallback接口的业务类
 */
public void sendMessageInTransaction(String topic, Object payload, Class<? extends TransactionCallback> clazz) {

    String callBackName = clazz.getAnnotation(Service.class).value();

    Message<Object> message = MessageBuilder
            .withPayload(payload)
            .setHeader("callback", callBackName)
            .build();
    rocketMQTemplate.sendMessageInTransaction(topic, message, null);
}

b.事务监听
/**
 * 事务消息监听器
 */
@Slf4j
@Component
@RequiredArgsConstructor
@RocketMQTransactionListener
public class TransactionListener implements RocketMQLocalTransactionListener {

    /**
     * 执行本地事务逻辑
     *
     * @param msg
     * @param transactionCallback
     * @return
     */
    @Override
    public RocketMQLocalTransactionState executeLocalTransaction(Message msg, Object transactionCallback) {
        String callbackName = msg.getHeaders().get("callback").toString();
        TransactionCallback callback = SpringUtils.getBean(callbackName);
        return callback.executeLocalTransaction(msg);
    }

    /**
     * 检查事务状态
     *
     * @param msg
     * @return
     */
    @Override
    public RocketMQLocalTransactionState checkLocalTransaction(Message msg) {

        String callbackName = msg.getHeaders().get("callback").toString();
        TransactionCallback callback = SpringUtils.getBean(callbackName);
        return callback.checkLocalTransaction(msg);
    }
}
````
## 消息重试表
````
CREATE TABLE `mq_local_message` (
  `message_id` bigint(20) NOT NULL COMMENT '消息id',
  `exchange` varchar(100) DEFAULT NULL COMMENT '交换机名称(非rabbitMq可以为空)',
  `topic` varchar(100) NOT NULL COMMENT '消息主题',
  `message` tinytext NOT NULL COMMENT '消息内容',
  `message_type` tinytext NOT NULL COMMENT '消息类型',
  `status` int(10) NOT NULL COMMENT '0:失败, 1:成功',
  `retry_count` tinyint(10) NOT NULL COMMENT '重试次数',
  `error_msg` text COMMENT '错误原因',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  UNIQUE KEY `inde_message_id` (`message_id`) USING BTREE COMMENT '消息id不能重复'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='本地消息表';
````
