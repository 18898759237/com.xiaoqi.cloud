package com.xiaoqi.common.rocketmq.service;

import org.apache.rocketmq.spring.core.RocketMQLocalTransactionState;
import org.springframework.messaging.Message;

public interface TransactionCallback {

    /**
     * 执行本地业务逻辑
     *
     * @param msg 消息
     * @return
     */
    RocketMQLocalTransactionState executeLocalTransaction(Message msg);

    /**
     * 检查本地业务执行情况
     *
     * @param msg 消息
     * @return
     */
    RocketMQLocalTransactionState checkLocalTransaction(Message msg);
}
