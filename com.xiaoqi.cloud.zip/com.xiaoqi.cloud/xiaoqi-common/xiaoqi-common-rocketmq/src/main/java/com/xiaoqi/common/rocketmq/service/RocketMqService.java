package com.xiaoqi.common.rocketmq.service;


import cn.hutool.core.util.ReflectUtil;
import com.alibaba.fastjson2.JSON;
import com.google.common.collect.Maps;
import com.xiaoqi.common.rocketmq.domain.MqLocalMessage;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.core.MessagePostProcessor;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Map;

/**
 * RocketMq消息发送
 */
@Service
public class RocketMqService {

    @Autowired
    private RocketMQTemplate rocketMQTemplate;


    /**
     * 普通消息(普通消息无返回值，只负责发送消息⽽不等待服务器回应且没有回调函数触发)
     *
     * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param message 消息 Message<String> msg = MessageBuilder.withPayload("Hello,RocketMQ").build()
     */
    public void send(String topic, Message message) {
        rocketMQTemplate.send(topic, message);
    }

    /**
     * 普通消息(普通消息无返回值，只负责发送消息⽽不等待服务器回应且没有回调函数触发)
     *
     * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param payload 消息内容, 会自行封装成Message
     */
    public <T> void convertAndSend(String topic, T payload) {

        rocketMQTemplate.convertAndSend(topic, payload);
    }

    /**
     * 消费失败后,消息重发
     *
     * @param mqLocalMessage
     */
    public void retryConvertAndSend(MqLocalMessage mqLocalMessage) {

        Object obj = JSON.parseObject(mqLocalMessage.getMessage(),
                ReflectUtil.newInstance(mqLocalMessage.getMessageType()).getClass());

        rocketMQTemplate.convertAndSend(mqLocalMessage.getTopic(), obj);
    }

    /**
     * 异步顺序消息
     * <p>
     * 1.生产者利用key保证同一类消息进入相同队列
     * <p>
     * 2.消费者开启 consumeMode = ConsumeMode.ORDERLY, // 消费模式 : 并发消费, 顺序消费, 默认并发消费,本质也是在保证消费者并发数是1;
     * <p>
     * 3.消费组只有一个消费者
     *
     * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param payload 消息内容, 会自行封装成Message
     * @param key     区分消息分类的关键字
     */
    public void asyncSendOrderly(String topic, Object payload, String key) {
        rocketMQTemplate.asyncSendOrderly(topic, payload, key, null);
    }

    /**
     * 事务消息
     * <br>
     * 1.必须要有事务监听器 @RocketMQTransactionListener, 实现接口RocketMQLocalTransactionListener
     * <br>
     * 2.监听器无法对不同业务逻辑做区分处理, 此处用实现TransactionCallback接口类做不同业务逻辑处理
     *
     * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param payload 消息体
     * @param clazz   实现TransactionCallback接口的业务类
     */
    public void sendMessageInTransaction(String topic, Object payload, Class<? extends TransactionCallback> clazz) {

        String callBackName = clazz.getAnnotation(Service.class).value();

        Message<Object> message = MessageBuilder
                .withPayload(payload)
                .setHeader("callback", callBackName)
                .build();
        rocketMQTemplate.sendMessageInTransaction(topic, message, null);
    }

    /**
     * 普通消息(普通消息无返回值，只负责发送消息⽽不等待服务器回应且没有回调函数触发)
     *
     * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param payload 消息内容, 会自行封装成Message
     * @param headers 消息头信息, 消费者利用sql92的方式实现消息过滤
     */
    public void convertAndSend(String topic, Object payload, Map<String, Object> headers) {
        rocketMQTemplate.convertAndSend(topic, payload, headers);
    }

    /**
     * 同步消息(同步消息有返回值SendResult，等到消息发送成功后才算结束)
     *
     * <p>超时时间与 sendMessageTimeout配置一致</p>
     *
     * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param payload 消息内容, 会自行封装成Message
     * @return
     */
    public SendResult sendSyncMsg(String topic, Object payload) {
        SendResult result = rocketMQTemplate.syncSend(topic, payload);
        return result;
    }

    /**
     * 同步批量发送
     * <br>
     * 消息体大小最大为 4MB, 一般建议发送的消息体在 4kb 之内 ( 性能最佳 )。
     * 消息属性最大为 32kb，一般建议发送的消息属性在 1kb 之内 ( 性能最佳 )
     *
     * @param topic    主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param messages 消息集合
     * @param <T>
     * @return
     */
    public <T extends Message> SendResult syncBatchSend(String topic, Collection<T> messages) {
        return rocketMQTemplate.syncSend(topic, messages);
    }

    /**
     * 异步消息
     * <br>
     * 异步消息无返回值，需要传入回调类。无需等待消息是否发送成功
     *
     * @param topic        主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param payload      消息体
     * @param sendCallback 回调函数
     */
    public void asyncSend(String topic, Object payload, SendCallback sendCallback) {
        rocketMQTemplate.asyncSend(topic, payload, sendCallback);
    }

    /**
     * 异步批量消息
     * <br>
     * 异步消息无返回值，需要传入回调类。无需等待消息是否发送成功
     *
     * @param topic        主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param messages     消息集合
     * @param sendCallback 回调函数
     */
    public <T extends Message> void asyncSend(String topic, Collection<T> messages, SendCallback sendCallback) {
        rocketMQTemplate.asyncSend(topic, messages, sendCallback);
    }

    /**
     * 单向消息
     * <br>
     * 与UDP类似，此方法在返回前不会等待代理的确认。显然，它具有最大的吞吐量，但也有消息丢失的可能性。
     *
     * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param payload 消息体
     */
    public void sendOneWay(String topic, Object payload) {
        rocketMQTemplate.sendOneWay(topic, payload);
    }

    /**
     * 同步应答消息(类似RPC调用, 性能比较差, 可用于登录等非频繁消息)
     *
     * @param topic   主题 topicName:tags，主题:标签，可单Topic不指定Tag
     * @param payload 消息体
     * @param type    消息者订阅完成后, 返回的数据类型
     * @param timeout 超时时间,单位:毫秒
     * @param <T>
     * @return
     */
    public <T> T sendAndReceive(String topic, Object payload, Type type, long timeout) {
        return rocketMQTemplate.sendAndReceive(topic, payload, type, timeout);
    }
}
