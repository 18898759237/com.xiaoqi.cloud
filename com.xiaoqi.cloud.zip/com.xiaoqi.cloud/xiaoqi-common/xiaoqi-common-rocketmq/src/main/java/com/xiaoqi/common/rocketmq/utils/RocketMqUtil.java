package com.xiaoqi.common.rocketmq.utils;

import cn.hutool.core.util.ReflectUtil;
import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.rocketmq.constant.MqConstants;
import com.xiaoqi.common.rocketmq.domain.MqLocalMessage;
import com.xiaoqi.common.rocketmq.domain.RcoketMqMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;

import java.util.Date;

/**
 * rabbit工具类
 */
@Slf4j
public class RocketMqUtil {


    /**
     * 构建本地消息
     *
     * @param message 消息内容
     * @return
     */
    public static <T> MqLocalMessage initMessage(Object message, RocketMQListener rocketMQListener) {

        // 获取对象注解
        RocketMQMessageListener listener = rocketMQListener.getClass().getAnnotation(RocketMQMessageListener.class);
        String topic = listener.topic();
        String tag = listener.selectorExpression();
        if (StringUtils.isNotEmpty(tag)) {
            topic = topic.concat(":").concat(tag);
        }
        String messageType = message.getClass().getName();
        Long messageId = getMessageId(message);
        // 构建本地消息
        MqLocalMessage mqLocalMessage = new MqLocalMessage();
        mqLocalMessage.setMessageId(messageId);
        mqLocalMessage.setMessage(JSON.toJSONString(message));
        mqLocalMessage.setStatus(0);
        mqLocalMessage.setRetryCount(0L);
        mqLocalMessage.setExchange("");
        mqLocalMessage.setTopic(topic);
        mqLocalMessage.setCreateTime(new Date());
        mqLocalMessage.setMessageType(messageType);
        return mqLocalMessage;
    }

    /* *
     * 消费者日志打印
     *
     * @param message*/

    public static void printLog(RcoketMqMessage message, RocketMQListener rocketMQListener) {
        MqLocalMessage mqLocalMessage = initMessage(message, rocketMQListener);
        log.info("routingKey:{}", mqLocalMessage.getTopic()); // 消息编号,rabbitmq自动生成,用于应答消息处理结果
        log.info("消息id：{}", mqLocalMessage.getMessageId());
        log.info("msg：{}", JSON.toJSONString(mqLocalMessage.getMessage()));
    }


    /**
     * 获取messageId
     *
     * @param message 消息
     * @param <T>
     * @return
     */
    private static <T> Long getMessageId(T message) {

        try {
            Object object = ReflectUtil.getFieldValue(message, MqConstants.MESSAGE_ID);
            Long messageId = Long.valueOf(object.toString());
            return messageId;
        } catch (Exception e) {
            return null;
        }
    }
}
