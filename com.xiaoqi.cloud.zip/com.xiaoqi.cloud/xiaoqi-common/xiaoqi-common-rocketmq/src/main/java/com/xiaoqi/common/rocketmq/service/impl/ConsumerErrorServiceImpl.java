package com.xiaoqi.common.rocketmq.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.xiaoqi.common.rocketmq.domain.MqLocalMessage;
import com.xiaoqi.common.rocketmq.mapper.MqLocalMessageMapper;
import com.xiaoqi.common.rocketmq.service.ConsumerErrorService;
import com.xiaoqi.common.rocketmq.service.RocketMqService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 本地消息Service业务层处理
 *
 * @author xiaoqi
 * @date 2024-01-08
 */
@Service
@Slf4j
public class ConsumerErrorServiceImpl implements ConsumerErrorService {
    @Autowired
    private MqLocalMessageMapper mqLocalMessageMapper;

    @Autowired
    private RocketMqService rocketMqService;

    /**
     * 保存/修改失败消息
     *
     * @param mqLocalMessage
     */
    @Override
    public void save(MqLocalMessage mqLocalMessage) {

        MqLocalMessage message = mqLocalMessageMapper.selectMqLocalMessageByMessageId(mqLocalMessage.getMessageId());
        if (null != message) {
            message.setRetryCount(message.getRetryCount() + 1);
            message.setUpdateTime(new Date());
            mqLocalMessageMapper.updateMqLocalMessage(message);
        } else {
            mqLocalMessageMapper.insertMqLocalMessage(mqLocalMessage);
        }
    }

    /**
     * 修改失败消息为成功
     *
     * @param messageId 消息id
     */
    @Override
    public void updateSuccess(Long messageId) {
        MqLocalMessage mqLocalMessage = mqLocalMessageMapper.selectMqLocalMessageByMessageId(messageId);
        if (null == mqLocalMessage) {
            return;
        }
        mqLocalMessage.setStatus(1);
        mqLocalMessage.setUpdateTime(new Date());
        mqLocalMessage.setRetryCount(mqLocalMessage.getRetryCount() + 1);
        mqLocalMessageMapper.updateMqLocalMessage(mqLocalMessage);
    }

    /**
     * 消息重试
     *
     * @param mqLocalMessage 查询条件
     */
    @Override
    public void retrySend(MqLocalMessage mqLocalMessage) {
        List<MqLocalMessage> localMessageList = mqLocalMessageMapper.selectMqLocalMessageList(mqLocalMessage);
        if (CollectionUtil.isEmpty(localMessageList)) {
            return;
        }
        for (MqLocalMessage message : localMessageList) {
            rocketMqService.retryConvertAndSend(message);
        }
    }
}
