package com.xiaoqi.common.rocketmq.domain;

import lombok.Data;

/**
 * 消息父类
 */
@Data
public class RcoketMqMessage {

    /**
     * 消息id
     */
    private Long messageId;
}
