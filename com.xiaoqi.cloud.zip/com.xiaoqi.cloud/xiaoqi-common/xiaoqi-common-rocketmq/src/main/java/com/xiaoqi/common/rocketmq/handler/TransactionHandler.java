package com.xiaoqi.common.rocketmq.handler;

import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.rocketmq.service.TransactionCallback;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.RocketMQTransactionListener;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionListener;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionState;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;


/**
 * 事务消息监听器
 */
@Slf4j
@Component
@RequiredArgsConstructor
@RocketMQTransactionListener
public class TransactionHandler implements RocketMQLocalTransactionListener {

    /**
     * 执行本地事务逻辑
     *
     * @param msg
     * @param transactionCallback
     * @return
     */
    @Override
    public RocketMQLocalTransactionState executeLocalTransaction(Message msg, Object transactionCallback) {
        String callbackName = msg.getHeaders().get("callback").toString();
        TransactionCallback callback = SpringUtils.getBean(callbackName);
        return callback.executeLocalTransaction(msg);
    }

    /**
     * 检查事务状态
     *
     * @param msg
     * @return
     */
    @Override
    public RocketMQLocalTransactionState checkLocalTransaction(Message msg) {

        String callbackName = msg.getHeaders().get("callback").toString();
        TransactionCallback callback = SpringUtils.getBean(callbackName);
        return callback.checkLocalTransaction(msg);
    }
}
