package com.xiaoqi.common.rocketmq.mapper;

import com.xiaoqi.common.rocketmq.domain.MqLocalMessage;

import java.util.List;

/**
 * 本地消息Mapper接口
 *
 * @author xiaoqi
 * @date 2024-01-08
 */
public interface MqLocalMessageMapper
{
    /**
     * 查询本地消息
     *
     * @param messageId 本地消息主键
     * @return 本地消息
     */
    public MqLocalMessage selectMqLocalMessageByMessageId(Long messageId);

    /**
     * 查询本地消息列表
     *
     * @param mqLocalMessage 本地消息
     * @return 本地消息集合
     */
    public List<MqLocalMessage> selectMqLocalMessageList(MqLocalMessage mqLocalMessage);

    /**
     * 新增本地消息
     *
     * @param mqLocalMessage 本地消息
     * @return 结果
     */
    public int insertMqLocalMessage(MqLocalMessage mqLocalMessage);

    /**
     * 修改本地消息
     *
     * @param mqLocalMessage 本地消息
     * @return 结果
     */
    public int updateMqLocalMessage(MqLocalMessage mqLocalMessage);

    /**
     * 删除本地消息
     *
     * @param messageId 本地消息主键
     * @return 结果
     */
    public int deleteMqLocalMessageByMessageId(Long messageId);

    /**
     * 批量删除本地消息
     *
     * @param messageIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteMqLocalMessageByMessageIds(Long[] messageIds);
}
