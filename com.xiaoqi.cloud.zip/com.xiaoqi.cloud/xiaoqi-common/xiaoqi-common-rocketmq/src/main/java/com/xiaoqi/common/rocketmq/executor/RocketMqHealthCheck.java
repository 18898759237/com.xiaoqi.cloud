package com.xiaoqi.common.rocketmq.executor;

import cn.hutool.core.util.ReflectUtil;
import com.google.common.collect.Maps;
import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.rocketmq.annotation.RocketMqErrorHandler;
import com.xiaoqi.common.rocketmq.constant.MqConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

/**
 * 检查订阅关系的一致性
 * <br>
 * 1.不需要可以配置关闭rocketmq.health.check.enabled=false, 默认是开启状态
 * <br>
 * 2.同一个消费者组（Group ID相同）下所有Consumer实例所订阅的Topic与Tag及对消息的处理逻辑必须完全一致。否则，消息消费的逻辑就会混乱，甚至导致消息丢失;
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "spring.rabbitmq.queue.check.enabled", matchIfMissing = true)
public class RocketMqHealthCheck implements ApplicationRunner {

    /**
     * Callback used to run the bean.
     *
     * @param args incoming application arguments
     * @throws Exception on error
     */
    @Override
    public void run(ApplicationArguments args) throws Exception {
        checkQueue();
        checkMessageId();
    }

    /**
     * 校验每个队列只能监听一类消息
     */
    public void checkQueue() throws Exception {

        Map<String, String> checkGroupMap = Maps.newHashMap();
        Map<String, String> checkTopicMap = Maps.newHashMap();
        List<String> beanList = SpringUtils.getBeanNamesForAnnotation(RocketMQMessageListener.class);
        for (String beanName : beanList) {
            Object obj = ReflectUtil.newInstance(beanName);
            RocketMQMessageListener listener = obj.getClass().getAnnotation(RocketMQMessageListener.class);
            String consumerGroup = listener.consumerGroup();
            String topic = listener.topic();
            String tag = listener.selectorExpression();
            String className = obj.getClass().getSimpleName();
            if (StringUtils.isBlank(consumerGroup)) {
                String error = StringUtils.replaceEach("类:{0}, 消费组名称不能为空...", new String[]{"{0}"},
                        new String[]{className});
                throw new Exception(error);
            }
            // 检查同一个项目中, 消费组名称是否有重复
            if (checkGroupMap.containsKey(consumerGroup)) {
                String oldClassName = checkGroupMap.get(consumerGroup);
                String error = StringUtils.replaceEach("类:{0}, {1}, 消费组名称:{2}不能重复...", new String[]{"{0}", "{1}", "{2}"},
                        new String[]{className, oldClassName, consumerGroup});
                throw new Exception(error);
            } else {
                checkGroupMap.put(consumerGroup, className);
            }

            // 检查topic是否为空
            if (StringUtils.isBlank(topic)) {
                String error = StringUtils.replaceEach("类:{0}, topic不能为空...", new String[]{"{0}"},
                        new String[]{className});
                throw new Exception(error);
            }

            // 检查tag是否同时有多个
            if (StringUtils.isNotBlank(tag) && tag.contains("||")) {
                String error = StringUtils.replaceEach("类:{0}, topic:{1}, tag;{2}不建议同一Topic下监听多个tag...", new String[]{"{0}", "{1}", "{2}"},
                        new String[]{className, topic, tag});
                throw new Exception(error);
            }

            // 检查同一个项目中, topic + tag是否有重复
            String topicTag = topic.concat(":").concat(tag);
            if (checkTopicMap.containsKey(topicTag)) {
                String oldClassName = checkTopicMap.get(topicTag);
                String error = StringUtils.replaceEach("类:{0}, {1}, topic + tag名称:{2}不能重复...", new String[]{"{0}", "{1}", "{2}"},
                        new String[]{className, oldClassName, topicTag});
                throw new Exception(error);
            } else {
                checkTopicMap.put(topicTag, className);
            }
        }
    }

    /**
     * 检查添加RocketMqErrorHandler注解的方法中的参数是否有messageId字段
     *
     * @throws NoSuchFieldException
     */
    public void checkMessageId() throws Exception {
        List<Map<String, Object>> list = SpringUtils.getMethodForAnnotation(RocketMqErrorHandler.class);
        for (Map map : list) {
            Method method = (Method) map.get("method");
            Object bean = map.get("bean");
            for (Class clazz : method.getParameterTypes()) {
                try {
                    ReflectUtil.getFieldValue(ReflectUtil.newInstance(clazz), MqConstants.MESSAGE_ID);
                } catch (Exception e) {
                    String error = StringUtils.replaceEach("类:{0}, 方法:{1}, 参数:{2}不含messageId字段, 请检查是否需要添加RocketMqErrorHandler注解...", new String[]{"{0}", "{1}", "{2}"},
                            new String[]{bean.getClass().getName(), method.getName(), clazz.getName()});

                    throw new Exception(error);
                }
            }

        }
    }
}
