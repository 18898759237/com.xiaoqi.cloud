package com.xiaoqi.common.rocketmq.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 消费异常处理
 * <p>
 * 1.添加此注解失败消息会保存到数据库
 * <p>
 * 2.若之前保存过失败消息, 添加此注解的方法, 无异常抛出, 会将失败消息状态修改为成功
 * <p>
 * 3.若方法参数,不含messageId,则不生效
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface RocketMqErrorHandler {

}
