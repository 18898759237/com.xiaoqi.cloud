package com.xiaoqi.common.rocketmq.task;

import com.xiaoqi.common.rocketmq.domain.MqLocalMessage;
import com.xiaoqi.common.rocketmq.service.ConsumerErrorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * 失败消息重试
 * <p>
 * 1.此类用于测试, 生产改成外部定时任务执行
 */
@Slf4j
@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "rocketmq.retrySend.enabled", matchIfMissing = false)
public class RocketMqTask {


    @Autowired
    private ConsumerErrorService consumerErrorService;

    // 每小时执行一次
    @Scheduled(fixedRate = 1000 * 10)
    public void retrySend() {
        log.info("失败消息重试开始...");
        MqLocalMessage mqLocalMessage = new MqLocalMessage();
        mqLocalMessage.setStatus(0);
        consumerErrorService.retrySend(mqLocalMessage);
    }
}
