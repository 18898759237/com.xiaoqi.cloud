package com.xiaoqi.common.rocketmq.handler;

import com.xiaoqi.common.core.domain.R;
import com.xiaoqi.common.rocketmq.domain.TestMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQReplyListener;
import org.springframework.stereotype.Component;

/**
 * 同步应答消息监听
 */
@Slf4j
@Component
@RocketMQMessageListener(topic = "test_topic_receive", consumerGroup = "springboot_consumer_reply_group")
public class ConsumerReplyHandler implements RocketMQReplyListener<TestMessage, R> {
    @Override
    public R onMessage(TestMessage message) {

        log.info("同步应答消息监听:{}", message);
        return R.ok();
    }
}
