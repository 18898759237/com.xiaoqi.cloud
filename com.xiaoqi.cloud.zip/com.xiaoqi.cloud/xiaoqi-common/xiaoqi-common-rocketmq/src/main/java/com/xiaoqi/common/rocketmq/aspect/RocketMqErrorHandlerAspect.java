package com.xiaoqi.common.rocketmq.aspect;

import com.xiaoqi.common.rocketmq.annotation.RocketMqErrorHandler;
import com.xiaoqi.common.rocketmq.domain.MqLocalMessage;
import com.xiaoqi.common.rocketmq.domain.RcoketMqMessage;
import com.xiaoqi.common.rocketmq.service.ConsumerErrorService;
import com.xiaoqi.common.rocketmq.utils.RocketMqUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * mq消费失败(可用于保存失败消息)
 *
 * @author xiaoqi
 */
@Slf4j
@Aspect
@Component
public class RocketMqErrorHandlerAspect {


    @Autowired
    private ConsumerErrorService consumerErrorService;

    /* *
     * 拦截异常操作
     *
     * @param joinPoint 切点
     * @param e         异常
     */
    @AfterThrowing(value = "@annotation(errorHandler)", throwing = "exception")
    public void doAfterThrowing(JoinPoint joinPoint, RocketMqErrorHandler errorHandler, Exception exception) {

        boolean status = check(joinPoint);
        if (!status) {
            return;
        }
        MqLocalMessage mqLocalMessage = RocketMqUtil.initMessage(joinPoint.getArgs()[0], (RocketMQListener) joinPoint.getTarget());
        if (null == mqLocalMessage.getMessageId()) {
            log.error("消费异常, topic:{},错误信息:", mqLocalMessage.getTopic(), exception);
            return;
        }
        log.error("消费异常,消息id:{}, topic:{},错误信息:", mqLocalMessage.getMessageId(), mqLocalMessage.getTopic(), exception);
        consumerErrorService.save(mqLocalMessage);
    }

    /**
     * 处理完请求后执行
     *
     * @param joinPoint 切点
     */
    @AfterReturning(pointcut = "@annotation(errorHandler)")
    public void doAfterReturning(JoinPoint joinPoint, RocketMqErrorHandler errorHandler) {

        boolean status = check(joinPoint);
        if (!status) {
            return;
        }
        // 初始化本地消息
        MqLocalMessage mqLocalMessage = RocketMqUtil.initMessage(joinPoint.getArgs()[0], (RocketMQListener) joinPoint.getTarget());

        if (null == mqLocalMessage.getMessageId()) {
            return;
        }
        consumerErrorService.updateSuccess(mqLocalMessage.getMessageId());
    }

    /**
     * 检查添加RocketMqErrorHandler注解的方法是否合理
     *
     * @param joinPoint
     * @return
     */
    private boolean check(JoinPoint joinPoint) {

        // 初始化 Message对象
        Object[] args = joinPoint.getArgs();
        Object message = (args != null && args.length > 0) ? args[0] : null;

        if (null == message) {
            return false;
        }
        // 判断是否实现了RocketMQListener接口
        if (!(joinPoint.getTarget() instanceof RocketMQListener)) {
            log.error("实现类:{}, 未实现RocketMQListener接口, 此方法不应添加RocketMqErrorHandler注解...", joinPoint.getTarget().getClass().getName());
            return false;
        }
        return true;
    }
}
