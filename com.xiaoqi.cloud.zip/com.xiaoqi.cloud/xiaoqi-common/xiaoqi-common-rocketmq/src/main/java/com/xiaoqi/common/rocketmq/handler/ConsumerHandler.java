package com.xiaoqi.common.rocketmq.handler;

import com.xiaoqi.common.rocketmq.annotation.RocketMqErrorHandler;
import com.xiaoqi.common.rocketmq.domain.TestMessage;
import org.apache.rocketmq.spring.annotation.ConsumeMode;
import org.apache.rocketmq.spring.annotation.MessageModel;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.annotation.SelectorType;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

@Component
@RocketMQMessageListener(
        topic = "vehicle_monitoring_vin_login", // 必填, 消息主题
        selectorType = SelectorType.TAG, // 消息过滤器配置: TAG, SQL92, 默认TAG
        selectorExpression = "*", // 消息过滤器表达式, TAG模式, "*"表示所有, "test_tag1 || test_tag2"可以指定过滤, 默认"*"
        // SQL92模式, 需要在消息头中设置harder.put("a", String.valueOf(i))属性值, "a BETWEEN 6 AND 9"
        consumeMode = ConsumeMode.CONCURRENTLY, // 消费模式 : 并发消费, 顺序消费, 默认并发消费
        messageModel = MessageModel.CLUSTERING, // 订阅模式 : 负载均衡, 广播模式, 默认负载均衡模式
        consumerGroup = "springboot_consumer_group", // 必填, 以上配置, 都是针对同一消费组生效的,不同消费组,不生效, 建议和配置文件保持一致, 同一消费组只能订阅一类消息
        maxReconsumeTimes = -1 // 默认-1即16,消费失败,重试次数

)
public class ConsumerHandler implements RocketMQListener<TestMessage> {

    @Override
    @RocketMqErrorHandler
    public void onMessage(TestMessage message) { //抛异常后, 就会消息重试
        // 处理消息的逻辑

        System.out.println("Received message: " + message);
    }
}
