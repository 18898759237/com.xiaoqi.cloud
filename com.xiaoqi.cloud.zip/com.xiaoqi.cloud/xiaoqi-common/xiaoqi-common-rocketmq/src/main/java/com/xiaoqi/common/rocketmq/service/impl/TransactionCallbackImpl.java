package com.xiaoqi.common.rocketmq.service.impl;

import com.xiaoqi.common.rocketmq.service.TransactionCallback;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionState;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Slf4j
@Service("transactionCallbackImpl")
public class TransactionCallbackImpl implements TransactionCallback {
    /**
     * 执行本地业务逻辑
     *
     * @param msg 消息
     * @return
     */
    @Override
    public RocketMQLocalTransactionState executeLocalTransaction(Message msg) {

        log.info("执行本地业务逻辑:{}", msg);
        return RocketMQLocalTransactionState.UNKNOWN;
    }

    /**
     * 检查本地业务执行情况
     *
     * @param msg 消息
     * @return
     */
    @Override
    public RocketMQLocalTransactionState checkLocalTransaction(Message msg) {
        log.info("检查本地业务执行情况:{}", msg);
        return RocketMQLocalTransactionState.COMMIT;
    }
}
