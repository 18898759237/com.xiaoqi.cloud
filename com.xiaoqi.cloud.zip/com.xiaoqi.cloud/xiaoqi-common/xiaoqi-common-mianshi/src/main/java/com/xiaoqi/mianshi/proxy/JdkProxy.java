package com.xiaoqi.mianshi.proxy;


import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

@Slf4j
public class JdkProxy {


    public static void main(String[] args) {

        Transactional trainStation = new Transactional() {
            @Override
            public void sell() {
                log.info("火车站售票!");
            }
        };
        Transactional sellTicket = (Transactional) Proxy.newProxyInstance(trainStation.getClass().getClassLoader(), trainStation.getClass().getInterfaces(),
                new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                        // 代码增强
                        log.info("开启事务...");
                        Object object = method.invoke(trainStation, args);
                        log.info("关闭事务...");
                        return object;
                    }
                });
        sellTicket.sell();
    }
}
