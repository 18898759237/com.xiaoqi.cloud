package com.xiaoqi.mianshi.lock;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 读写锁
 * 1.读锁持有锁的时候,其他读锁可以获取锁;靠计数器来完成;
 * 2.写锁持有锁的时候, 读锁需要等待;
 * 3.多读锁时,写锁可能一直获取不到锁(锁饥饿), 可以尝试使用公平锁; 也可以不加锁,使用CAS+自旋实现;
 */
@Slf4j
public class ReentrantReadWriteLockTest {

    /**
     * 读锁
     */
    private ReentrantReadWriteLock.ReadLock readLock = new ReentrantReadWriteLock(false).readLock();

    /**
     * 写锁
     */
    private ReentrantReadWriteLock.WriteLock writeLock = new ReentrantReadWriteLock(false).writeLock();

    @Test
    public void readLockTest() throws InterruptedException {

        for (int i = 0; i < 10; i++) {

            int finalI = i;
            new Thread(new Runnable() {
                @SneakyThrows
                @Override
                public void run() {
                    readLock.lock();
                    log.info("线程名称:{}", Thread.currentThread().getName() + finalI);
                    Thread.sleep(finalI);
                    log.info("释放线程名称:{}", Thread.currentThread().getName() + finalI);
                    readLock.unlock();

                }
            }, "线程").start();
        }
        Thread.sleep(5 * 1000);
        log.info("----------------------------------------分界线----------------------------------------");
        for (int i = 10; i < 20; i++) {

            int finalI = i;
            new Thread(new Runnable() {
                @SneakyThrows
                @Override
                public void run() {
                    writeLock.lock();
                    log.info("线程名称:{}", Thread.currentThread().getName() + finalI);
                    Thread.sleep(finalI);
                    log.info("释放线程名称:{}", Thread.currentThread().getName() + finalI);
                    writeLock.unlock();

                }
            }, "线程").start();
        }
        Thread.sleep(10 * 1000);
    }

}
