package com.xiaoqi.mianshi.domain;

/**
 * 测试数据类
 */
public class User {
    public volatile int number = 0;

    public void setNumberTo100() {
        number = 100;
    }

}
