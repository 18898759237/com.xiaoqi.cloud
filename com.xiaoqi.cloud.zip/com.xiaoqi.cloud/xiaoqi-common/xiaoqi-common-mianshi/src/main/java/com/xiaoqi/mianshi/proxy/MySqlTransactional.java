package com.xiaoqi.mianshi.proxy;

public class MySqlTransactional implements Transactional {
     @Override
     public void sell() {
         System.out.println("火车站售票");
     }

}
