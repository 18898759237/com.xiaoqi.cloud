package com.xiaoqi.mianshi.lock;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.util.concurrent.locks.ReentrantLock;

/**
 * 可重入的互斥锁
 * <p>
 * 1.ReentrantLock实现了Lock接口;
 * 2.AQS ( Abstract Queued Synchronizer ）是一个抽象的双向队列同步器，通过维护一个共享资源状态（ Volatile Int State ）和
 * 一个先进先出（ FIFO ）的线程等待队列来实现一个多线程访问共享资源的同步框架.
 * 3.CAS(compareAndSet)比较并交换, 是AQS即锁的状态比较的重要手段;
 * 4.synchronize、ReentrantLock、ReentrantReadWriteLock都是可重入锁;
 * 5.synchronize、ReentrantLock、ReentrantReadWriteLock均为悲观锁, 锁定资源->阻塞等待->唤醒->再试图锁定资源...->释放资源;
 * 6.严格讲 CAS + 自旋 没有锁定资源, 才能称作是乐观锁, 这种不存在死锁问题, 但是消耗cup资源;
 * 7.synchronized, Lock锁定的都是当前this对象;只是粒度不同,Lock声明必须是对象的成员变量;
 * 8.公平锁尝试获取锁,要排队; 非公平锁先直接获取锁, 获取不到进入队头进行排队;
 */
@Slf4j
public class ReentrantLockTest {

    // 公平锁, 获取锁失败,进去等待锁队列的队尾
    private ReentrantLock fairLock = new ReentrantLock(true);

    // 非公平锁, 获取锁失败, 进去等待锁队列的队尾
    private ReentrantLock noFairLock = new ReentrantLock(false);

    @Test
    public void noFairLockTest() throws InterruptedException {

        noFairLock.lock();
        new Thread(new Runnable() {
            @Override
            public void run() {
                noFairLock.lock();
                log.info("线程名称:{}", Thread.currentThread().getName());
                noFairLock.unlock();
            }
        }, "线程1").start();
        log.info("线程名称:{}", Thread.currentThread().getName());
        Thread.sleep(10 * 1000);
        noFairLock.unlock();


    }
}
