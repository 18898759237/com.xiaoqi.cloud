package com.xiaoqi.mianshi.thread;

/**
 * 继承Thread创建线程
 */
public class ExtendsThread extends Thread {

    @Override
    public void run(){
        System.out.println("Thread");
    }

}
