package com.xiaoqi.mianshi.thread;

import org.junit.Test;

import java.util.concurrent.*;

/**
 * 线程
 */
public class ThreadTest {

    /**
     * 1.实现runable接口创建线程
     */
    @Test
    public void runnableTest() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("runable");
            }
        }).start();
    }

    /**
     * 实现 callable接口创建线程
     *
     * @param <T>
     */
    @Test
    public <T> void callAbleTest() throws ExecutionException, InterruptedException {

        FutureTask<String> futureTask = new FutureTask<String>(new Callable<String>() {
            @Override
            public String call() throws Exception {
                System.out.println("Callable");
                return null;
            }
        });
        // 启动线程
        futureTask.run();

        // 获取线程执行结果
        String result = futureTask.get();
    }

    @Test
    /**
     * 继承Thread类创建线程
     */
    public void threadTest() {
        Thread thread = new Thread(new ExtendsThread());
        thread.start();
    }

    /**
     * 以线程池方式创建线程
     */
    @Test
    public void executorTest() {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        executorService.submit(new Runnable() {
            @Override
            public void run() {
                System.out.println("Executors -> Runnable");
            }
        });

        Future future = executorService.submit(new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {

                System.out.println("Executors -> Callable");
                return true;
            }
        });
    }
}
