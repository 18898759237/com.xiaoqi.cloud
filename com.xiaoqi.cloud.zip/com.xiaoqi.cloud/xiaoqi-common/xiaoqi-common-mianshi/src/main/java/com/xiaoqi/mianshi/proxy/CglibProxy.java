package com.xiaoqi.mianshi.proxy;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;


import java.lang.reflect.Method;

@Slf4j
public class CglibProxy {

    public static void main(String[] args) throws Exception {

        MySqlTransactional trainStation = new MySqlTransactional();

        Enhancer enhancer = new Enhancer();
        //设置父类的字节码对象
        enhancer.setSuperclass(trainStation.getClass());
        //设置回调函数
        enhancer.setCallback(new MethodInterceptor() {

            @Override
            public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
                // 代码增强
                log.info("开启事务...");
                Object obj = method.invoke(trainStation, objects);
                log.info("关闭事务...");
                return obj;
            }
        });
        //创建代理对象
        Transactional proxyObj = (Transactional) enhancer.create();
        proxyObj.sell();


    }
}
