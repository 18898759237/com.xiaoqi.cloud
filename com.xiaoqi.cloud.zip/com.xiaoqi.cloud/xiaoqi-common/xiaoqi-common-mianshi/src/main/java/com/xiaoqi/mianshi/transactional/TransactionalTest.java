package com.xiaoqi.mianshi.transactional;

/**
 * spring事务
 */
public class TransactionalTest {
    /**
     * 一.@Transactional事务原理
     *
     * 1.spring BeanFactory初始化的时候, 扫描添加@Transactional方法的类,并为它生成代理对象, 并缓存加有@Transactional注解的类和方法;
     * 2.此时Controller层 @Autowired private IVehicleInfoService vehicleInfoService;注入的是代理对象;
     * 3.代理对象执行实际操作前, 会进行一系列拦截器检查操作, 比如:TransactionInterceptor事务拦截器;
     * 4.TransactionInterceptor发现需要invoke的bean的方法存在需要开始事务的缓存中,则开启事务;
     * 5.invoke之后的所有方法调用, 均不是代理对象的调用, 而是真实对象的调用;
     */

    //
    /**
     * 二.事务失效场景
     *
     * 1.未添加@Transactional注解.
     * 2. 凡是private、static、final修饰的方法上面添加@Transactional; proxy代理对象invoke不到私有方法;
     * 3.proxy对象调用的方法没添加@Transactional, 后续又调用了内部类的其他加了注解的方法;此时调用内部方法的不是proxy对象,
     *   无法进行TransactionInterceptor拦截器开始事务;
     * 4.try...catch进行异常捕获,导致异常未上抛,没进行回滚;
     * 5.@Transactional(notRollbackFor=RunTimeException.class), 默认是RunTimeException异常回滚, 若抛出的是自定义异常,也不
     *   会回滚;
     *
     * 6.数据库不支持事务;
     * 7.调用对象不被spring管理;
     * 8. 第1,2,3点,主要是由spring的事务管理, Aspect是运行时,在方法中植入代码;
     *    spring事务是通过动态代理生成一个代理对象, 在调用代理对象方法之前后,进行一系列的操作;一旦invoke了真实对象方法,
     *    后续该对象调用的方法,均不受代理对象控制, 直到真实对象方法执行完, 又回到代理对象; 比如,事务开启,代理对象调用的方法
     *    未添加@Transactional注解,导致在调用真实对象方法前,未开启事务,之后也就不会再开启事务;
     */
    /**
     * 三.事务隔离级别
     *
     * 1.读未提交 -> 会出现脏读，不可重复读，幻读问题
     * 2.读已提交 -> 会出现不可重复读，幻读问题 -> 一般数据库默认级别
     * 3.可重复读 -> MySQL的默认事务隔离级别，InnoDB存储引擎通过多版本并发控制（MVCC，Multiversion Concurrency Control）机制解决了幻读问题;
     * 4.串行 -> 事务并发差;
     */
}
