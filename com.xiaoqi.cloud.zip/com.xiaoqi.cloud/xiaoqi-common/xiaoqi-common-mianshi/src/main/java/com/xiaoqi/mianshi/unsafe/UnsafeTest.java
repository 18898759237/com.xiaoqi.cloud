package com.xiaoqi.mianshi.unsafe;

import org.junit.Test;
import sun.misc.Unsafe;

public class UnsafeTest {

    @Test
    public void testUnSafe(){
        Unsafe.getUnsafe();
    }
}
