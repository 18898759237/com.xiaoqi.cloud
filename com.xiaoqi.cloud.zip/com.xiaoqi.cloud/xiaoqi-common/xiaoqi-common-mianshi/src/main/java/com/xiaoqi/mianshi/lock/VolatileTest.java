package com.xiaoqi.mianshi.lock;

/**
 * volatile
 * 1.保证可见性, 线程间的可见性;
 * 2.不保证原子性
 * 3.禁止指令重排
 */
public class VolatileTest {

    static  volatile int initFlag = 0;



    public static void main(String[] args) throws InterruptedException {

        new Thread(() -> {

            while (initFlag == 0) {
            }
            System.out.println("initFlag1--" + initFlag);
        }).start();

        Thread.sleep(200);

        new Thread(() -> {
            initFlag = 2;
            System.out.println("initFlag2--" + initFlag);
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();

        Thread.sleep(200);
        initFlag = 1;
        Thread.sleep(2000);
        System.out.println("initFlag over --" + initFlag);
    }
}


