package com.xiaoqi.mianshi.solution;

import org.jcp.xml.dsig.internal.SignerOutputStream;

class Solution {
    public static boolean canJump(int[] nums) {

        // 能到达的最远下标
        int can = nums[0];
        // 每到达一个格子， 刷新能跳到的最远距离
        for (int i = 0; i <= can && i < nums.length; i++) {
            can = Math.max(can, i + nums[i]);
        }
        // 返回最远距离can 能否到达最后一个下标
        return can >= nums.length - 1;
    }

    public static void main(String[] args) {
        boolean result = canJump(new int[]{3, 0, 0, 4});
        System.out.println(result);
    }
}
