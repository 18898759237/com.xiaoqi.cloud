package com.xiaoqi.mianshi.lock;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Atomic测试
 */
@Slf4j
public class AtomicTest {

    private AtomicInteger atomicInteger = new AtomicInteger(0);
    private volatile int num = 0;

    /**
     * 1.volatile保证线程间可见, 但是无法保证原子性.
     * 2.AtomicInteger 中 volatile int value, 保证了线程间的可见性;
     * 3.AtomicInteger  unsafe.getAndAddInt(this, valueOffset, 1), 利用可见性, CAS + 自旋,保证了原子性
     */
    @Test
    public void AtomicIntegerTest() throws InterruptedException {

        for (int i = 0; i < 1000; i++) {
            new Thread(() -> {
                try {

                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                num++;
                atomicInteger.getAndIncrement();
            }).start();
        }
        Thread.sleep(1 * 1000);
        log.info("---atomicInteger:{}, ---num:{}", atomicInteger.get(), num);
    }
}
