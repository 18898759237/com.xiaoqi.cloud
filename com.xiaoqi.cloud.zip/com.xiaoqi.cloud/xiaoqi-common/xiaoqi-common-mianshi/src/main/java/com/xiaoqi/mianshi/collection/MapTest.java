package com.xiaoqi.mianshi.collection;

import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * hashMap
 * 1.hashMap初始是16位数组 + Node链表;
 * 2.每次put方法, 都是key的hash%16,放到数组对应位置, key的hash%16若是重复, 则放到Node链表的尾端;
 * 3.按0.75进行扩容, 扩容后数组重排;
 * 4.下标位置元素个数8，则生成一棵新的红黑树，并将树的根节点添加到新数组的对应下标位置.
 * 5.hashMap是线程不安全的;
 */
@Slf4j
public class MapTest {

    // 线程不安全, Node数组
    private HashMap hashMap = new HashMap();

    // put方法锁住了,整个map, 效率低下, 竞争激烈, 底层是Entry数组;
    private Hashtable hashtable = new Hashtable();

    /*
    1.Hashtable的升级, 底层是用synchronize锁住每个node链表的头节点, 减少竞争; Node数组
    2.ConcurrentHashMap中的node的vaue, next及各种下一个节点, 都是volatile, 保证了扩容, 寻找下个node等操作时, 其他线程可见;
    3.
    */
    private ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();


    /**
     * 非线程安全
     */
    private StringBuilder sbi = new StringBuilder();

    /**
     * append方法添加了synchronized 线程安全
     */
    private StringBuffer sbf = new StringBuffer();

    private ArrayList arrayList = new ArrayList();
    /**
     * hashMap扩容机制
     */
    @Test
    public void test_01() {
        Map map = new HashMap();
        for (int i = 0; i < 100; i++) {
            map.put(i + "", i);
        }
        List mm = Lists.newArrayList();
    }
}
