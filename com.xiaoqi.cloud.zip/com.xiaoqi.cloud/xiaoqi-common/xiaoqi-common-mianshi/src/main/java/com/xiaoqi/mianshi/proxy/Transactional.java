package com.xiaoqi.mianshi.proxy;

/**
 * 事务
 */
public interface Transactional {

    void sell();
}
