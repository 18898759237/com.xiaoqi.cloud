## 安装配置
1.见安装部署文档中rabbitmq部分;

## 配置文件
````
#rabbitmq配置信息
spring:
    rabbitmq:
      host: 192.168.136.130
      port: 5672
      username: admin
      password: admin
      # 虚拟主机的方式
      virtual-host: /
      publisher-confirm-type: correlated
      listener:
        simple:
          # auto:自动确认，manual:手动确认，none:没有消息确认
          acknowledge-mode: manual
          # 配置重试机制(消费端本地重试机制)
          retry:
            # 开启消费重试机制
            enabled: true
            # 最大重试次数。默认为 3 。
            max-attempts: 3
            # 重试间隔，单位为毫秒。默认为 1000 。
            initial-interval: 1000
````
## 消息重试表
````
CREATE TABLE `mq_local_message` (
  `message_id` bigint(20) NOT NULL COMMENT '消息id',
  `exchange` varchar(100) DEFAULT NULL COMMENT '交换机名称(非rabbitMq可以为空)',
  `topic` varchar(100) NOT NULL COMMENT '消息主题',
  `message` tinytext NOT NULL COMMENT '消息内容',
  `message_type` tinytext NOT NULL COMMENT '消息类型',
  `status` int(10) NOT NULL COMMENT '0:失败, 1:成功',
  `retry_count` tinyint(10) NOT NULL COMMENT '重试次数',
  `error_msg` text COMMENT '错误原因',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  UNIQUE KEY `inde_message_id` (`message_id`) USING BTREE COMMENT '消息id不能重复'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='本地消息表';
````
