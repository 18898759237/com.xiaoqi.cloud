package com.xiaoqi.common.rabbitmq.handler;

import com.rabbitmq.client.Channel;
import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.rabbitmq.annotation.RabbitMqErrorHandler;
import com.xiaoqi.common.rabbitmq.constant.MqConstants;
import com.xiaoqi.common.rabbitmq.domain.MqLocalMessage;
import com.xiaoqi.common.rabbitmq.domain.TestMessage;
import com.xiaoqi.common.rabbitmq.service.ConsumerErrorService;
import com.xiaoqi.common.rabbitmq.utils.RabbitUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ConsumerHandler {

    @Autowired
    private ConsumerErrorService consumerErrorService;

    /**
     * 消费延时工单队列数据
     *
     * @param msg
     * @param message
     * @param channel
     */
    @RabbitListener(bindings =
    @QueueBinding(
            value = @Queue(name = "xiaoqi.topic.queue", durable = "true"), //队列，持久化为true
            exchange = @Exchange(name = MqConstants.TOPIC_EXCHANGE_NAME, type = ExchangeTypes.TOPIC), //交换机
            key = "vehicle.monitoring.*.login" // "#"通配任何零个或多个word, "*"通配任何单个word
    ),
            group = "consumer_group_01", // 消费组, 同一消费组内,负载均衡
            concurrency = "4" // 并发数, 若想实现顺序消息, 此处该设置成1, 并且消费组内只有一个消费者
    )
    @RabbitMqErrorHandler
    // TestMessage msg 消息类型要与生成者发送内容类型一致
    public void onMessage(TestMessage msg, Message message, Channel channel, @Header(AmqpHeaders.DELIVERY_TAG) long deliveryTag) throws Exception {

        log.info("消费者接受消息---------------------");

        // 消息ID
        RabbitUtil.printLog(message);
        /**
         * 处理成功
         *
         * deliveryTag : 消息编号
         * multiple : 是否批量处理, 比如: 当前deliveryTag为10, 小于10的消息未应答的消息,均按成功处理;
         */
        int mm = 2 / 0;
        channel.basicAck(deliveryTag, false);

        /**
         * 消息处理失败
         *
         * deliveryTag : 消息编号
         * multiple : 是否批量处理, 比如: 当前deliveryTag为10, 小于10的消息未应答的消息,均按requeue策略处理;
         * requeue : true:重新放回队列，false:丢弃或者进入死信队列
         */
        // channel.basicNack(deliveryTag, true, true);

        /**
         * 消息处理失败
         *
         * deliveryTag : 消息编号
         * requeue : true:重新放回队列，false:丢弃或者进入死信队列
         */
        // channel.basicReject(deliveryTag, true);

    }
}
