
package com.xiaoqi.common.rabbitmq.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 本地消息对象 mq_local_message
 *
 * @author xiaoqi
 * @date 2024-01-05
 */
@ApiModel(value = "本地消息")
@Data
public class MqLocalMessage {
    private static final long serialVersionUID = 1L;

    /**
     * 消息id
     */
    private Long messageId;

    /**
     * 交换机名称(非rabbitMq可以为空)
     */
    private String exchange;

    /**
     * 主题
     */
    private String topic;

    /**
     * 消息内容
     */
    private String message;

    /**
     * 消息类型
     */
    private String messageType;

    /**
     * 0:失败, 1:成功
     */
    private Integer status;

    /**
     * 重试次数
     */
    private Long retryCount;

    /**
     * 错误原因
     */
    private String errorMsg;


    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;


    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("messageId", getMessageId())
                .append("exchange", getExchange())
                .append("topic", getTopic())
                .append("message", getMessage())
                .append("status", getStatus())
                .append("retryCount", getRetryCount())
                .append("errorMsg", getErrorMsg())
                .append("createTime", getCreateTime())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}
