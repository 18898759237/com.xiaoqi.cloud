package com.xiaoqi.common.rabbitmq.service;


import cn.hutool.core.util.ReflectUtil;
import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.rabbitmq.constant.MqConstants;
import com.xiaoqi.common.rabbitmq.domain.MqLocalMessage;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RabbitService {

    @Autowired
    private RabbitTemplate rabbitTemplate;


    public void convertAndSend(String exchange, String routingKey, Object message, Long messageId) {

        CorrelationData correlationData = new CorrelationData(messageId + "");
        rabbitTemplate.convertAndSend(exchange, routingKey, message, correlationData);
    }

    /**
     * 消费失败后,消息重发
     *
     * @param mqLocalMessage
     */
    public void retryConvertAndSend(MqLocalMessage mqLocalMessage) {

        CorrelationData correlationData = new CorrelationData(mqLocalMessage.getMessageId() + "");
        String messageType = mqLocalMessage.getMessageType();

        Object obj = JSON.parseObject(mqLocalMessage.getMessage(), ReflectUtil.newInstance(messageType).getClass());
        rabbitTemplate.convertAndSend(mqLocalMessage.getExchange(), mqLocalMessage.getTopic(), obj, correlationData);
    }
}
