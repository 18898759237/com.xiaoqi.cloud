package com.xiaoqi.common.rabbitmq.constant;

/**
 * 交换机配置
 */
public class MqConstants {


    /**
     * topic交换机名称
     */
    public static final String TOPIC_EXCHANGE_NAME = "xiaoqi.topic.exchange";


    /**
     * DIRECT交换机名称
     */
    public static final String DIRECT_EXCHANGE_NAME = "xiaoqi.direct.exchange";

    /**
     * FANOUT交换机名称
     */
    public static final String FANOUT_EXCHANGE_NAME = "xiaoqi.fanout.exchange";


    /**
     * error交换机名称
     */
    public static final String ERROR_EXCHANGE = "xiaoqi.error.exchange";

    /**
     * error队列名称
     */
    public static final String ERROR_QUEUE = "xiaoqi.error.queue";

    /**
     * error的路由key策略
     */
    public static final String ERROR_ROUTING_KEY = "xiaoqi.error.routing.key";


    /**
     * rabbit消息id标识, 用于从消息header中,获取消息ID
     */
    public static final String MESSAGE_ID = "spring_returned_message_correlation";

    /**
     * rabbit消息类型标识
     */
    public static final String MESSAGE_TYPE = "__TypeId__";

}
