package com.xiaoqi.common.rabbitmq.aspect;

import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.rabbitmq.annotation.RabbitMqErrorHandler;
import com.xiaoqi.common.rabbitmq.domain.MqLocalMessage;
import com.xiaoqi.common.rabbitmq.service.ConsumerErrorService;
import com.xiaoqi.common.rabbitmq.utils.RabbitUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.amqp.core.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * mq消费失败(可用于保存失败消息)
 *
 * @author xiaoqi
 */
@Slf4j
@Aspect
@Component
public class RabbitMqErrorHandlerAspect {

    @Autowired
    private ConsumerErrorService consumerErrorService;

    /* *
     * 拦截异常操作
     *
     * @param joinPoint 切点
     * @param e         异常
     */
    @AfterThrowing(value = "@annotation(errorHandler)", throwing = "exception")
    public void doAfterThrowing(JoinPoint joinPoint, RabbitMqErrorHandler errorHandler, Exception exception) throws Exception {

        // 初始化 Message对象
        Object[] args = joinPoint.getArgs();
        Message amqpMessage = null;
        for (Object obj : args) {
            if (obj instanceof Message) {
                amqpMessage = (Message) obj;
            }
        }
        if (null == amqpMessage) {
            throw exception;
        }

        // 消息ID
        MqLocalMessage mqLocalMessage = RabbitUtil.initMessage(amqpMessage);

        log.error("消费异常,消息id:{}, exchange:{}, topic:{}, 错误信息:", mqLocalMessage.getMessageId(),
                mqLocalMessage.getExchange(), mqLocalMessage.getTopic(), exception);
        /**
         * 1.根据消息Id查询, 本次异常消息是否已经入库;
         * 2.若已经入库, 则不做任何处理;
         */
        consumerErrorService.save(mqLocalMessage);

    }

    /**
     * 处理完请求后执行
     *
     * @param joinPoint 切点
     */
    @AfterReturning(pointcut = "@annotation(errorHandler)")
    public void doAfterReturning(JoinPoint joinPoint, RabbitMqErrorHandler errorHandler) {

        // 初始化 Message对象
        Object[] args = joinPoint.getArgs();
        Message amqpMessage = null;
        for (Object obj : args) {
            if (obj instanceof Message) {
                amqpMessage = (Message) obj;
            }
        }
        if (null == amqpMessage) {
            return;
        }
        // 消息ID
        MqLocalMessage mqLocalMessage = RabbitUtil.initMessage(amqpMessage);
        consumerErrorService.updateSuccess(mqLocalMessage.getMessageId());
    }
}
