package com.xiaoqi.common.rabbitmq.executor;

import com.google.common.collect.Maps;
import com.xiaoqi.common.core.utils.SpringUtils;
import com.xiaoqi.common.rabbitmq.service.ConsumerErrorService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

/**
 * 校验每个队列只能监听一类消息
 * <br>
 * 1.不需要可以配置关闭rabbitmq.queue.check.enabled=false, 默认是开启状态
 * <br>
 * 2.建议一个queue只监听一类消息, 防止消息监听混乱
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "spring.rabbitmq.queue.check.enabled", matchIfMissing = true)
public class RabbitMqHealthCheck implements ApplicationRunner {

    /**
     * Callback used to run the bean.
     *
     * @param args incoming application arguments
     * @throws Exception on error
     */
    @Override
    public void run(ApplicationArguments args) throws Exception {
        checkQueue();
        checkGroup();
    }

    /**
     * 校验每个队列只能监听一类消息
     */
    public void checkQueue() throws Exception {

        Map<String, String> queueMap = Maps.newHashMap();
        List<Map<String, Object>> annotationList = SpringUtils.getMethodForAnnotation(RabbitListener.class);
        for (Map map : annotationList) {

            Object obj = map.get("bean");
            Method method = (Method) map.get("method");
            RabbitListener rabbitListener = (RabbitListener) map.get("annotation");
            if (rabbitListener.queues() != null) {
                for (String queueName : rabbitListener.queues()) {
                    if (queueMap.containsKey(queueName)) {
                        String oldObj = queueMap.get(queueName);
                        String error = StringUtils.replaceEach("队列名称:{1}, 在类名:{2}, {3}中重复定义...", new String[]{"{1}", "{2}", "{3}"},
                                new String[]{queueName, obj.getClass().getSimpleName(), oldObj});
                        throw new Exception(error);
                    } else {
                        queueMap.put(queueName, obj.getClass().getSimpleName());
                    }
                }
            }
            if (rabbitListener.bindings() != null) {
                for (QueueBinding bind : rabbitListener.bindings()) {
                    String queueName = bind.value().name();
                    if (queueMap.containsKey(queueName)) {
                        String oldObj = queueMap.get(queueName);
                        String error = StringUtils.replaceEach("队列名称:{1}, 在类名:{2}, {3}中重复定义...", new String[]{"{1}", "{2}", "{3}"},
                                new String[]{queueName, obj.getClass().getSimpleName(), oldObj});
                        throw new Exception(error);
                    } else {
                        queueMap.put(queueName, obj.getClass().getSimpleName());
                    }
                }
            }
        }
    }

    /**
     * 检查消费组是否重复
     */
    public void checkGroup() throws Exception {

        Map<String, String> groupMap = Maps.newHashMap();
        List<Map<String, Object>> annotationList = SpringUtils.getMethodForAnnotation(RabbitListener.class);
        for (Map map : annotationList) {

            Object obj = map.get("bean");
            Method method = (Method) map.get("method");
            RabbitListener listener = (RabbitListener) map.get("annotation");
            if (StringUtils.isEmpty(listener.group())) {
                String error = StringUtils.replaceEach("类名:{0}, 方法:{1}, group不能为空...", new String[]{"{0}", "{1}"},
                        new String[]{obj.getClass().getSimpleName(), method.getName()});
                throw new Exception(error);
            }
            String methodName = obj.getClass().getSimpleName().concat(".").concat(method.getName());
            if (groupMap.containsKey(listener.group())) {
                String oldObj = groupMap.get(listener.group());
                String error = StringUtils.replaceEach("消费组名称:{0}, 方法:{1}, {2}中重复定义...", new String[]{"{0}", "{1}", "{2}"},
                        new String[]{listener.group(), methodName, oldObj});
                throw new Exception(error);
            } else {
                groupMap.put(listener.group(), methodName);
            }

        }
    }
}
