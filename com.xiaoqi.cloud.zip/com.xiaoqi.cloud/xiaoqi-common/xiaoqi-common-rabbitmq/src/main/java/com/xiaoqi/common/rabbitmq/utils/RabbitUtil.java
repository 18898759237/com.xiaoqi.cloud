package com.xiaoqi.common.rabbitmq.utils;

import com.alibaba.fastjson2.JSON;
import com.xiaoqi.common.rabbitmq.constant.MqConstants;
import com.xiaoqi.common.rabbitmq.domain.MqLocalMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;

import java.util.Date;

/**
 * rabbit工具类
 */
@Slf4j
public class RabbitUtil {


    /**
     * 构建本地消息
     *
     * @param message 消息内容
     * @return
     */
    public static MqLocalMessage initMessage(Message message) {

        // 消息ID
        Long messageId = Long.valueOf(message.getMessageProperties().getHeader(MqConstants.MESSAGE_ID));
        String exchange = message.getMessageProperties().getReceivedExchange();
        String topic = message.getMessageProperties().getReceivedRoutingKey();
        String messageType = message.getMessageProperties().getHeader(MqConstants.MESSAGE_TYPE);

        MqLocalMessage mqLocalMessage = new MqLocalMessage();
        mqLocalMessage.setMessageId(messageId);
        mqLocalMessage.setMessage(new String(message.getBody()));
        mqLocalMessage.setStatus(0);
        mqLocalMessage.setRetryCount(0L);
        mqLocalMessage.setExchange(exchange);
        mqLocalMessage.setTopic(topic);
        mqLocalMessage.setCreateTime(new Date());
        mqLocalMessage.setMessageType(messageType);
        return mqLocalMessage;
    }

    /**
     * 消费者日志打印
     *
     * @param message
     */
    public static void printLog(Message message) {

        MqLocalMessage mqLocalMessage = initMessage(message);
        log.info("交换机:{}", mqLocalMessage.getExchange());
        log.info("routingKey:{}", mqLocalMessage.getTopic()); // 消息编号,rabbitmq自动生成,用于应答消息处理结果
        log.info("消息id：{}", mqLocalMessage.getMessageId());
        log.info("msg：{}", mqLocalMessage.getMessage());
    }
}
