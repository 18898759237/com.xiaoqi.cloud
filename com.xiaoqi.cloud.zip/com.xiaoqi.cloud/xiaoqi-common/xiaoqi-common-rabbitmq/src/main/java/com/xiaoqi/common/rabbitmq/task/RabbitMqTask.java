package com.xiaoqi.common.rabbitmq.task;

import com.xiaoqi.common.rabbitmq.domain.MqLocalMessage;
import com.xiaoqi.common.rabbitmq.service.ConsumerErrorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * 失败消息重试
 * <p>
 * 1.此类用于测试, 生成改成外部定时任务执行
 */
@Slf4j
@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "spring.rabbitmq.queue.retrySend.enabled", matchIfMissing = false)
public class RabbitMqTask {


    @Autowired
    private ConsumerErrorService consumerErrorService;

    // 每小时执行一次
    @Scheduled(fixedRate = 1000 * 60 * 60)
    public void retrySend() {
        log.info("失败消息重试开始...");
        MqLocalMessage mqLocalMessage = new MqLocalMessage();
        mqLocalMessage.setStatus(0);
        consumerErrorService.retrySend(mqLocalMessage);
    }
}
