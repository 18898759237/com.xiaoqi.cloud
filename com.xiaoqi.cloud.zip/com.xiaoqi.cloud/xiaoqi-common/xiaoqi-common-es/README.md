## 安装配置
1.见安装部署文档中elasticsearch, kibana部分;

## 修改配置文件
````
# elasticsearch配置,顶格写,不是spring下配置
elasticsearch:
  #es集群地址
  hosts: [192.168.136.129:9200, 192.168.136.128:9200]
  userName: elastic
  password: V8S6QLr4KxkfbsQOG+3Y
  #文档中生成的秘钥
  certPath: certs\http.p12
````
## 调用

1.  引入EsService
````
@Autowired
private EsService esService;
````
