package com.xiaoqi.common.es.utils;

import cn.hutool.core.bean.BeanUtil;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import com.xiaoqi.common.es.annotation.EsMapper;
import com.xiaoqi.common.es.domain.EsScript;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.client.Request;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.io.UnsupportedEncodingException;
import java.lang.annotation.Annotation;
import java.util.List;

/**
 * ES工具类
 */
public class EsUtil {

    private static final Logger log = LoggerFactory.getLogger(EsUtil.class);

    private static final Gson gson = new Gson();

    /**
     * 脚本查询模板
     */
    public static final String template = "{\"_source\":{\"excludes\":excludes_value,\"includes\":includes_value},\"from\":from_value,\"size\":size_value,\"sort\":sort_value,\"query\":query_value}";

    /**
     * 获取实体ID
     *
     * @param entity
     * @param <T>
     * @return
     */
    public static <T> String getEntityId(T entity) {
        Object id = BeanUtil.getFieldValue(entity, "id");
        return BeanUtil.getFieldValue(entity, "id").toString();
    }

    /**
     * 获取实体上EsMapper主键
     *
     * @param clazz 实体类型
     * @return
     */
    public static String getIndex(Class clazz) throws Exception {

        Annotation classAnnotation = clazz.getAnnotation(EsMapper.class);
        if (classAnnotation == null) {
            log.error("此实体{}未添加EsMapper注解", clazz.getName());
            throw new Exception(StringUtils.replace("此实体{}未添加EsMapper注解", "{}", clazz.getName()));
        }
        EsMapper esMapper = (EsMapper) classAnnotation;
        // 索引名称
        String index = esMapper.index();
        return index;
    }

    /**
     * 获取实体类型
     *
     * @param entity
     * @param <T>
     * @return
     */
    public static <T> Class getEntityClass(T entity) {
        return entity.getClass();
    }

    /**
     * 创建ES查询PageInfo
     *
     * @param dataList ES查询结果集
     * @param pageNum  页码
     * @param pageSize 每页多少条
     * @param total    总条数
     * @param <T>
     * @return
     */
    public static <T> PageInfo<T> createPageInfo(List<T> dataList, Integer pageNum, Integer pageSize, Integer total) {

        PageInfo<T> pageInfo = new PageInfo(dataList);
        pageInfo.setTotal(total);
        pageInfo.setPageSize(pageSize);
        pageInfo.setPageNum(pageNum);
        return pageInfo;
    }

    /**
     * 生成查询脚本
     *
     * @param esScript 脚本信息
     * @return
     */
    public static String createScriptTemplate(EsScript esScript) {
        String template = EsUtil.template;

        String script = esScript.getScript();
        for (int i = 0; i < esScript.getQueryList().size(); i++) {
            String key = i < 9 ? "{{param_0" + (i + 1) + "}}" : "{{param_" + (i + 1) + "}}";
            String value = StringUtils.trimToEmpty(esScript.getQueryList().get(i));
            Assert.isTrue(!StringUtils.isEmpty(value), "ES脚本参数不能为空!");
            script = script.replace(key, value);
        }
        // 占位符与参数数目是否一致
        boolean status = script.contains("param_");
        Assert.isTrue(!status, "占位符与参数数目不一致");

        template = template.replaceAll("excludes_value", gson.toJson(esScript.getExcludeList()))
                .replaceAll("includes_value", gson.toJson(esScript.getIncludeList()))
                .replaceAll("from_value", esScript.getFrom().toString())
                .replaceAll("size_value", esScript.getSize().toString())
                .replaceAll("sort_value", gson.toJson(esScript.getSortOptionsList()))
                .replaceAll("query_value", script)
        ;
        return template;
    }

    /**
     * 构建一个request
     *
     * @param sql 查询语句
     * @return
     * @throws UnsupportedEncodingException
     */
    public static Request buildRequest(String sql) throws UnsupportedEncodingException {
        Request request = new Request("POST", "_sql?format=json");
        NStringEntity nStringEntity = new NStringEntity(sql, "UTF-8");
        nStringEntity.setContentType("application/json");
        request.setEntity(nStringEntity);
        return request;
    }
}
