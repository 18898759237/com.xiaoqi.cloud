package com.xiaoqi.common.es.domain;

import java.util.List;
import java.util.Map;

/**
 * _sql的Reponse请求返回数据
 */
public class EsSqlContent {

    /**
     * 字段
     */
    private List<Map<String, String>> columns;

    /**
     * 数据
     */
    private List<List<Object>> rows;

    /**
     * 游标
     */
    private String cursor;

    public List<Map<String, String>> getColumns() {
        return columns;
    }

    public void setColumns(List<Map<String, String>> columns) {
        this.columns = columns;
    }

    public List<List<Object>> getRows() {
        return rows;
    }

    public void setRows(List<List<Object>> rows) {
        this.rows = rows;
    }

    public String getCursor() {
        return cursor;
    }

    public void setCursor(String cursor) {
        this.cursor = cursor;
    }
}
