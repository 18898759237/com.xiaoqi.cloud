package com.xiaoqi.common.es.domain;

import co.elastic.clients.elasticsearch._types.FieldSort;
import co.elastic.clients.elasticsearch._types.SortOptions;
import co.elastic.clients.elasticsearch._types.SortOrder;
import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.List;

/**
 * ES查询条件,排序,返回字段等参数配置
 */
public class EsQuery {


    /**
     * 文档 必须 匹配这些条件才能被包含进来。相当于sql中的 and
     */
    private EsFiledQuery mustQuery = new EsFiledQuery();

    /**
     * 文档 必须不 匹配这些条件才能被包含进来。相当于sql中的 not
     */
    private EsFiledQuery mustNotQuery = new EsFiledQuery();


    /**
     * 必须匹配，但它以不评分、过滤模式来进行。这些语句对评分没有贡献，只是根据过滤标准来排除或包含文档。
     */
    private EsFiledQuery filterQuery = new EsFiledQuery();

    /**
     * 包含字段，不设置返回全部
     */
    private List<String> includeList = Lists.newArrayList();

    /**
     * 排除字段，不设置返回全部
     */
    private List<String> excludeList = Lists.newArrayList();

    /**
     * 排序字段
     */
    private List<SortOptions> sortOptionsList = Lists.newArrayList();

    /**
     * 创建Must查询器
     * <p>
     * 档 必须 匹配这些条件才能被包含进来。相当于sql中的 and
     *
     * @return EsFiledQuery
     */
    public EsFiledQuery must() {
        return mustQuery;
    }

    /**
     * 创建MustNot查询器
     * <p>
     * 文档 必须不 匹配这些条件才能被包含进来。相当于sql中的 not
     *
     * @return EsFiledQuery
     */
    public EsFiledQuery mustNot() {
        return mustNotQuery;
    }


    /**
     * 创建Filter查询器(一般用于时间, 数值等不需要分词查询字段, 能优化match查询)
     * <p>
     * 必须匹配，但它以不评分、过滤模式来进行。这些语句对评分没有贡献，只是根据过滤标准来排除或包含文档。
     *
     * @return EsFiledQuery
     */
    public EsFiledQuery filter() {
        return filterQuery;
    }


    /**
     * 包含字段 -> 不指定返回所有
     *
     * @param filedName 指定返回字段
     * @return
     */
    public EsQuery includeSource(String... filedName) {
        this.includeList.addAll(Arrays.asList(filedName));
        return this;
    }

    /**
     * 排除字段 -> 不排除返回所有
     *
     * @param filedName 指定返回字段
     * @return
     */
    public EsQuery excludeSource(String... filedName) {
        this.excludeList.addAll(Arrays.asList(filedName));
        return this;
    }

    /**
     * 添加排序字段 -> 不指定不排序
     *
     * @param filedName 查询字段
     * @param sortOrder 排序类型
     * @return
     */
    public EsQuery addSort(String filedName, SortOrder sortOrder) {

        FieldSort fieldSort = new FieldSort.Builder().field(filedName).order(sortOrder).build();
        SortOptions sortOptions = new SortOptions.Builder().field(fieldSort).build();
        this.sortOptionsList.add(sortOptions);
        return this;
    }

    public List<SortOptions> getSortOptionsList() {
        return sortOptionsList;
    }

    public List<String> getIncludeList() {
        return includeList;
    }

    public List<String> getExcludeList() {
        return excludeList;
    }

    public EsFiledQuery getMustQuery() {
        return mustQuery;
    }

    public EsFiledQuery getMustNotQuery() {
        return mustNotQuery;
    }


    public EsFiledQuery getFilterQuery() {
        return filterQuery;
    }
}
