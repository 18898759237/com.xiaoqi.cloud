package com.xiaoqi.common.es.domain;

/**
 * _sql查询语句
 */
public class EsSql {

    /**
     * SQl语句(不含分页, 排序部分)
     */
    private String query;

    /**
     * 一次取多少
     */
    private Integer fetch_size;

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public Integer getFetch_size() {
        return fetch_size;
    }

    public void setFetch_size(Integer fetch_size) {
        this.fetch_size = fetch_size;
    }
}
