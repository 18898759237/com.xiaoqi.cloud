package com.xiaoqi.common.es.domain;

import co.elastic.clients.elasticsearch._types.query_dsl.*;
import co.elastic.clients.json.JsonData;
import com.google.common.collect.Lists;

import java.util.List;


/**
 * ES字段查询配置
 */
public class EsFiledQuery {


    /**
     * 查询条件
     */
    private List<Query> queryList = Lists.newArrayList();


    /**
     * 匹配查询(按分词进行查询)
     *
     * @param filedName  查询字段
     * @param filedValue 匹配值
     * @return
     */
    public EsFiledQuery addMatchQuery(String filedName, String filedValue) {

        Query matchQuery = new MatchQuery.Builder().field(filedName).query(filedValue).build()._toQuery();
        this.queryList.add(matchQuery);
        return this;
    }

    /**
     * 全字段匹配查询
     *
     * @param filedValue 匹配值
     * @return
     */
    public EsFiledQuery addMatchAllQuery(String filedValue) {

        Query matchAllQuery = new MatchAllQuery.Builder().queryName(filedValue).build()._toQuery();
        queryList.add(matchAllQuery);
        return this;
    }

    /**
     * 多字段匹配查询
     *
     * @param filedName  查询字段
     * @param filedValue 匹配值
     * @return
     */
    public EsFiledQuery addMultiMatchQuery(String filedValue, String filedName, String... filedNames) {

        Query matchQuery = new MultiMatchQuery.Builder().fields(filedName, filedNames).query(filedValue).build()._toQuery();
        this.queryList.add(matchQuery);
        return this;
    }

    /**
     * 精准查询
     *
     * @param filedName  查询字段
     * @param filedValue 匹配值
     * @return
     */
    public EsFiledQuery addTermQuery(String filedName, String filedValue) {

        Query matchQuery = new TermQuery.Builder().field(filedName + ".keyword").value(filedValue).build()._toQuery();
        this.queryList.add(matchQuery);
        return this;
    }

    /**
     * 模糊查询
     *
     * @param filedName  查询字段
     * @param filedValue 匹配值
     * @return
     */
    public EsFiledQuery addFuzzyQuery(String filedName, String filedValue) {

        Query fuzzyQuery = new FuzzyQuery.Builder().field(filedName).value(filedValue).maxExpansions(2).build()._toQuery();

        queryList.add(fuzzyQuery);
        return this;
    }

    /**
     * 范围查询-> 大于等于
     *
     * @param filedName 查询字段
     * @param filedVue  匹配值
     * @return
     */
    public EsFiledQuery addRangeGteQuery(String filedName, String filedVue) {
        Query rangeGteQuery = new RangeQuery.Builder().field(filedName).gte(JsonData.of(filedVue)).build()._toQuery();
        queryList.add(rangeGteQuery);
        return this;
    }

    /**
     * 范围查询-> 大于
     *
     * @param filedName 查询字段
     * @param filedVue  匹配值
     * @return
     */
    public EsFiledQuery addRangeGtQuery(String filedName, String filedVue) {

        Query rangeGteQuery = new RangeQuery.Builder().field(filedName).gt(JsonData.of(filedVue)).build()._toQuery();
        queryList.add(rangeGteQuery);
        return this;
    }

    /**
     * 范围查询-> 小于等于
     *
     * @param filedName 查询字段
     * @param filedVue  匹配值
     * @return
     */
    public EsFiledQuery addRangeLteQuery(String filedName, String filedVue) {

        Query rangeGteQuery = new RangeQuery.Builder().field(filedName).lte(JsonData.of(filedVue)).build()._toQuery();
        queryList.add(rangeGteQuery);
        return this;
    }

    /**
     * 范围查询-> 小于
     *
     * @param filedName 查询字段
     * @param filedVue  匹配值
     * @return
     */
    public EsFiledQuery addRangeLtQuery(String filedName, String filedVue) {

        Query rangeGteQuery = new RangeQuery.Builder().field(filedName).lt(JsonData.of(filedVue)).build()._toQuery();
        queryList.add(rangeGteQuery);
        return this;
    }

    public List<Query> getQueryList() {
        return queryList;
    }
}
