package com.xiaoqi.common.es.service;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.Result;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch.cat.IndicesResponse;
import co.elastic.clients.elasticsearch.core.*;
import co.elastic.clients.elasticsearch.core.search.SourceConfig;
import co.elastic.clients.elasticsearch.core.search.SourceFilter;
import co.elastic.clients.elasticsearch.indices.*;
import com.alibaba.fastjson2.JSON;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xiaoqi.common.core.annotation.TimeConsume;
import com.xiaoqi.common.core.utils.PageUtils;
import com.xiaoqi.common.core.web.domain.BaseEntity;
import com.xiaoqi.common.es.annotation.EsMapper;
import com.xiaoqi.common.es.domain.EsQuery;
import com.xiaoqi.common.es.domain.EsScript;
import com.xiaoqi.common.es.domain.EsSql;
import com.xiaoqi.common.es.domain.EsSqlContent;
import com.xiaoqi.common.es.utils.EsIoUtil;
import com.xiaoqi.common.es.utils.EsUtil;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Elasticsearch实现类
 *
 * @author xiaoqi
 **/
@SuppressWarnings(value = {"unchecked", "rawtypes"})
@Component
public class EsService {

    private static final Logger log = LoggerFactory.getLogger(EsService.class);

    private static final Gson gson = new Gson();

    @Autowired
    private ElasticsearchClient elasticsearchClient;

    @Autowired
    private RestClient restClient;

    /**
     * 创建索引
     *
     * @param clazz 实体类型
     * @return
     * @throws Exception
     */
    public boolean createIndex(Class<? extends BaseEntity> clazz) throws Exception {

        EsMapper esMapper = clazz.getAnnotation(EsMapper.class);

        // 索引配置
        IndexSettings indexSettings = new IndexSettings.Builder()
                .numberOfShards(Integer.valueOf(esMapper.shards()).toString()) // 主分片数量，默认1
                .numberOfReplicas(Integer.valueOf(esMapper.replicas()).toString()) // 主分片的副本数，默认1
                .build();

        // 创建索引请求Request
        CreateIndexRequest createIndexRequest = new CreateIndexRequest.Builder()
                .index(esMapper.index())
                .settings(indexSettings)
                .build();

        CreateIndexResponse response = elasticsearchClient.indices().create(createIndexRequest);
        //响应状态
        boolean acknowledged = response.acknowledged();
        boolean shardsAcknowledged = response.shardsAcknowledged();
        log.info("创建索引状态:{}", acknowledged);
        log.info("已确认的分片:{}", shardsAcknowledged);
        log.info("索引名称:{}", response.index());
        return acknowledged;
    }

    /**
     * 查看索引
     *
     * @param clazz 实体类型
     * @throws Exception
     */
    public void getIndex(Class<? extends BaseEntity> clazz) throws Exception {
        // 查看指定索引
        final String index = EsUtil.getIndex(clazz);
        GetIndexResponse getIndexResponse = elasticsearchClient.indices().get(req -> req.index(index));
        Map<String, IndexState> result = getIndexResponse.result();
        result.forEach((k, v) -> {
            log.info("索引名称:{}, 索引:{}", k, v);
        });
    }

    /**
     * 查看全部索引
     *
     * @throws Exception
     */
    public void getAllIndex() throws Exception {

        // 查看全部索引
        IndicesResponse indicesResponse = elasticsearchClient.cat().indices();
        indicesResponse.valueBody().forEach(info -> {
            log.info("索引:{}", info.index());
            log.info("info:{}", info.toString());
        });
    }

    /**
     * 删除索引
     *
     * @param clazz 实体类型
     * @return
     * @throws Exception
     */
    public boolean deleteIndex(Class<? extends BaseEntity> clazz) throws Exception {

        final String index = EsUtil.getIndex(clazz);
        DeleteIndexResponse deleteIndexResponse = elasticsearchClient.indices().delete(req -> req.index(index));
        log.info("删除索引操作结果：{}", deleteIndexResponse.acknowledged());
        return deleteIndexResponse.acknowledged();
    }

    /**
     * 添加文档
     *
     * @param <T>    实体类型
     * @param entity 实体
     * @return
     * @throws IOException
     */
    public <T> boolean addDocument(T entity) throws Exception {
        String index = EsUtil.getIndex(entity.getClass());
        IndexRequest.Builder<T> indexReqBuilder = new IndexRequest.Builder<>();
        indexReqBuilder.index(index);
        indexReqBuilder.id(EsUtil.getEntityId(entity));
        indexReqBuilder.document(entity);

        IndexResponse response = elasticsearchClient.index(indexReqBuilder.build());
        log.info("添加一个文档操作结果:{}", response.result());
        return response.result().equals(Result.Created);
    }

    /**
     * 批量添加文档
     *
     * @param <T>
     * @param entityList 实体集合
     * @return
     * @throws Exception
     */
    public <T> boolean batchAddDocument(List<T> entityList) throws Exception {
        String index = EsUtil.getIndex(entityList.get(0).getClass());

        BulkRequest.Builder bulkRequestBuilder = new BulkRequest.Builder();

        entityList.forEach(entity -> {
            bulkRequestBuilder.operations(bulkOperation -> bulkOperation
                    .index(indexOperation -> indexOperation
                            .index(index)
                            .id(EsUtil.getEntityId(entity))
                            .document(entity)));
        });

        BulkResponse bulkResponse = elasticsearchClient.bulk(bulkRequestBuilder.build());

        log.error("bulkResponse.errors() = {}", bulkResponse.errors());
        log.info("批量添加文档操作结果:{}", !bulkResponse.errors());
        return !bulkResponse.errors();
    }

    /**
     * 根据id更新文档
     *
     * @param <T>    实体类型
     * @param entity 实体
     * @return
     * @throws Exception
     */
    public <T> boolean updateDocumentById(T entity) throws Exception {
        String index = EsUtil.getIndex(entity.getClass());
        // 构建修改文档的请求
        UpdateResponse<Object> response = elasticsearchClient.update(req -> req
                        .index(index)
                        .id(EsUtil.getEntityId(entity))
                        .doc(entity),
                Object.class
        );
        log.info("更新文档操作结果:{}", response.result());
        return response.result().equals(Result.Updated);
    }

    /**
     * 根据id删除文档
     *
     * @param clazz 实体类型
     * @return
     * @throws Exception
     */
    public boolean deleteDocumentById(Class<? extends BaseEntity> clazz, Integer id) throws Exception {
        String index = EsUtil.getIndex(clazz);
        DeleteResponse deleteResponse = elasticsearchClient.delete(req -> req
                .index(index)
                .id(id.toString()));
        log.info("删除文档操作结果:{}", deleteResponse.result());
        return deleteResponse.result().equals(Result.Deleted);
    }

    /**
     * 批量删除文档
     *
     * @param entityList 实体集合
     * @throws Exception
     */
    public boolean batchDeleteDocument(List entityList) throws Exception {

        String index = EsUtil.getIndex(entityList.get(0).getClass());

        BulkRequest.Builder bulkRequestBuilder = new BulkRequest.Builder();

        entityList.forEach(entity -> {
            bulkRequestBuilder.operations(bulkOperation -> bulkOperation
                    .delete(deleteOperation -> deleteOperation
                            .index(index)
                            .id(EsUtil.getEntityId(entity))));
        });
        BulkResponse bulkResponse = elasticsearchClient.bulk(bulkRequestBuilder.build());
        return !bulkResponse.errors();
    }

    /**
     * 根据id查询文档
     *
     * @param id  查询ID
     * @param <T> 实体类型
     * @return
     * @throws Exception
     */
    public <T> T queryDocumentById(Class<? extends BaseEntity> clazz, Integer id) throws Exception {
        String index = EsUtil.getIndex(clazz);

        GetResponse<T> response = elasticsearchClient.get(req -> req
                        .index(index)
                        .id(id.toString()),
                (Type) clazz);

        if (!response.found()) {
            throw new Exception(StringUtils.replace("实体ID:{},搜索为空！", "{}", id.toString()));
        }
        return response.source();
    }

    /**
     * 分页 + 排序条件搜索
     *
     * @param clazz   实体类型
     * @param esQuery 查询条件
     * @param <T>
     * @return
     * @throws Exception
     */
    @TimeConsume
    public <T> PageInfo<T> queryPage(Class<? extends BaseEntity> clazz, EsQuery esQuery) throws Exception {

        // 获取分页参数
        Page page = PageUtils.getPage();

        String index = EsUtil.getIndex(clazz);

        Query query = new BoolQuery.Builder()
                .must(esQuery.getMustQuery().getQueryList())
                .mustNot(esQuery.getMustNotQuery().getQueryList())
                .filter(esQuery.getFilterQuery().getQueryList())
                .build()._toQuery();


        // 查询总条数
        Integer total = queryCount(index, query);

        // 设置包含字段, 排除字段
        SourceFilter sourceFilter = new SourceFilter.Builder()
                .includes(esQuery.getIncludeList())
                .excludes(esQuery.getExcludeList())
                .build();
        SourceConfig sourceConfig = new SourceConfig.Builder().filter(sourceFilter).build();

        // 匹配查询
        SearchRequest searchRequest = new SearchRequest.Builder().query(query)
                .index(index)
                .from((page.getPageNum() - 1) * page.getPageSize())
                .size(page.getPageSize())
                .sort(esQuery.getSortOptionsList())
                .source(sourceConfig)
                .build();

        log.info("匹配查询语句:{}", searchRequest.toString());
        SearchResponse<T> response = elasticsearchClient.search(searchRequest, (Type) clazz);
        // 获取查询结果
        List<T> dataList = Lists.newArrayList();
        response.hits().hits().stream().forEach(hit -> {
            dataList.add(hit.source());
        });
        return EsUtil.createPageInfo(dataList, page.getPageNum(), page.getPageSize(), total);
    }

    /**
     * 查询所有(慎用, 尽量带条件, 减少查询范围)
     *
     * @param clazz   实体类型
     * @param esQuery 查询条件
     * @param <T>
     * @return
     * @throws Exception
     */
    @TimeConsume
    public <T> List<T> queryAll(Class<? extends BaseEntity> clazz, EsQuery esQuery) throws Exception {

        String index = EsUtil.getIndex(clazz);
        Query query = new BoolQuery.Builder()
                .must(esQuery.getMustQuery().getQueryList())
                .mustNot(esQuery.getMustNotQuery().getQueryList())
                .filter(esQuery.getFilterQuery().getQueryList())
                .build()._toQuery();

        // 查询总条数
        Integer total = queryCount(index, query);

        // 设置包含字段, 排除字段
        SourceFilter sourceFilter = new SourceFilter.Builder()
                .includes(esQuery.getIncludeList())
                .excludes(esQuery.getExcludeList())
                .build();
        SourceConfig sourceConfig = new SourceConfig.Builder().filter(sourceFilter).build();

        // 匹配查询
        SearchRequest searchRequest = new SearchRequest.Builder().query(query)
                .index(index)
                .from(0)
                .size(total)
                .sort(esQuery.getSortOptionsList())
                .source(sourceConfig)
                .build();

        log.info("匹配查询语句:{}", searchRequest.toString());
        SearchResponse<T> response = elasticsearchClient.search(searchRequest, (Type) clazz);
        // 获取查询结果
        List<T> dataList = Lists.newArrayList();
        response.hits().hits().stream().forEach(hit -> {
            dataList.add(hit.source());
        });
        return dataList;
    }

    /**
     * 查询总条数
     *
     * @param index 索引
     * @param query 查询条件
     * @return
     * @throws IOException
     */
    private Integer queryCount(String index, Query query) throws IOException {

        long startTime = System.currentTimeMillis();
        // 查询总条数
        CountRequest countRequest = new CountRequest.Builder().query(query)
                .index(index)
                .build();
        log.info("总条数查询语句:{}", countRequest.toString());
        CountResponse countResponse = elasticsearchClient.count(countRequest);
        log.info("耗时:{}", System.currentTimeMillis() - startTime);
        return ((Long) countResponse.count()).intValue();
    }

    /**
     * 模板脚本分页查询(复杂查询可用脚本查询)
     *
     * @param clazz
     * @param esScript
     * @param <T>
     * @return
     * @throws Exception
     */
    public <T> PageInfo<T> queryTemplatedPage(Class<? extends BaseEntity> clazz, EsScript esScript) throws Exception {

        //第一步, sql转成DSL语句
        /*
            POST _sql/translate
            {
                "query":
                """
                  SELECT * FROM "vehilce_test_record"
                  where ((customerName = '百度' and vin <>'LTIC08871524F10921' ) or customerName = '小马' )
                  and recodTime >='2023-12-06' and recodTime <'2023-12-07'
                """
            }
        */
        // 第二步,替换脚本中变量,直接创建查询模板,直接查询

        // 获取分页参数
        Page page = PageUtils.getPage();

        String index = EsUtil.getIndex(clazz);

        String queryScript = index + "_script";
        esScript.setFrom((page.getPageNum() - 1) * page.getPageSize());
        esScript.setSize(page.getPageSize());

        String template = EsUtil.createScriptTemplate(esScript);


        // 创建搜索模板
        PutScriptRequest putScriptRequest = new PutScriptRequest.Builder()
                .id(queryScript)
                .script(sReq -> sReq
                        .lang("mustache")
                        .source(template)

                )
                .build();
        log.info("查询语句:{}", putScriptRequest.toString());
        elasticsearchClient.putScript(putScriptRequest);

        // 创建模板搜索request
        SearchTemplateRequest searchTemplateRequest = new SearchTemplateRequest.Builder()
                .index(index)
                .id(queryScript)
                .build();
        // 模板搜索
        SearchTemplateResponse<T> response = elasticsearchClient.searchTemplate(searchTemplateRequest, (Type) clazz);
        // 获取查询结果
        List<T> dataList = Lists.newArrayList();
        response.hits().hits().stream().forEach(hit -> {
            dataList.add(hit.source());
        });
        return EsUtil.createPageInfo(dataList, page.getPageNum(), page.getPageSize(), dataList.size());
    }

    /**
     * _sql分页查询(与mysql语法基本一致, 与kibana执行_sql原理一致)
     *
     * @param sql      _sql脚本, 不含排序, 分页字段
     *                 列如:" SELECT * from  vehilce_test_record where ((customerName = '百度' and vin <>'' ) or customerName = '小马' ) and recodTime >='2023-12-06' and recodTime <'2023-12-07'"
     * @param orderSql 排序sql, 如 order by id desc
     * @param <T>
     * @return
     * @throws Exception
     */
    @TimeConsume
    public <T> PageInfo<T> querySqlPage(String sql, String orderSql) throws Exception {

        // 获取分页参数
        Page page = PageUtils.getPage();

        // 总数查询
        String countStr = sql.split("from")[1];
        countStr = " select count(*) from ".concat(countStr);
        EsSql countSql = new EsSql();
        countSql.setQuery(countStr);
        Request countRequest = EsUtil.buildRequest(JSON.toJSONString(countSql));
        Response countResponse = restClient.performRequest(countRequest);
        String countContent = EsIoUtil.toString(countResponse.getEntity().getContent(), "UTF-8");
        EsSqlContent countSqlContent = gson.fromJson(countContent, EsSqlContent.class);
        Double total = Double.valueOf(countSqlContent.getRows().get(0).get(0).toString());


        // 分页查询
        String queryStr = sql.concat(" ").concat(orderSql);
        EsSql pageSql = new EsSql();
        pageSql.setQuery(queryStr);
        pageSql.setFetch_size(page.getPageNum() * page.getPageSize());

        Request pageRequest = EsUtil.buildRequest(JSON.toJSONString(pageSql));
        Response pageResponse = restClient.performRequest(pageRequest);
        String pageContent = EsIoUtil.toString(pageResponse.getEntity().getContent(), "UTF-8");
        EsSqlContent esSqlContent = gson.fromJson(pageContent, EsSqlContent.class);

        // 封装查询结果
        List<Map<String, Object>> data = Lists.newArrayList();
        for (int i = 0; i < esSqlContent.getRows().size(); i++) {

            Map<String, Object> rowMap = new HashMap<>();
            List<Object> row = esSqlContent.getRows().get(i);
            for (int j = 0; j < row.size(); j++) {
                String name = esSqlContent.getColumns().get(j).get("name");
                rowMap.put(name, row.get(j));
            }
            data.add(rowMap);
        }
        List<T> dataList = gson.fromJson(gson.toJson(data), List.class);
        dataList = dataList.subList((page.getPageNum() - 1) * page.getPageSize(), dataList.size());
        return EsUtil.createPageInfo(dataList, page.getPageNum(), page.getPageSize(), total.intValue());
    }
}
