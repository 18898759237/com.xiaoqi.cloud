package com.xiaoqi.common.es.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * ES实体注解
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface EsMapper {

    /**
     * 索引名称
     */
    String index() default "";


    /**
     * 主分片数量，默认1
     */
    int shards() default 1;

    /**
     * 主分片的副本数，默认1
     */
    int replicas() default 1;

}
