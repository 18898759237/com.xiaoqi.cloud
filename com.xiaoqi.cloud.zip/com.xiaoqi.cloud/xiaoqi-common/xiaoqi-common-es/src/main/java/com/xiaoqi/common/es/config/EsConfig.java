package com.xiaoqi.common.es.config;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import com.google.common.collect.Lists;
import com.xiaoqi.common.es.service.EsService;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.List;

@Configuration
@ConfigurationProperties(prefix = "elasticsearch")
public class EsConfig {

    private static final Logger logger = LoggerFactory.getLogger(EsService.class);

    /**
     * ES连接配置
     */
    private List<String> hosts;

    /**
     * 用户名(elastic)
     */
    private String userName;

    /**
     * 密码
     */
    private String password;

    /**
     * http秘钥(http.p12)
     */
    private String certPath;

    /**
     * 创建ElasticsearchClient连接(含Credentials校验及SSL连接)
     *
     * @return
     * @throws NoSuchAlgorithmException
     * @throws KeyStoreException
     * @throws KeyManagementException
     */
    @Bean
    public ElasticsearchClient getElasticsearchClient(RestClient restClient) {
        ElasticsearchTransport transport = new RestClientTransport(
                restClient, new JacksonJsonpMapper());
        ElasticsearchClient elasticsearchClient = new ElasticsearchClient(transport);
        return elasticsearchClient;
    }

    /**
     * 创建restClient连接(含Credentials校验及SSL连接)
     *
     * @return
     * @throws NoSuchAlgorithmException
     * @throws KeyStoreException
     * @throws KeyManagementException
     */
    @Bean
    public RestClient getRestClient() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(userName, password));
        KeyStore keyStore = KeyStore.getInstance("pkcs12");
        try (InputStream is = this.getClass().getClassLoader().getResourceAsStream(certPath)) {
            // 秘钥没设置密码
            keyStore.load(is, "".toCharArray());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        SSLContextBuilder sslContextBuilder = SSLContexts.custom().loadTrustMaterial(keyStore, (x509Certificates, s) -> true);
        final SSLContext sslContext = sslContextBuilder.build();
        RestClientBuilder builder = RestClient.builder(getHttpHostList());
        builder.setHttpClientConfigCallback(httpClientBuilder -> {
            httpClientBuilder.setSSLContext(sslContext);
            httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
            return httpClientBuilder;
        });
        RestClient restClient = builder.build();
        return restClient;
    }

    /**
     * 创建ES连接配置
     *
     * @return
     */
    public HttpHost[] getHttpHostList() {
        List<HttpHost> httpHostList = Lists.newArrayList();

        hosts.forEach(vo -> {
            String ip = vo.split(":")[0];
            int port = Integer.valueOf(vo.split(":")[1]);
            HttpHost httpHost = new HttpHost(ip, port, "https");
            httpHostList.add(httpHost);
        });
        HttpHost[] httpHosts = new HttpHost[httpHostList.size()];
        for (int i = 0; i < httpHostList.size(); i++) {
            httpHosts[i] = httpHostList.get(i);
        }
        return httpHosts;
    }

    ;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCertPath() {
        return certPath;
    }

    public void setCertPath(String certPath) {
        this.certPath = certPath;
    }

    public List<String> getHosts() {
        return hosts;
    }

    public void setHosts(List<String> hosts) {
        this.hosts = hosts;
    }
}
