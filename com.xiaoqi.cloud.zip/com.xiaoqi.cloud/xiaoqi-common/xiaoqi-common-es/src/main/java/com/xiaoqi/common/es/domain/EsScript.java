package com.xiaoqi.common.es.domain;

import co.elastic.clients.elasticsearch._types.SortOrder;
import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * ES脚本模板查询
 */
public class EsScript {

    private List<String> excludeList = Lists.newArrayList();
    private List<String> includeList = Lists.newArrayList();
    private Integer from;
    private Integer size;
    private List<Map<String, Map<String, String>>> sortOptionsList = Lists.newArrayList();
    private String script = new String();
    private List<String> queryList = Lists.newArrayList();


    /**
     * 包含字段 -> 不指定返回所有
     *
     * @param filedName 指定返回字段
     * @return
     */
    public EsScript includeSource(String... filedName) {
        this.includeList.addAll(Arrays.asList(filedName));
        return this;
    }

    /**
     * 排除字段 -> 不排除返回所有
     *
     * @param filedName 指定返回字段
     * @return
     */
    public EsScript excludeSource(String... filedName) {
        this.excludeList.addAll(Arrays.asList(filedName));
        return this;
    }

    /**
     * 添加排序字段 -> 不指定不排序
     *
     * @param filedName 查询字段
     * @param sortOrder 排序类型
     * @return
     */
    public EsScript addSort(String filedName, SortOrder sortOrder) {

        Map<String, Map<String, String>> sortMap = new HashMap<>();
        Map<String, String> filedMap = new HashMap<>();
        filedMap.put("order", sortOrder.jsonValue());
        sortMap.put(filedName, filedMap);
        this.sortOptionsList.add(sortMap);
        return this;
    }

    /**
     * 查询脚本字段
     *
     * @param params 参数
     * @return
     */
    public EsScript addParams(String... params) {
        this.queryList.addAll(Arrays.asList(params));
        return this;
    }

    public List<String> getExcludeList() {
        return excludeList;
    }

    public List<String> getIncludeList() {
        return includeList;
    }

    public Integer getFrom() {
        return from;
    }

    public Integer getSize() {
        return size;
    }

    public List<Map<String, Map<String, String>>> getSortOptionsList() {
        return sortOptionsList;
    }

    public String getScript() {
        return script;
    }

    public List<String> getQueryList() {
        return queryList;
    }

    public EsScript setFrom(Integer from) {
        this.from = from;
        return this;
    }

    public EsScript setScript(String script) {
        this.script = script;
        return this;
    }

    public EsScript setSize(Integer size) {
        this.size = size;
        return this;
    }
}

